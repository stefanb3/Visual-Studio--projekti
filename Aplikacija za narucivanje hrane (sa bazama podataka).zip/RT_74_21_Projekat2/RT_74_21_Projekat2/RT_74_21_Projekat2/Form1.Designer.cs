﻿
namespace RT_74_21_Projekat2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnStatistika = new System.Windows.Forms.Button();
            this.btnRacuni = new System.Windows.Forms.Button();
            this.btnDodajJelo = new System.Windows.Forms.Button();
            this.btnOcisti = new System.Windows.Forms.Button();
            this.btnFinish = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.numKol = new System.Windows.Forms.NumericUpDown();
            this.btnUkloniPrilog = new System.Windows.Forms.Button();
            this.btnUkloniJelo = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnAddJelo = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnSerach = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSortOpad = new System.Windows.Forms.Button();
            this.btnSortRast = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblAnimacija = new System.Windows.Forms.Label();
            this.animationTimer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStatistika
            // 
            this.btnStatistika.Location = new System.Drawing.Point(808, 237);
            this.btnStatistika.Name = "btnStatistika";
            this.btnStatistika.Size = new System.Drawing.Size(550, 25);
            this.btnStatistika.TabIndex = 48;
            this.btnStatistika.Text = "Prikazi Statistiku prodaje";
            this.btnStatistika.UseVisualStyleBackColor = true;
            this.btnStatistika.Click += new System.EventHandler(this.btnStatistika_Click);
            // 
            // btnRacuni
            // 
            this.btnRacuni.Location = new System.Drawing.Point(808, 298);
            this.btnRacuni.Name = "btnRacuni";
            this.btnRacuni.Size = new System.Drawing.Size(550, 23);
            this.btnRacuni.TabIndex = 47;
            this.btnRacuni.Text = "Pogledaj Racune";
            this.btnRacuni.UseVisualStyleBackColor = true;
            this.btnRacuni.Click += new System.EventHandler(this.btnRacuni_Click);
            // 
            // btnDodajJelo
            // 
            this.btnDodajJelo.Location = new System.Drawing.Point(808, 268);
            this.btnDodajJelo.Name = "btnDodajJelo";
            this.btnDodajJelo.Size = new System.Drawing.Size(550, 23);
            this.btnDodajJelo.TabIndex = 46;
            this.btnDodajJelo.Text = "Dodaj Jelo";
            this.btnDodajJelo.UseVisualStyleBackColor = true;
            this.btnDodajJelo.Click += new System.EventHandler(this.btnDodajJelo_Click);
            // 
            // btnOcisti
            // 
            this.btnOcisti.Location = new System.Drawing.Point(1258, 12);
            this.btnOcisti.Name = "btnOcisti";
            this.btnOcisti.Size = new System.Drawing.Size(100, 34);
            this.btnOcisti.TabIndex = 45;
            this.btnOcisti.Text = "Ocisti Korpu";
            this.btnOcisti.UseVisualStyleBackColor = true;
            this.btnOcisti.Click += new System.EventHandler(this.btnOcisti_Click);
            // 
            // btnFinish
            // 
            this.btnFinish.Location = new System.Drawing.Point(808, 208);
            this.btnFinish.Name = "btnFinish";
            this.btnFinish.Size = new System.Drawing.Size(550, 23);
            this.btnFinish.TabIndex = 44;
            this.btnFinish.Text = "Zavrsi Kupovinu";
            this.btnFinish.UseVisualStyleBackColor = true;
            this.btnFinish.Click += new System.EventHandler(this.btnFinish_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(764, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 43;
            this.label4.Text = "Korpa:";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(808, 52);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView3.Size = new System.Drawing.Size(550, 150);
            this.dataGridView3.TabIndex = 42;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 366);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 41;
            this.label3.Text = "Kolicina:";
            // 
            // numKol
            // 
            this.numKol.Location = new System.Drawing.Point(65, 359);
            this.numKol.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numKol.Name = "numKol";
            this.numKol.Size = new System.Drawing.Size(37, 20);
            this.numKol.TabIndex = 40;
            this.numKol.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnUkloniPrilog
            // 
            this.btnUkloniPrilog.Location = new System.Drawing.Point(250, 418);
            this.btnUkloniPrilog.Name = "btnUkloniPrilog";
            this.btnUkloniPrilog.Size = new System.Drawing.Size(106, 20);
            this.btnUkloniPrilog.TabIndex = 39;
            this.btnUkloniPrilog.Text = "Ukloni";
            this.btnUkloniPrilog.UseVisualStyleBackColor = true;
            this.btnUkloniPrilog.Click += new System.EventHandler(this.btnUkloniPrilog_Click);
            // 
            // btnUkloniJelo
            // 
            this.btnUkloniJelo.Location = new System.Drawing.Point(250, 392);
            this.btnUkloniJelo.Name = "btnUkloniJelo";
            this.btnUkloniJelo.Size = new System.Drawing.Size(106, 20);
            this.btnUkloniJelo.TabIndex = 38;
            this.btnUkloniJelo.Text = "Ukloni";
            this.btnUkloniJelo.UseVisualStyleBackColor = true;
            this.btnUkloniJelo.Click += new System.EventHandler(this.btnUkloniJelo_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 416);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Izabran Prilog:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 396);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 36;
            this.label1.Text = "Izabrano Jelo:";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(88, 417);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(144, 20);
            this.textBox2.TabIndex = 35;
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(88, 391);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(144, 20);
            this.textBox1.TabIndex = 34;
            // 
            // btnAddJelo
            // 
            this.btnAddJelo.Location = new System.Drawing.Point(130, 355);
            this.btnAddJelo.Name = "btnAddJelo";
            this.btnAddJelo.Size = new System.Drawing.Size(226, 30);
            this.btnAddJelo.TabIndex = 33;
            this.btnAddJelo.Text = "Dodaj Selektovano Jelo Na Racun";
            this.btnAddJelo.UseVisualStyleBackColor = true;
            this.btnAddJelo.Click += new System.EventHandler(this.btnAddJelo_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(362, 52);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView2.Size = new System.Drawing.Size(308, 269);
            this.dataGridView2.TabIndex = 32;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(244, 327);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(112, 23);
            this.btnReset.TabIndex = 31;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnSerach
            // 
            this.btnSerach.Location = new System.Drawing.Point(130, 327);
            this.btnSerach.Name = "btnSerach";
            this.btnSerach.Size = new System.Drawing.Size(112, 23);
            this.btnSerach.TabIndex = 30;
            this.btnSerach.Text = "Pretrazi";
            this.btnSerach.UseVisualStyleBackColor = true;
            this.btnSerach.Click += new System.EventHandler(this.btnSerach_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(12, 327);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(112, 20);
            this.txtSearch.TabIndex = 29;
            // 
            // btnSortOpad
            // 
            this.btnSortOpad.Location = new System.Drawing.Point(176, 12);
            this.btnSortOpad.Name = "btnSortOpad";
            this.btnSortOpad.Size = new System.Drawing.Size(180, 34);
            this.btnSortOpad.TabIndex = 28;
            this.btnSortOpad.Text = "Sortiraj Opadajuce";
            this.btnSortOpad.UseVisualStyleBackColor = true;
            this.btnSortOpad.Click += new System.EventHandler(this.btnSortOpad_Click);
            // 
            // btnSortRast
            // 
            this.btnSortRast.Location = new System.Drawing.Point(15, 12);
            this.btnSortRast.Name = "btnSortRast";
            this.btnSortRast.Size = new System.Drawing.Size(155, 34);
            this.btnSortRast.TabIndex = 27;
            this.btnSortRast.Text = "Sortiraj Rastuce";
            this.btnSortRast.UseVisualStyleBackColor = true;
            this.btnSortRast.Click += new System.EventHandler(this.btnSortRast_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 52);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dataGridView1.Size = new System.Drawing.Size(344, 269);
            this.dataGridView1.TabIndex = 26;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblAnimacija
            // 
            this.lblAnimacija.AutoSize = true;
            this.lblAnimacija.Location = new System.Drawing.Point(245, 79);
            this.lblAnimacija.Name = "lblAnimacija";
            this.lblAnimacija.Size = new System.Drawing.Size(35, 13);
            this.lblAnimacija.TabIndex = 49;
            this.lblAnimacija.Text = "label5";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblAnimacija);
            this.groupBox1.Location = new System.Drawing.Point(498, 337);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(628, 163);
            this.groupBox1.TabIndex = 50;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Najprodavanije jelo";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1416, 503);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnStatistika);
            this.Controls.Add(this.btnRacuni);
            this.Controls.Add(this.btnDodajJelo);
            this.Controls.Add(this.btnOcisti);
            this.Controls.Add(this.btnFinish);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numKol);
            this.Controls.Add(this.btnUkloniPrilog);
            this.Controls.Add(this.btnUkloniJelo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnAddJelo);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnSerach);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSortOpad);
            this.Controls.Add(this.btnSortRast);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numKol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStatistika;
        private System.Windows.Forms.Button btnRacuni;
        private System.Windows.Forms.Button btnDodajJelo;
        private System.Windows.Forms.Button btnOcisti;
        private System.Windows.Forms.Button btnFinish;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numKol;
        private System.Windows.Forms.Button btnUkloniPrilog;
        private System.Windows.Forms.Button btnUkloniJelo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnAddJelo;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnSerach;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSortOpad;
        private System.Windows.Forms.Button btnSortRast;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblAnimacija;
        private System.Windows.Forms.Timer animationTimer;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

