﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RT_74_21_Projekat2
{
    public partial class Form1 : Form
    {
        public restoraniDataSet ds;
        public restoraniDataSetTableAdapters.JeloTableAdapter da;
        public restoraniDataSetTableAdapters.PrilogTableAdapter dPrilog;
        public restoraniDataSetTableAdapters.PripadnostTableAdapter dPripadnost;
        public restoraniDataSetTableAdapters.Stavka_racunaTableAdapter dStavka;
        public restoraniDataSetTableAdapters.RacunTableAdapter dRacun;
        int jeloCena, prilogCena;
        string jeloIme = null, prilogIme = null;
        int id_jelo, id_prilog;
        Thread t;
        Point p;
        DataTable racun = new DataTable();

        


        int startY;
        int direction = 1; // 1 za kretanje naniže, -1 za kretanje naviše
        int speed = 2; // Brzina animacije



        public Form1()
        {
            InitializeComponent();
            ds = new restoraniDataSet();    // Inicijalizacija skupa podataka
            da = new restoraniDataSetTableAdapters.JeloTableAdapter();   // Inicijalizacija adaptera za tabelu "Jelo" u bazi
            dPrilog = new restoraniDataSetTableAdapters.PrilogTableAdapter();   // Inicijalizacija adaptera za tabelu "Prilog" u bazi
            dPripadnost = new restoraniDataSetTableAdapters.PripadnostTableAdapter(); // Inicijalizacija adaptera za tabelu "Pripadnost" u bazi
            dStavka = new restoraniDataSetTableAdapters.Stavka_racunaTableAdapter();   // Inicijalizacija adaptera za tabelu "Stavka_racuna" u bazi
            dRacun = new restoraniDataSetTableAdapters.RacunTableAdapter();   // Inicijalizacija adaptera za tabelu "Racun" u bazi
            p = new Point(250, 0);
            this.Paint += Form1_Paint;  // Dodajemo događaj za crtanje na formi
            this.DoubleBuffered = true; // Omogućava dvostruko učitavanje za bolju animaciju

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            //lblAnimacija.Left = p.X;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            da.Fill(ds.Jelo); // Popunjavanje skupa podataka "ds" s podacima iz tabele "Jelo"
            dPripadnost.Fill(ds.Pripadnost); // Popunjavanje skupa podataka "ds" s podacima iz tabele "Pripadnost"
            dPrilog.Fill(ds.Prilog); //isto za prilog
            dRacun.Fill(ds.Racun); // isto za racun
            dStavka.Fill(ds.Stavka_racuna); // isto za stavku
            dataGridView1.DataSource = ds.Jelo; // Postavljanje izvora podataka za "dataGridView1" na tabelu "Jelo" to je prvi dataGridView sa lijeve strane
            lblAnimacija.Text = "Cevapi"; //stavljamo prvo jelo koje ce da bude najprodavanije prije prvog azuriranja od strane funkicje
            // Inicijalizacija DataTable "racun" za prikaz racuna
            racun.Columns.Add("Kolicina", typeof(int));
            racun.Columns.Add("Jelo", typeof(string));
            racun.Columns.Add("Prilog", typeof(string));
            racun.Columns.Add("Jelo Cena", typeof(int));
            racun.Columns.Add("Prilog Cena", typeof(int));
            racun.Columns.Add("Ukpuna Cena", typeof(int));
            racun.Columns.Add("id_Jelo", typeof(int));
            racun.Columns.Add("id_Prilog", typeof(int));

            // Postavljanje izvora podataka za "dataGridView3" na "racun" to je dataGridView prvi sa desne strane za racune
            dataGridView3.DataSource = racun;





            startY = groupBox1.Top + lblAnimacija.Top; // Računanje relativne pozicije
            System.Windows.Forms.Timer animationTimer = new System.Windows.Forms.Timer();
            animationTimer.Interval = 20; // Interval u milisekundama
            animationTimer.Tick += AnimationTimer_Tick; //pozivamo funkciju  za animaciju
            animationTimer.Start(); //startujemo

            // Poziv funkcije za prikaz najprodavanijih jela
            lblNajprodavanije(); //da azuriramo labl u slucaju da je neko drugo jelo prodavanije od prethodnog
        }

        private void AnimationTimer_Tick(object sender, EventArgs e)
        {
            int maxY = groupBox1.ClientSize.Height - lblAnimacija.Height;

           
            lblAnimacija.Top += speed * direction;     // Ažuriranje pozicije labela


            if (lblAnimacija.Top <= 0 || lblAnimacija.Top >= maxY)    // Ako labela dodirne gornju ili donju granicu, promeni smjer animacije
            {
                direction *= -1;
            }
        }


        private void btnSortRast_Click(object sender, EventArgs e)
        {
            // Izvršavanje upita za sortiranje podataka iz tabele "Jelo" po ceni u rastućem redosledu
            var rez = from s
                     in ds.Jelo
                      orderby s.cena
                      select s;
            dataGridView1.AutoGenerateColumns = true; // Omogućavanje automatskog generisanja kolona u "dataGridView1"
            dataGridView1.DataSource = rez.ToList(); // Postavljanje izvora podataka "dataGridView1" na rezultat upita kao listu
        }
        //ove dvije funkcije imaju isti kod samo je razlika u ascending i descending iz nekog razloga za rast nije potrebno staviti ascending 
        private void btnSortOpad_Click(object sender, EventArgs e)
        {
            // Izvršavanje upita za sortiranje podataka iz tabele "Jelo" po ceni u opadajucem redosledu
            var rez = from s
                      in ds.Jelo
                      orderby s.cena descending
                      select s;
            dataGridView1.AutoGenerateColumns = true; // Omogućavanje automatskog generisanja kolona u "dataGridView1"
            dataGridView1.DataSource = rez.ToList(); // Postavljanje izvora podataka "dataGridView1" na rezultat upita kao listu
        }

        private void btnSerach_Click(object sender, EventArgs e)
        {
            var rez = from s     // Izvršavanje upita za pronalaženje jela sa nazivom koji se poklapa sa tekstom unetim u txtSearch polje
                     in ds.Jelo
                      where s.naziv.ToLower() == txtSearch.Text.ToLower()
                      select s;
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = rez.ToList();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewCell clickedCell = dataGridView1.Rows[e.RowIndex].Cells[0];   // Dobijanje vrednosti ćelije u prvoj koloni
                string cellValue = clickedCell.Value.ToString();
                 
                var rez = from s in ds.Prilog    // Izvršavanje upita za pronalaženje priloga povezanih sa odabranim jelom
                          where (from b in ds.Pripadnost
                                 where b.id_jelo.ToString() == cellValue
                                 select b.id_prilog).Contains(s.id_prilog)
                          select s;

                // Postavljanje vrednosti u TextBox kontrole 
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox2.Text = "";
                jeloIme = textBox1.Text;
                prilogIme = null;
                id_prilog = 0;
                prilogCena = 0;
                jeloCena = Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString());
                id_jelo = Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                dataGridView2.AutoGenerateColumns = true;  // Omogućavanje automatskog generisanja kolona u "dataGridView2"
                dataGridView2.DataSource = rez.ToList();   // Postavljanje izvora podataka "dataGridView2" na rezultat upita kao listu 
            }
        }

        private void btnUkloniJelo_Click(object sender, EventArgs e) //uklanjamo izabrano jelo
        {
            textBox1.Text = "";
            textBox2.Text = "";
            prilogIme = null;
            jeloIme = null;
            jeloCena = 0;
            prilogCena = 0;
        }

        private void btnUkloniPrilog_Click(object sender, EventArgs e) //uklanjamo izabrani prilog moglo je sve kao jedno dugme ali bolje je odvojeno da bi korisnik ako izabere ispravno jelo a pogresan prilog mogao samo prilog da skloni da ne dodaje sve ispocetka
        {
            textBox2.Text = "";
            prilogIme = null;
            prilogCena = 0;
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                textBox2.Text = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();   // Postavljanje vrednosti u TextBox  za prilog
                prilogIme = textBox2.Text;
                prilogCena = Int32.Parse(dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString()); // Postavljanje vrednosti za cenu priloga 
                id_prilog = Int32.Parse(dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString()); //Postavljanje vrednosti za njegov ID
            }
        }

        private void btnOcisti_Click(object sender, EventArgs e) //za ciscenje racuna
        {
            racun.Clear();
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            int ukupnaCena = 0; //inicijalizujemo pocetno na 0
            for (int i = 0; i < dataGridView3.RowCount; i++) //prolazimo kroz tabelu za racun
            {

                // Kreiranje nove vrste (row) za tabelu "Stavka_racuna"
                DataRow newRow = ds.Tables["Stavka_racuna"].NewRow();
                if (ds.Racun.Rows.Count == 0)  // Postavljanje vrednosti za "id_racun"
                {
                    newRow["id_racun"] = 1;
                }
                else
                {
                    newRow["id_racun"] = Int32.Parse(ds.Racun.Rows[ds.Racun.Rows.Count - 1]["id_racun"].ToString()) + 1;
                }
                // Postavljanje vrednosti za "id_jelo" i "id_prilog"
                newRow["id_jelo"] = Int32.Parse(dataGridView3.Rows[i].Cells[6].Value.ToString());
                newRow["id_prilog"] = Int32.Parse(dataGridView3.Rows[i].Cells[7].Value.ToString());


                // Postavljanje vrednosti za cene jela i priloga
                newRow["cenaJelo"] = Int32.Parse(dataGridView3.Rows[i].Cells[3].Value.ToString());
                ukupnaCena += Int32.Parse(dataGridView3.Rows[i].Cells[3].Value.ToString()) * Int32.Parse(dataGridView3.Rows[i].Cells[0].Value.ToString());
                newRow["cenaPrilog"] = Int32.Parse(dataGridView3.Rows[i].Cells[4].Value.ToString());
                ukupnaCena += Int32.Parse(dataGridView3.Rows[i].Cells[4].Value.ToString()) * Int32.Parse(dataGridView3.Rows[i].Cells[0].Value.ToString());


                newRow["kolicina"] = Int32.Parse(dataGridView3.Rows[i].Cells[0].Value.ToString()); // Postavljanje vrednosti za količinu
                ds.Tables["Stavka_racuna"].Rows.Add(newRow); // Dodavanje nove vrste u tabelu "Stavka_racuna"




            }
            // Kreiranje nove vrste (row) za tabelu "Racun"
            DataRow newRow1 = ds.Tables["Racun"].NewRow();


            if (ds.Racun.Rows.Count == 0) // Postavljanje vrednosti za "id_racun"
            {
                newRow1["id_racun"] = 1;
            }
            else
            {
                newRow1["id_racun"] = Int32.Parse(ds.Racun.Rows[ds.Racun.Rows.Count - 1]["id_racun"].ToString()) + 1;
            }

            // Postavljanje vrednosti za "ukupna_cena" i "datum"
            newRow1["ukupna_cena"] = ukupnaCena;
            newRow1["datum"] = System.DateTime.Now;

            // Dodavanje nove vrste u tabelu "Racun"
            ds.Tables["Racun"].Rows.Add(newRow1);

            // Brisanje sadržaja DataTable "racun"
            racun.Clear();
            lblNajprodavanije(); //pozivamo funkciju koja ce da provjeri koje je najprodavanije jelo i da ga upise u labelu
        }

        private void btnStatistika_Click(object sender, EventArgs e)
        {
            prikaziStatistikuProdaje formaZaStatistikuProdaje = new prikaziStatistikuProdaje();
            formaZaStatistikuProdaje.SourceForm = this;
            formaZaStatistikuProdaje.ShowDialog();
        }

        private void btnDodajJelo_Click(object sender, EventArgs e)
        {
            formaZaDodavanjeJela formaZaDodavanjejela = new formaZaDodavanjeJela();
            formaZaDodavanjejela.SourceForm = this;
            formaZaDodavanjejela.Show();
        }

        private void btnRacuni_Click(object sender, EventArgs e)
        {
            formaZaPregledRacuna forma = new formaZaPregledRacuna();
            forma.SourceForm = this;
            forma.Show();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = true;
            dataGridView1.DataSource = ds.Jelo;
        }

        private void btnAddJelo_Click(object sender, EventArgs e)
        {
            if (jeloIme != null)  // Provera da li je odabrano jelo
                racun.Rows.Add(numKol.Value, textBox1.Text, prilogIme, jeloCena, prilogCena, (jeloCena + prilogCena) * numKol.Value, id_jelo, id_prilog);
            checkGrid3();
        }




        void checkGrid3()//ispitujemo da li se ponavljaju redovi tj dali smo isto jelo narucili vise puta pa samo dodaje kolicinu + za vrijednost koliko smo istih porudzbina jos dodali a brise novi red tako da ima samo 1
        {
            for (int i = 0; i < dataGridView3.RowCount - 1; i++) //prolazaimo kroz tabelu za racun dg3
            {
                for (int j = i + 1; j < dataGridView3.RowCount; j++)
                {
                    // Provera da li postoje dva reda sa istim jelom i prilogom
                    if (dataGridView3.Rows[i].Cells[1].Value.ToString() == dataGridView3.Rows[j].Cells[1].Value.ToString() && dataGridView3.Rows[i].Cells[2].Value.ToString() == dataGridView3.Rows[j].Cells[2].Value.ToString())
                    {
                        // Kombinovanje količina i ažuriranje ukupne cene
                        int novaKolicina = Int32.Parse(dataGridView3.Rows[i].Cells[0].Value.ToString()) + Int32.Parse(dataGridView3.Rows[j].Cells[0].Value.ToString());
                        int staraCena = Int32.Parse(dataGridView3.Rows[i].Cells[5].Value.ToString()) / Int32.Parse(dataGridView3.Rows[i].Cells[0].Value.ToString());
                        racun.Rows[i]["Kolicina"] = novaKolicina;
                        racun.Rows[i]["Ukpuna Cena"] = staraCena * novaKolicina;

                        // Obrisati drugi red iz tabele "racun"
                        DataRow rowToRemove = racun.Rows[j];
                        rowToRemove.Delete();
                        racun.AcceptChanges();
                    }

                }
            }
        }





        public void lblNajprodavanije() {

            prikaziStatistikuProdaje forma = new prikaziStatistikuProdaje();
            forma.SourceForm = this;
            forma.Show();
            lblAnimacija.Text = forma.najprodavanijeJelo;
            forma.Close();

        
        
        }
    }
}
