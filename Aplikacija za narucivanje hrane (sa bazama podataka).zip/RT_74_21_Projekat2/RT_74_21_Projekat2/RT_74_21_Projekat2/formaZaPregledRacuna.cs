﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RT_74_21_Projekat2
{
    public partial class formaZaPregledRacuna : Form
    {
        public Form1 SourceForm { get; set; }

        public formaZaPregledRacuna()
        {
            InitializeComponent();
        }

        private void formaZaPregledRacuna_Load(object sender, EventArgs e)
        {
            // Izvršavanje upita za dobijanje računa koji su kreirani u poslednji minut
            var rez = from s in SourceForm.ds.Racun
                      where s.datum.AddMinutes(1) > DateTime.Now
                      select new
                      {
                          s.id_racun,
                          s.ukupna_cena,
                          s.datum

                      };
            dataGridView1.DataSource = rez.ToList();  // Postavljanje izvora podataka za dataGridView1 na rezultat upita
        } 

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewCell clickedCell = dataGridView1.Rows[e.RowIndex].Cells[0];
                string cellValue = clickedCell.Value.ToString();

                // Izvršavanje upita za dobijanje stavki računa za odabrani račun
                var rez = from s in SourceForm.ds.Stavka_racuna
                          join jelo in SourceForm.ds.Jelo on s.id_jelo equals jelo.id_jelo
                          join prilog in SourceForm.ds.Prilog on s.id_prilog equals prilog.id_prilog into prilogGroup
                          from prilog in prilogGroup.DefaultIfEmpty()
                          where s.id_racun == Int32.Parse(clickedCell.Value.ToString())
                          select new
                          {
                              s.id_racun,
                              JeloNaziv = jelo.naziv,
                              PrilogNaziv = prilog != null ? prilog.naziv : "",
                              s.cenaJelo,
                              s.cenaPrilog,
                              s.kolicina
                          };
               

                dataGridView2.DataSource = rez.ToList();   // Postavljanje izvora podataka za dataGridView2 na rezultat upita
            }
        }
    }
}
