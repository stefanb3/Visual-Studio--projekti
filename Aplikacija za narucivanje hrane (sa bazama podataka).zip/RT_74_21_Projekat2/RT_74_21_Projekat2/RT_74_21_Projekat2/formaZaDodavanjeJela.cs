﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RT_74_21_Projekat2
{
    public partial class formaZaDodavanjeJela : Form
    {
        public Form1 SourceForm { get; set; } // Referenca na Form1
        DataTable prilozi = new DataTable();
        DataTable prilozi1 = new DataTable();
        public formaZaDodavanjeJela()
        {
            InitializeComponent();
        }

        private void formaZaDodavanjeJela_Load(object sender, EventArgs e)
        {
            // Kopiranje tabele "Prilog" iz Form1 u prilozi1
            prilozi1 = SourceForm.ds.Prilog.Copy();

            dataGridView1.DataSource = prilozi1; // Postavljanje izvora podataka za dataGridView1 na prilozi1

            // Inicijalizacija DataTable "prilozi" za prikaz odabranih priloga
            prilozi.Columns.Add("id_prilog", typeof(int));
            prilozi.Columns.Add("naziv", typeof(string));
            prilozi.Columns.Add("cena", typeof(int));
            dataGridView2.DataSource = prilozi;  // Postavljanje izvora podataka za dataGridView2 na prilozi

        }

        private void btnDodajJelo_Click(object sender, EventArgs e)
        {
            if (txtIme.Text != "")
            {
                int id = SourceForm.ds.Jelo.Rows.Count + 1;
                SourceForm.ds.Jelo.Rows.Add(id, txtIme.Text, Int32.Parse(numericUpDown1.Value.ToString())); // Dodavanje novog jela u tabelu "Jelo" u Form1

                for (int i = 0; i < prilozi.Rows.Count; i++) // Dodavanje priloga za novo jelo u tabelu "Pripadnost" u Form1
                {
                    SourceForm.ds.Pripadnost.Rows.Add(id, Int32.Parse(dataGridView2.Rows[i].Cells[0].Value.ToString()));
                }
                // Resetovanje polja za unos
                numericUpDown1.Value = 0;
                txtIme.Text = "";
                // Očisti DataTable "prilozi"
                prilozi.Clear();
                prilozi1 = SourceForm.ds.Prilog.Copy();  // Kopiranje ponovno dostupnih priloga iz Form1 u prilozi1
            }
            MessageBox.Show("Jelo uspjesno dodato");
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Ukloni izabrani prilog iz prilozi1 i dodaj ga u prilozi
                DataRow rowToRemove = prilozi1.Rows[e.RowIndex];
                prilozi.Rows.Add(Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString()), dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString(), Int32.Parse(dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString()));
                rowToRemove.Delete();
                prilozi1.AcceptChanges();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Ukloni izabrani prilog iz prilozi i dodaj ga nazad u prilozi1
                DataRow rowToRemove = prilozi.Rows[e.RowIndex];
                prilozi1.Rows.Add(Int32.Parse(dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString()), dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString(), Int32.Parse(dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString()));
                rowToRemove.Delete();
                prilozi.AcceptChanges();
            }
        }
    }
}
