﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RT_74_21_Projekat2
{
    public partial class prikaziStatistikuProdaje : Form
    {
        float percent = 0; // Inicijalizacija promenljive za postotak (procenat prodaje)
        public Form1 SourceForm { get; set; } // Referenca na drugu formu (Form1)
        public string najprodavanijeJelo = ""; // Promenljiva za najprodavanije jelo
        public prikaziStatistikuProdaje()
        {
            InitializeComponent();

            this.Paint += FrmStatistickiPrikaz_Paint; // Dodavanje događaja za crtanje grafikona
            this.DoubleBuffered = true; // Podešavanje dvostrukog baferisanja za bolje iscrtavanje
        }

        private void FrmStatistickiPrikaz_Paint(object sender, PaintEventArgs e)  // Metoda za crtanje grafikona
        {
            int radius = Math.Min(this.Width, this.Height) / 3;
            int startAngle = 0;
            int sweepAngle = (int)(percent * 360 / 100);
            using (SolidBrush brush = new SolidBrush(Color.Black))
            {
                e.Graphics.FillPie(brush, 500, 80, radius * 2, radius * 2, 0, 360);
            }
            using (SolidBrush brush = new SolidBrush(Color.Blue))
            {

                e.Graphics.FillPie(brush, 500, 80, radius * 2, radius * 2, startAngle, sweepAngle);
            }
        }

        private void prikaziStatistikuProdaje_Load(object sender, EventArgs e)
        {
            int numberOfJelo = SourceForm.ds.Jelo.Rows.Count;
            int ukupnoProdanih = 0;   // Ukupan broj prodanih jela inicijalizujemo na 0

            DataTable Statistika = new DataTable();
            Statistika.Columns.Add("id_jelo", typeof(int));
            Statistika.Columns.Add("Jelo", typeof(string));
            Statistika.Columns.Add("Kolicina", typeof(int));
            Statistika.Columns.Add("Procenat prodaje", typeof(string));

            dataGridView1.DataSource = SourceForm.ds.Jelo; // Postavljanje izvora podataka za DataGridView na tabelu "Jelo"

            for (int i = 0; i < SourceForm.ds.Jelo.Rows.Count; i++) //inicijalizacija tabele "Statistika" sa početnim vrednostima
            {
                Statistika.Rows.Add(dataGridView1.Rows[i].Cells[0].Value, dataGridView1.Rows[i].Cells[1].Value.ToString(), 0, "0%");
            }
            dataGridView1.DataSource = SourceForm.ds.Stavka_racuna; // Postavljanje izvora podataka za DataGridView na tabelu "Stavka_racuna"

            DataGridView dataGridViewTemp = new DataGridView(); // Kreiranje privremenog DataGridView za manipulaciju podacima
            dataGridViewTemp.DataSource = Statistika;
            Controls.Add(dataGridViewTemp);
            for (int j = 0; j < dataGridViewTemp.Rows.Count - 1; j++) // Ažuriranje količine prodanih jela
            {

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {

                    if (dataGridView1.Rows[i].Cells[1].Value.ToString() == dataGridViewTemp.Rows[j].Cells[0].Value.ToString())
                    {
                        int novaKolicina = Int32.Parse(dataGridView1.Rows[i].Cells[5].Value.ToString()) + Int32.Parse(dataGridViewTemp.Rows[j].Cells[2].Value.ToString());

                        Statistika.Rows[j]["Kolicina"] = novaKolicina;
                        Statistika.AcceptChanges();
                    }
                }
                ukupnoProdanih += Int32.Parse(Statistika.Rows[j]["Kolicina"].ToString());
            }
            if (ukupnoProdanih > 0)  // Računanje procenta prodaje i pronalaženje najprodavanijeg jela
            {
                int max = Int32.Parse(Statistika.Rows[0]["Kolicina"].ToString());
                for (int i = 0; i < dataGridViewTemp.Rows.Count - 1; i++)
                {
                    float procenat = ((Int32.Parse(Statistika.Rows[i][2].ToString()) * 1f) / (ukupnoProdanih * 1f)) * 100f;
                    Statistika.Rows[i][3] = procenat.ToString() + "%";
                    if (Int32.Parse(Statistika.Rows[i]["Kolicina"].ToString()) > max)
                    {
                        max = Int32.Parse(Statistika.Rows[i]["Kolicina"].ToString());
                        najprodavanijeJelo = Statistika.Rows[i][1].ToString();
                    }
                }
            }
            dataGridView1.DataSource = Statistika; // Postavljanje izvora podataka za DataGridView na tabelu "Statistika" i čišćenje privremenog DataGridView
            dataGridViewTemp.Parent.Controls.Remove(dataGridViewTemp);
            dataGridViewTemp.Dispose();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Ponovno iscrtavanje grafikona na osnovu kliknute ćelije u DataGridView-u ideja je bila da automatski ucita ali je pucao program
            this.Invalidate();
            percent = float.Parse(dataGridView1.Rows[e.RowIndex].Cells["Procenat prodaje"].Value.ToString().Substring(0, dataGridView1.Rows[e.RowIndex].Cells["Procenat prodaje"].Value.ToString().Length - 1));
        }
    }
}

