﻿
namespace Projekat1Konacno
{
    partial class JeloForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnUkiniPrilog;
            System.Windows.Forms.Button btnOmoguciPrilog;
            System.Windows.Forms.Button btnUkiniDodatak;
            System.Windows.Forms.Button btnOmoguciDodatak;
            System.Windows.Forms.Button btnDodajJelo;
            System.Windows.Forms.Button btnObrisiJelo;
            System.Windows.Forms.Button button1;
            System.Windows.Forms.Button btnAzurirajOmoguciPrilog;
            System.Windows.Forms.Button btnAzurirajUkiniDodatak;
            System.Windows.Forms.Button btnAzurirajOmoguciDodatak;
            System.Windows.Forms.Button btnSacuvajAzuriranePodatke;
            this.lblDodaciZaJelo = new System.Windows.Forms.Label();
            this.lstbOmoguceniPrilozi = new System.Windows.Forms.ListBox();
            this.lstbOmoguceniDodaci = new System.Windows.Forms.ListBox();
            this.rbtnPrilogNijeObavezan = new System.Windows.Forms.RadioButton();
            this.rbtnObavezanPrilog = new System.Windows.Forms.RadioButton();
            this.lblOmoguceniDodaci = new System.Windows.Forms.Label();
            this.lblOmoguceniPrilozi = new System.Windows.Forms.Label();
            this.cmbDostupniDodaci = new System.Windows.Forms.ComboBox();
            this.cmbDostupniPrilozi = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCenaJela = new System.Windows.Forms.TextBox();
            this.lblCenaJela = new System.Windows.Forms.Label();
            this.lblOpisJela = new System.Windows.Forms.Label();
            this.txtOpisJela = new System.Windows.Forms.TextBox();
            this.txtGramazaJela = new System.Windows.Forms.TextBox();
            this.lblGramazaJela = new System.Windows.Forms.Label();
            this.txtNazivJela = new System.Windows.Forms.TextBox();
            this.lblNazivJela = new System.Windows.Forms.Label();
            this.cmbJeloZaRestoran = new System.Windows.Forms.ComboBox();
            this.lblJeloZaRestoran = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblOdabirJelaZaAzuriranje = new System.Windows.Forms.Label();
            this.cmbOdabirJelaZaAzuriranje = new System.Windows.Forms.ComboBox();
            this.lstbAzuriraniOmoguceniPrilozi = new System.Windows.Forms.ListBox();
            this.lstbAzurirajOmoguceneDodatke = new System.Windows.Forms.ListBox();
            this.rbtAzuriranjePrilogNijeObavezan = new System.Windows.Forms.RadioButton();
            this.lblAzurirajGramazuJela = new System.Windows.Forms.Label();
            this.rbtnAzuriranjeObavezniPrilog = new System.Windows.Forms.RadioButton();
            this.lblAzurirajOmoguceneDodatke = new System.Windows.Forms.Label();
            this.lblAzurirajOmogucenePriloge = new System.Windows.Forms.Label();
            this.cmbAzuriranjeDostupnihDodataka = new System.Windows.Forms.ComboBox();
            this.cmbAzurirajDostupnePriloge = new System.Windows.Forms.ComboBox();
            this.lblAzurirajPriloge = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtAzurirajCenuJela = new System.Windows.Forms.TextBox();
            this.lblAzurirajCenuJela = new System.Windows.Forms.Label();
            this.lblAzurirajOpisJela = new System.Windows.Forms.Label();
            this.txtAzurirajOpisJela = new System.Windows.Forms.TextBox();
            this.txtAzurirajGramazuJela = new System.Windows.Forms.TextBox();
            this.txtAzurirajNazivJela = new System.Windows.Forms.TextBox();
            this.lblAzurirajNazivJela = new System.Windows.Forms.Label();
            this.cmbRestoranZaAzuriranjeJela = new System.Windows.Forms.ComboBox();
            this.lblRestoranUKomJeJeloZaAzuriranje = new System.Windows.Forms.Label();
            btnUkiniPrilog = new System.Windows.Forms.Button();
            btnOmoguciPrilog = new System.Windows.Forms.Button();
            btnUkiniDodatak = new System.Windows.Forms.Button();
            btnOmoguciDodatak = new System.Windows.Forms.Button();
            btnDodajJelo = new System.Windows.Forms.Button();
            btnObrisiJelo = new System.Windows.Forms.Button();
            button1 = new System.Windows.Forms.Button();
            btnAzurirajOmoguciPrilog = new System.Windows.Forms.Button();
            btnAzurirajUkiniDodatak = new System.Windows.Forms.Button();
            btnAzurirajOmoguciDodatak = new System.Windows.Forms.Button();
            btnSacuvajAzuriranePodatke = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnUkiniPrilog
            // 
            btnUkiniPrilog.Location = new System.Drawing.Point(4, 534);
            btnUkiniPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnUkiniPrilog.Name = "btnUkiniPrilog";
            btnUkiniPrilog.Size = new System.Drawing.Size(243, 29);
            btnUkiniPrilog.TabIndex = 56;
            btnUkiniPrilog.Text = "Ukini oznaceni prilog\r\n";
            btnUkiniPrilog.UseVisualStyleBackColor = true;
            btnUkiniPrilog.Click += new System.EventHandler(this.btnUkiniPrilog_Click);
            // 
            // btnOmoguciPrilog
            // 
            btnOmoguciPrilog.Location = new System.Drawing.Point(3, 385);
            btnOmoguciPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnOmoguciPrilog.Name = "btnOmoguciPrilog";
            btnOmoguciPrilog.Size = new System.Drawing.Size(243, 29);
            btnOmoguciPrilog.TabIndex = 55;
            btnOmoguciPrilog.Text = "Omoguci prilog";
            btnOmoguciPrilog.UseVisualStyleBackColor = true;
            btnOmoguciPrilog.Click += new System.EventHandler(this.btnOmoguciPrilog_Click);
            // 
            // btnUkiniDodatak
            // 
            btnUkiniDodatak.Location = new System.Drawing.Point(264, 228);
            btnUkiniDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnUkiniDodatak.Name = "btnUkiniDodatak";
            btnUkiniDodatak.Size = new System.Drawing.Size(243, 29);
            btnUkiniDodatak.TabIndex = 54;
            btnUkiniDodatak.Text = "Ukini oznaceni dodatak";
            btnUkiniDodatak.UseVisualStyleBackColor = true;
            btnUkiniDodatak.Click += new System.EventHandler(this.btnUkiniDodatak_Click);
            // 
            // btnOmoguciDodatak
            // 
            btnOmoguciDodatak.Location = new System.Drawing.Point(264, 84);
            btnOmoguciDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnOmoguciDodatak.Name = "btnOmoguciDodatak";
            btnOmoguciDodatak.Size = new System.Drawing.Size(243, 29);
            btnOmoguciDodatak.TabIndex = 52;
            btnOmoguciDodatak.Text = "Omoguci dodatak";
            btnOmoguciDodatak.UseVisualStyleBackColor = true;
            btnOmoguciDodatak.Click += new System.EventHandler(this.btnOmoguciDodatak_Click);
            // 
            // btnDodajJelo
            // 
            btnDodajJelo.Location = new System.Drawing.Point(264, 261);
            btnDodajJelo.Margin = new System.Windows.Forms.Padding(2);
            btnDodajJelo.Name = "btnDodajJelo";
            btnDodajJelo.Size = new System.Drawing.Size(243, 29);
            btnDodajJelo.TabIndex = 35;
            btnDodajJelo.Text = "Dodaj jelo";
            btnDodajJelo.UseVisualStyleBackColor = true;
            btnDodajJelo.Click += new System.EventHandler(this.btnDodajJelo_Click);
            // 
            // btnObrisiJelo
            // 
            btnObrisiJelo.Location = new System.Drawing.Point(858, 294);
            btnObrisiJelo.Margin = new System.Windows.Forms.Padding(2);
            btnObrisiJelo.Name = "btnObrisiJelo";
            btnObrisiJelo.Size = new System.Drawing.Size(243, 29);
            btnObrisiJelo.TabIndex = 59;
            btnObrisiJelo.Text = "Obrisi jelo";
            btnObrisiJelo.UseVisualStyleBackColor = true;
            btnObrisiJelo.Click += new System.EventHandler(this.btnObrisiJelo_Click);
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(593, 594);
            button1.Margin = new System.Windows.Forms.Padding(2);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(243, 29);
            button1.TabIndex = 56;
            button1.Text = "Ukini oznaceni prilog\r\n";
            button1.UseVisualStyleBackColor = true;
            button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnAzurirajOmoguciPrilog
            // 
            btnAzurirajOmoguciPrilog.Location = new System.Drawing.Point(592, 445);
            btnAzurirajOmoguciPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnAzurirajOmoguciPrilog.Name = "btnAzurirajOmoguciPrilog";
            btnAzurirajOmoguciPrilog.Size = new System.Drawing.Size(243, 29);
            btnAzurirajOmoguciPrilog.TabIndex = 55;
            btnAzurirajOmoguciPrilog.Text = "Omoguci prilog";
            btnAzurirajOmoguciPrilog.UseVisualStyleBackColor = true;
            btnAzurirajOmoguciPrilog.Click += new System.EventHandler(this.btnAzurirajOmoguciPrilog_Click);
            // 
            // btnAzurirajUkiniDodatak
            // 
            btnAzurirajUkiniDodatak.Location = new System.Drawing.Point(859, 228);
            btnAzurirajUkiniDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnAzurirajUkiniDodatak.Name = "btnAzurirajUkiniDodatak";
            btnAzurirajUkiniDodatak.Size = new System.Drawing.Size(243, 29);
            btnAzurirajUkiniDodatak.TabIndex = 54;
            btnAzurirajUkiniDodatak.Text = "Ukini oznaceni dodatak";
            btnAzurirajUkiniDodatak.UseVisualStyleBackColor = true;
            btnAzurirajUkiniDodatak.Click += new System.EventHandler(this.btnAzurirajUkiniDodatak_Click);
            // 
            // btnAzurirajOmoguciDodatak
            // 
            btnAzurirajOmoguciDodatak.Location = new System.Drawing.Point(859, 84);
            btnAzurirajOmoguciDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnAzurirajOmoguciDodatak.Name = "btnAzurirajOmoguciDodatak";
            btnAzurirajOmoguciDodatak.Size = new System.Drawing.Size(243, 29);
            btnAzurirajOmoguciDodatak.TabIndex = 52;
            btnAzurirajOmoguciDodatak.Text = "Omoguci dodatak";
            btnAzurirajOmoguciDodatak.UseVisualStyleBackColor = true;
            btnAzurirajOmoguciDodatak.Click += new System.EventHandler(this.btnAzurirajOmoguciDodatak_Click);
            // 
            // btnSacuvajAzuriranePodatke
            // 
            btnSacuvajAzuriranePodatke.Location = new System.Drawing.Point(860, 261);
            btnSacuvajAzuriranePodatke.Margin = new System.Windows.Forms.Padding(2);
            btnSacuvajAzuriranePodatke.Name = "btnSacuvajAzuriranePodatke";
            btnSacuvajAzuriranePodatke.Size = new System.Drawing.Size(243, 29);
            btnSacuvajAzuriranePodatke.TabIndex = 35;
            btnSacuvajAzuriranePodatke.Text = "Sacuvaj izmene";
            btnSacuvajAzuriranePodatke.UseVisualStyleBackColor = true;
            btnSacuvajAzuriranePodatke.Click += new System.EventHandler(this.btnSacuvajAzuriranePodatke_Click);
            // 
            // lblDodaciZaJelo
            // 
            this.lblDodaciZaJelo.AutoSize = true;
            this.lblDodaciZaJelo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDodaciZaJelo.Location = new System.Drawing.Point(261, 36);
            this.lblDodaciZaJelo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDodaciZaJelo.Name = "lblDodaciZaJelo";
            this.lblDodaciZaJelo.Size = new System.Drawing.Size(254, 17);
            this.lblDodaciZaJelo.TabIndex = 57;
            this.lblDodaciZaJelo.Text = "Dodavanje dostupnih dodataka za jelo:";
            // 
            // lstbOmoguceniPrilozi
            // 
            this.lstbOmoguceniPrilozi.FormattingEnabled = true;
            this.lstbOmoguceniPrilozi.Location = new System.Drawing.Point(3, 435);
            this.lstbOmoguceniPrilozi.Margin = new System.Windows.Forms.Padding(2);
            this.lstbOmoguceniPrilozi.Name = "lstbOmoguceniPrilozi";
            this.lstbOmoguceniPrilozi.Size = new System.Drawing.Size(244, 95);
            this.lstbOmoguceniPrilozi.TabIndex = 53;
            // 
            // lstbOmoguceniDodaci
            // 
            this.lstbOmoguceniDodaci.FormattingEnabled = true;
            this.lstbOmoguceniDodaci.Location = new System.Drawing.Point(264, 129);
            this.lstbOmoguceniDodaci.Margin = new System.Windows.Forms.Padding(2);
            this.lstbOmoguceniDodaci.Name = "lstbOmoguceniDodaci";
            this.lstbOmoguceniDodaci.Size = new System.Drawing.Size(244, 95);
            this.lstbOmoguceniDodaci.TabIndex = 39;
            // 
            // rbtnPrilogNijeObavezan
            // 
            this.rbtnPrilogNijeObavezan.AutoSize = true;
            this.rbtnPrilogNijeObavezan.Location = new System.Drawing.Point(119, 567);
            this.rbtnPrilogNijeObavezan.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnPrilogNijeObavezan.Name = "rbtnPrilogNijeObavezan";
            this.rbtnPrilogNijeObavezan.Size = new System.Drawing.Size(120, 17);
            this.rbtnPrilogNijeObavezan.TabIndex = 51;
            this.rbtnPrilogNijeObavezan.TabStop = true;
            this.rbtnPrilogNijeObavezan.Text = "Prilog nije obavezan";
            this.rbtnPrilogNijeObavezan.UseVisualStyleBackColor = true;
            // 
            // rbtnObavezanPrilog
            // 
            this.rbtnObavezanPrilog.AutoSize = true;
            this.rbtnObavezanPrilog.Location = new System.Drawing.Point(4, 567);
            this.rbtnObavezanPrilog.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnObavezanPrilog.Name = "rbtnObavezanPrilog";
            this.rbtnObavezanPrilog.Size = new System.Drawing.Size(112, 17);
            this.rbtnObavezanPrilog.TabIndex = 50;
            this.rbtnObavezanPrilog.TabStop = true;
            this.rbtnObavezanPrilog.Text = "Prilog je obavezan";
            this.rbtnObavezanPrilog.UseVisualStyleBackColor = true;
            // 
            // lblOmoguceniDodaci
            // 
            this.lblOmoguceniDodaci.AutoSize = true;
            this.lblOmoguceniDodaci.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOmoguceniDodaci.Location = new System.Drawing.Point(263, 110);
            this.lblOmoguceniDodaci.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOmoguceniDodaci.Name = "lblOmoguceniDodaci";
            this.lblOmoguceniDodaci.Size = new System.Drawing.Size(130, 17);
            this.lblOmoguceniDodaci.TabIndex = 49;
            this.lblOmoguceniDodaci.Text = "Omoguceni dodaci:";
            // 
            // lblOmoguceniPrilozi
            // 
            this.lblOmoguceniPrilozi.AutoSize = true;
            this.lblOmoguceniPrilozi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOmoguceniPrilozi.Location = new System.Drawing.Point(1, 416);
            this.lblOmoguceniPrilozi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOmoguceniPrilozi.Name = "lblOmoguceniPrilozi";
            this.lblOmoguceniPrilozi.Size = new System.Drawing.Size(125, 17);
            this.lblOmoguceniPrilozi.TabIndex = 45;
            this.lblOmoguceniPrilozi.Text = "Omoguceni prilozi:";
            // 
            // cmbDostupniDodaci
            // 
            this.cmbDostupniDodaci.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDostupniDodaci.FormattingEnabled = true;
            this.cmbDostupniDodaci.Location = new System.Drawing.Point(264, 55);
            this.cmbDostupniDodaci.Margin = new System.Windows.Forms.Padding(2);
            this.cmbDostupniDodaci.Name = "cmbDostupniDodaci";
            this.cmbDostupniDodaci.Size = new System.Drawing.Size(244, 25);
            this.cmbDostupniDodaci.TabIndex = 47;
            this.cmbDostupniDodaci.SelectedIndexChanged += new System.EventHandler(this.cmbDostupniDodaci_SelectedIndexChanged);
            // 
            // cmbDostupniPrilozi
            // 
            this.cmbDostupniPrilozi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDostupniPrilozi.FormattingEnabled = true;
            this.cmbDostupniPrilozi.Location = new System.Drawing.Point(4, 356);
            this.cmbDostupniPrilozi.Margin = new System.Windows.Forms.Padding(2);
            this.cmbDostupniPrilozi.Name = "cmbDostupniPrilozi";
            this.cmbDostupniPrilozi.Size = new System.Drawing.Size(244, 25);
            this.cmbDostupniPrilozi.TabIndex = 43;
            this.cmbDostupniPrilozi.SelectedIndexChanged += new System.EventHandler(this.cmbDostupniPrilozi_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1, 337);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(238, 17);
            this.label4.TabIndex = 42;
            this.label4.Text = "Dodavanje priloga dostupnih za jelo:";
            // 
            // txtCenaJela
            // 
            this.txtCenaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCenaJela.Location = new System.Drawing.Point(2, 309);
            this.txtCenaJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtCenaJela.Name = "txtCenaJela";
            this.txtCenaJela.Size = new System.Drawing.Size(244, 26);
            this.txtCenaJela.TabIndex = 41;
            // 
            // lblCenaJela
            // 
            this.lblCenaJela.AutoSize = true;
            this.lblCenaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCenaJela.Location = new System.Drawing.Point(1, 290);
            this.lblCenaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCenaJela.Name = "lblCenaJela";
            this.lblCenaJela.Size = new System.Drawing.Size(71, 17);
            this.lblCenaJela.TabIndex = 40;
            this.lblCenaJela.Text = "Cena jela:";
            // 
            // lblOpisJela
            // 
            this.lblOpisJela.AutoSize = true;
            this.lblOpisJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpisJela.Location = new System.Drawing.Point(-1, 176);
            this.lblOpisJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOpisJela.Name = "lblOpisJela";
            this.lblOpisJela.Size = new System.Drawing.Size(67, 17);
            this.lblOpisJela.TabIndex = 39;
            this.lblOpisJela.Text = "Opis jela:";
            // 
            // txtOpisJela
            // 
            this.txtOpisJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOpisJela.Location = new System.Drawing.Point(2, 195);
            this.txtOpisJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtOpisJela.Multiline = true;
            this.txtOpisJela.Name = "txtOpisJela";
            this.txtOpisJela.Size = new System.Drawing.Size(244, 93);
            this.txtOpisJela.TabIndex = 35;
            // 
            // txtGramazaJela
            // 
            this.txtGramazaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramazaJela.Location = new System.Drawing.Point(2, 148);
            this.txtGramazaJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtGramazaJela.Name = "txtGramazaJela";
            this.txtGramazaJela.Size = new System.Drawing.Size(244, 26);
            this.txtGramazaJela.TabIndex = 35;
            // 
            // lblGramazaJela
            // 
            this.lblGramazaJela.AutoSize = true;
            this.lblGramazaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGramazaJela.Location = new System.Drawing.Point(-1, 129);
            this.lblGramazaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGramazaJela.Name = "lblGramazaJela";
            this.lblGramazaJela.Size = new System.Drawing.Size(96, 17);
            this.lblGramazaJela.TabIndex = 38;
            this.lblGramazaJela.Text = "Gramaza jela:";
            // 
            // txtNazivJela
            // 
            this.txtNazivJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazivJela.Location = new System.Drawing.Point(2, 101);
            this.txtNazivJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtNazivJela.Name = "txtNazivJela";
            this.txtNazivJela.Size = new System.Drawing.Size(244, 26);
            this.txtNazivJela.TabIndex = 35;
            // 
            // lblNazivJela
            // 
            this.lblNazivJela.AutoSize = true;
            this.lblNazivJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNazivJela.Location = new System.Drawing.Point(-1, 82);
            this.lblNazivJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNazivJela.Name = "lblNazivJela";
            this.lblNazivJela.Size = new System.Drawing.Size(73, 17);
            this.lblNazivJela.TabIndex = 37;
            this.lblNazivJela.Text = "Naziv jela:";
            // 
            // cmbJeloZaRestoran
            // 
            this.cmbJeloZaRestoran.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbJeloZaRestoran.FormattingEnabled = true;
            this.cmbJeloZaRestoran.Location = new System.Drawing.Point(2, 55);
            this.cmbJeloZaRestoran.Margin = new System.Windows.Forms.Padding(2);
            this.cmbJeloZaRestoran.Name = "cmbJeloZaRestoran";
            this.cmbJeloZaRestoran.Size = new System.Drawing.Size(244, 25);
            this.cmbJeloZaRestoran.TabIndex = 36;
            this.cmbJeloZaRestoran.SelectedIndexChanged += new System.EventHandler(this.cmbJeloZaRestoran_SelectedIndexChanged);
            // 
            // lblJeloZaRestoran
            // 
            this.lblJeloZaRestoran.AutoSize = true;
            this.lblJeloZaRestoran.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJeloZaRestoran.Location = new System.Drawing.Point(-1, 36);
            this.lblJeloZaRestoran.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblJeloZaRestoran.Name = "lblJeloZaRestoran";
            this.lblJeloZaRestoran.Size = new System.Drawing.Size(216, 17);
            this.lblJeloZaRestoran.TabIndex = 0;
            this.lblJeloZaRestoran.Text = "Restoran u kom je jelo dostupno:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(80, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 17);
            this.label1.TabIndex = 40;
            this.label1.Text = "Dodaj jelo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(797, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 17);
            this.label2.TabIndex = 58;
            this.label2.Text = "Azuriraj jelo:";
            // 
            // lblOdabirJelaZaAzuriranje
            // 
            this.lblOdabirJelaZaAzuriranje.AutoSize = true;
            this.lblOdabirJelaZaAzuriranje.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabirJelaZaAzuriranje.Location = new System.Drawing.Point(589, 82);
            this.lblOdabirJelaZaAzuriranje.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabirJelaZaAzuriranje.Name = "lblOdabirJelaZaAzuriranje";
            this.lblOdabirJelaZaAzuriranje.Size = new System.Drawing.Size(81, 17);
            this.lblOdabirJelaZaAzuriranje.TabIndex = 32;
            this.lblOdabirJelaZaAzuriranje.Text = "Odabir jela:";
            // 
            // cmbOdabirJelaZaAzuriranje
            // 
            this.cmbOdabirJelaZaAzuriranje.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOdabirJelaZaAzuriranje.FormattingEnabled = true;
            this.cmbOdabirJelaZaAzuriranje.Location = new System.Drawing.Point(592, 101);
            this.cmbOdabirJelaZaAzuriranje.Margin = new System.Windows.Forms.Padding(2);
            this.cmbOdabirJelaZaAzuriranje.Name = "cmbOdabirJelaZaAzuriranje";
            this.cmbOdabirJelaZaAzuriranje.Size = new System.Drawing.Size(244, 25);
            this.cmbOdabirJelaZaAzuriranje.TabIndex = 32;
            this.cmbOdabirJelaZaAzuriranje.SelectedIndexChanged += new System.EventHandler(this.cmbOdabirJelaZaAzuriranje_SelectedIndexChanged);
            // 
            // lstbAzuriraniOmoguceniPrilozi
            // 
            this.lstbAzuriraniOmoguceniPrilozi.FormattingEnabled = true;
            this.lstbAzuriraniOmoguceniPrilozi.Location = new System.Drawing.Point(594, 495);
            this.lstbAzuriraniOmoguceniPrilozi.Margin = new System.Windows.Forms.Padding(2);
            this.lstbAzuriraniOmoguceniPrilozi.Name = "lstbAzuriraniOmoguceniPrilozi";
            this.lstbAzuriraniOmoguceniPrilozi.Size = new System.Drawing.Size(244, 95);
            this.lstbAzuriraniOmoguceniPrilozi.TabIndex = 53;
            this.lstbAzuriraniOmoguceniPrilozi.SelectedIndexChanged += new System.EventHandler(this.lstbAzuriraniOmoguceniPrilozi_SelectedIndexChanged);
            // 
            // lstbAzurirajOmoguceneDodatke
            // 
            this.lstbAzurirajOmoguceneDodatke.FormattingEnabled = true;
            this.lstbAzurirajOmoguceneDodatke.Location = new System.Drawing.Point(858, 129);
            this.lstbAzurirajOmoguceneDodatke.Margin = new System.Windows.Forms.Padding(2);
            this.lstbAzurirajOmoguceneDodatke.Name = "lstbAzurirajOmoguceneDodatke";
            this.lstbAzurirajOmoguceneDodatke.Size = new System.Drawing.Size(244, 95);
            this.lstbAzurirajOmoguceneDodatke.TabIndex = 39;
            // 
            // rbtAzuriranjePrilogNijeObavezan
            // 
            this.rbtAzuriranjePrilogNijeObavezan.AutoSize = true;
            this.rbtAzuriranjePrilogNijeObavezan.Location = new System.Drawing.Point(718, 627);
            this.rbtAzuriranjePrilogNijeObavezan.Margin = new System.Windows.Forms.Padding(2);
            this.rbtAzuriranjePrilogNijeObavezan.Name = "rbtAzuriranjePrilogNijeObavezan";
            this.rbtAzuriranjePrilogNijeObavezan.Size = new System.Drawing.Size(120, 17);
            this.rbtAzuriranjePrilogNijeObavezan.TabIndex = 51;
            this.rbtAzuriranjePrilogNijeObavezan.TabStop = true;
            this.rbtAzuriranjePrilogNijeObavezan.Text = "Prilog nije obavezan";
            this.rbtAzuriranjePrilogNijeObavezan.UseVisualStyleBackColor = true;
            this.rbtAzuriranjePrilogNijeObavezan.CheckedChanged += new System.EventHandler(this.rbtAzuriranjePrilogNijeObavezan_CheckedChanged);
            // 
            // lblAzurirajGramazuJela
            // 
            this.lblAzurirajGramazuJela.AutoSize = true;
            this.lblAzurirajGramazuJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajGramazuJela.Location = new System.Drawing.Point(589, 176);
            this.lblAzurirajGramazuJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajGramazuJela.Name = "lblAzurirajGramazuJela";
            this.lblAzurirajGramazuJela.Size = new System.Drawing.Size(96, 17);
            this.lblAzurirajGramazuJela.TabIndex = 38;
            this.lblAzurirajGramazuJela.Text = "Gramaza jela:";
            // 
            // rbtnAzuriranjeObavezniPrilog
            // 
            this.rbtnAzuriranjeObavezniPrilog.AutoSize = true;
            this.rbtnAzuriranjeObavezniPrilog.Location = new System.Drawing.Point(592, 627);
            this.rbtnAzuriranjeObavezniPrilog.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnAzuriranjeObavezniPrilog.Name = "rbtnAzuriranjeObavezniPrilog";
            this.rbtnAzuriranjeObavezniPrilog.Size = new System.Drawing.Size(112, 17);
            this.rbtnAzuriranjeObavezniPrilog.TabIndex = 50;
            this.rbtnAzuriranjeObavezniPrilog.TabStop = true;
            this.rbtnAzuriranjeObavezniPrilog.Text = "Prilog je obavezan";
            this.rbtnAzuriranjeObavezniPrilog.UseVisualStyleBackColor = true;
            this.rbtnAzuriranjeObavezniPrilog.CheckedChanged += new System.EventHandler(this.rbtnAzuriranjeObavezniPrilog_CheckedChanged);
            // 
            // lblAzurirajOmoguceneDodatke
            // 
            this.lblAzurirajOmoguceneDodatke.AutoSize = true;
            this.lblAzurirajOmoguceneDodatke.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajOmoguceneDodatke.Location = new System.Drawing.Point(856, 110);
            this.lblAzurirajOmoguceneDodatke.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajOmoguceneDodatke.Name = "lblAzurirajOmoguceneDodatke";
            this.lblAzurirajOmoguceneDodatke.Size = new System.Drawing.Size(130, 17);
            this.lblAzurirajOmoguceneDodatke.TabIndex = 49;
            this.lblAzurirajOmoguceneDodatke.Text = "Omoguceni dodaci:";
            // 
            // lblAzurirajOmogucenePriloge
            // 
            this.lblAzurirajOmogucenePriloge.AutoSize = true;
            this.lblAzurirajOmogucenePriloge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajOmogucenePriloge.Location = new System.Drawing.Point(591, 476);
            this.lblAzurirajOmogucenePriloge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajOmogucenePriloge.Name = "lblAzurirajOmogucenePriloge";
            this.lblAzurirajOmogucenePriloge.Size = new System.Drawing.Size(125, 17);
            this.lblAzurirajOmogucenePriloge.TabIndex = 45;
            this.lblAzurirajOmogucenePriloge.Text = "Omoguceni prilozi:";
            // 
            // cmbAzuriranjeDostupnihDodataka
            // 
            this.cmbAzuriranjeDostupnihDodataka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAzuriranjeDostupnihDodataka.FormattingEnabled = true;
            this.cmbAzuriranjeDostupnihDodataka.Location = new System.Drawing.Point(859, 55);
            this.cmbAzuriranjeDostupnihDodataka.Margin = new System.Windows.Forms.Padding(2);
            this.cmbAzuriranjeDostupnihDodataka.Name = "cmbAzuriranjeDostupnihDodataka";
            this.cmbAzuriranjeDostupnihDodataka.Size = new System.Drawing.Size(244, 25);
            this.cmbAzuriranjeDostupnihDodataka.TabIndex = 47;
            this.cmbAzuriranjeDostupnihDodataka.SelectedIndexChanged += new System.EventHandler(this.cmbAzuriranjeDostupnihDodataka_SelectedIndexChanged);
            // 
            // cmbAzurirajDostupnePriloge
            // 
            this.cmbAzurirajDostupnePriloge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAzurirajDostupnePriloge.FormattingEnabled = true;
            this.cmbAzurirajDostupnePriloge.Location = new System.Drawing.Point(592, 416);
            this.cmbAzurirajDostupnePriloge.Margin = new System.Windows.Forms.Padding(2);
            this.cmbAzurirajDostupnePriloge.Name = "cmbAzurirajDostupnePriloge";
            this.cmbAzurirajDostupnePriloge.Size = new System.Drawing.Size(244, 25);
            this.cmbAzurirajDostupnePriloge.TabIndex = 43;
            this.cmbAzurirajDostupnePriloge.SelectedIndexChanged += new System.EventHandler(this.cmbAzurirajDostupnePriloge_SelectedIndexChanged);
            // 
            // lblAzurirajPriloge
            // 
            this.lblAzurirajPriloge.AutoSize = true;
            this.lblAzurirajPriloge.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajPriloge.Location = new System.Drawing.Point(591, 397);
            this.lblAzurirajPriloge.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajPriloge.Name = "lblAzurirajPriloge";
            this.lblAzurirajPriloge.Size = new System.Drawing.Size(238, 17);
            this.lblAzurirajPriloge.TabIndex = 42;
            this.lblAzurirajPriloge.Text = "Dodavanje priloga dostupnih za jelo:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(856, 36);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(254, 17);
            this.label9.TabIndex = 46;
            this.label9.Text = "Dodavanje dodataka dostupnih za jelo:";
            // 
            // txtAzurirajCenuJela
            // 
            this.txtAzurirajCenuJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajCenuJela.Location = new System.Drawing.Point(592, 366);
            this.txtAzurirajCenuJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajCenuJela.Name = "txtAzurirajCenuJela";
            this.txtAzurirajCenuJela.Size = new System.Drawing.Size(244, 26);
            this.txtAzurirajCenuJela.TabIndex = 41;
            // 
            // lblAzurirajCenuJela
            // 
            this.lblAzurirajCenuJela.AutoSize = true;
            this.lblAzurirajCenuJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajCenuJela.Location = new System.Drawing.Point(591, 343);
            this.lblAzurirajCenuJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajCenuJela.Name = "lblAzurirajCenuJela";
            this.lblAzurirajCenuJela.Size = new System.Drawing.Size(71, 17);
            this.lblAzurirajCenuJela.TabIndex = 40;
            this.lblAzurirajCenuJela.Text = "Cena jela:";
            // 
            // lblAzurirajOpisJela
            // 
            this.lblAzurirajOpisJela.AutoSize = true;
            this.lblAzurirajOpisJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajOpisJela.Location = new System.Drawing.Point(589, 228);
            this.lblAzurirajOpisJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajOpisJela.Name = "lblAzurirajOpisJela";
            this.lblAzurirajOpisJela.Size = new System.Drawing.Size(67, 17);
            this.lblAzurirajOpisJela.TabIndex = 39;
            this.lblAzurirajOpisJela.Text = "Opis jela:";
            // 
            // txtAzurirajOpisJela
            // 
            this.txtAzurirajOpisJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajOpisJela.Location = new System.Drawing.Point(592, 247);
            this.txtAzurirajOpisJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajOpisJela.Multiline = true;
            this.txtAzurirajOpisJela.Name = "txtAzurirajOpisJela";
            this.txtAzurirajOpisJela.Size = new System.Drawing.Size(244, 93);
            this.txtAzurirajOpisJela.TabIndex = 35;
            // 
            // txtAzurirajGramazuJela
            // 
            this.txtAzurirajGramazuJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajGramazuJela.Location = new System.Drawing.Point(592, 198);
            this.txtAzurirajGramazuJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajGramazuJela.Name = "txtAzurirajGramazuJela";
            this.txtAzurirajGramazuJela.Size = new System.Drawing.Size(244, 26);
            this.txtAzurirajGramazuJela.TabIndex = 35;
            // 
            // txtAzurirajNazivJela
            // 
            this.txtAzurirajNazivJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajNazivJela.Location = new System.Drawing.Point(592, 148);
            this.txtAzurirajNazivJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajNazivJela.Name = "txtAzurirajNazivJela";
            this.txtAzurirajNazivJela.Size = new System.Drawing.Size(244, 26);
            this.txtAzurirajNazivJela.TabIndex = 35;
            // 
            // lblAzurirajNazivJela
            // 
            this.lblAzurirajNazivJela.AutoSize = true;
            this.lblAzurirajNazivJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajNazivJela.Location = new System.Drawing.Point(589, 128);
            this.lblAzurirajNazivJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajNazivJela.Name = "lblAzurirajNazivJela";
            this.lblAzurirajNazivJela.Size = new System.Drawing.Size(73, 17);
            this.lblAzurirajNazivJela.TabIndex = 37;
            this.lblAzurirajNazivJela.Text = "Naziv jela:";
            // 
            // cmbRestoranZaAzuriranjeJela
            // 
            this.cmbRestoranZaAzuriranjeJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbRestoranZaAzuriranjeJela.FormattingEnabled = true;
            this.cmbRestoranZaAzuriranjeJela.Location = new System.Drawing.Point(592, 55);
            this.cmbRestoranZaAzuriranjeJela.Margin = new System.Windows.Forms.Padding(2);
            this.cmbRestoranZaAzuriranjeJela.Name = "cmbRestoranZaAzuriranjeJela";
            this.cmbRestoranZaAzuriranjeJela.Size = new System.Drawing.Size(244, 25);
            this.cmbRestoranZaAzuriranjeJela.TabIndex = 36;
            this.cmbRestoranZaAzuriranjeJela.SelectedIndexChanged += new System.EventHandler(this.cmbRestoranZaAzuriranjeJela_SelectedIndexChanged);
            // 
            // lblRestoranUKomJeJeloZaAzuriranje
            // 
            this.lblRestoranUKomJeJeloZaAzuriranje.AutoSize = true;
            this.lblRestoranUKomJeJeloZaAzuriranje.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRestoranUKomJeJeloZaAzuriranje.Location = new System.Drawing.Point(589, 36);
            this.lblRestoranUKomJeJeloZaAzuriranje.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblRestoranUKomJeJeloZaAzuriranje.Name = "lblRestoranUKomJeJeloZaAzuriranje";
            this.lblRestoranUKomJeJeloZaAzuriranje.Size = new System.Drawing.Size(216, 17);
            this.lblRestoranUKomJeJeloZaAzuriranje.TabIndex = 0;
            this.lblRestoranUKomJeJeloZaAzuriranje.Text = "Restoran u kom je jelo dostupno:";
            // 
            // JeloForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1142, 716);
            this.Controls.Add(btnObrisiJelo);
            this.Controls.Add(btnSacuvajAzuriranePodatke);
            this.Controls.Add(btnAzurirajUkiniDodatak);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lstbAzurirajOmoguceneDodatke);
            this.Controls.Add(button1);
            this.Controls.Add(btnAzurirajOmoguciDodatak);
            this.Controls.Add(this.cmbOdabirJelaZaAzuriranje);
            this.Controls.Add(btnAzurirajOmoguciPrilog);
            this.Controls.Add(this.lblAzurirajOmoguceneDodatke);
            this.Controls.Add(this.lstbAzuriraniOmoguceniPrilozi);
            this.Controls.Add(this.cmbAzuriranjeDostupnihDodataka);
            this.Controls.Add(this.rbtAzuriranjePrilogNijeObavezan);
            this.Controls.Add(this.lblOdabirJelaZaAzuriranje);
            this.Controls.Add(this.rbtnAzuriranjeObavezniPrilog);
            this.Controls.Add(btnDodajJelo);
            this.Controls.Add(btnUkiniDodatak);
            this.Controls.Add(this.lblDodaciZaJelo);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.lstbOmoguceniDodaci);
            this.Controls.Add(this.label1);
            this.Controls.Add(btnOmoguciDodatak);
            this.Controls.Add(this.lblAzurirajOmogucenePriloge);
            this.Controls.Add(this.lblAzurirajGramazuJela);
            this.Controls.Add(btnUkiniPrilog);
            this.Controls.Add(this.lblOmoguceniDodaci);
            this.Controls.Add(btnOmoguciPrilog);
            this.Controls.Add(this.cmbAzurirajDostupnePriloge);
            this.Controls.Add(this.cmbDostupniDodaci);
            this.Controls.Add(this.lblAzurirajPriloge);
            this.Controls.Add(this.lstbOmoguceniPrilozi);
            this.Controls.Add(this.rbtnPrilogNijeObavezan);
            this.Controls.Add(this.txtAzurirajCenuJela);
            this.Controls.Add(this.lblJeloZaRestoran);
            this.Controls.Add(this.lblAzurirajCenuJela);
            this.Controls.Add(this.rbtnObavezanPrilog);
            this.Controls.Add(this.txtAzurirajOpisJela);
            this.Controls.Add(this.lblAzurirajOpisJela);
            this.Controls.Add(this.cmbJeloZaRestoran);
            this.Controls.Add(this.lblNazivJela);
            this.Controls.Add(this.txtAzurirajGramazuJela);
            this.Controls.Add(this.txtNazivJela);
            this.Controls.Add(this.lblGramazaJela);
            this.Controls.Add(this.txtGramazaJela);
            this.Controls.Add(this.txtAzurirajNazivJela);
            this.Controls.Add(this.lblOpisJela);
            this.Controls.Add(this.lblAzurirajNazivJela);
            this.Controls.Add(this.lblOmoguceniPrilozi);
            this.Controls.Add(this.txtOpisJela);
            this.Controls.Add(this.lblCenaJela);
            this.Controls.Add(this.txtCenaJela);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbRestoranZaAzuriranjeJela);
            this.Controls.Add(this.cmbDostupniPrilozi);
            this.Controls.Add(this.lblRestoranUKomJeJeloZaAzuriranje);
            this.Name = "JeloForma";
            this.Text = "JeloForma";
            this.Load += new System.EventHandler(this.JeloForma_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblDodaciZaJelo;
        private System.Windows.Forms.ListBox lstbOmoguceniPrilozi;
        private System.Windows.Forms.ListBox lstbOmoguceniDodaci;
        private System.Windows.Forms.RadioButton rbtnPrilogNijeObavezan;
        private System.Windows.Forms.RadioButton rbtnObavezanPrilog;
        private System.Windows.Forms.Label lblOmoguceniDodaci;
        private System.Windows.Forms.Label lblOmoguceniPrilozi;
        private System.Windows.Forms.ComboBox cmbDostupniDodaci;
        private System.Windows.Forms.ComboBox cmbDostupniPrilozi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCenaJela;
        private System.Windows.Forms.Label lblCenaJela;
        private System.Windows.Forms.Label lblOpisJela;
        private System.Windows.Forms.TextBox txtOpisJela;
        private System.Windows.Forms.TextBox txtGramazaJela;
        private System.Windows.Forms.Label lblGramazaJela;
        private System.Windows.Forms.TextBox txtNazivJela;
        private System.Windows.Forms.Label lblNazivJela;
        private System.Windows.Forms.ComboBox cmbJeloZaRestoran;
        private System.Windows.Forms.Label lblJeloZaRestoran;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblOdabirJelaZaAzuriranje;
        private System.Windows.Forms.ComboBox cmbOdabirJelaZaAzuriranje;
        private System.Windows.Forms.ListBox lstbAzuriraniOmoguceniPrilozi;
        private System.Windows.Forms.ListBox lstbAzurirajOmoguceneDodatke;
        private System.Windows.Forms.RadioButton rbtAzuriranjePrilogNijeObavezan;
        private System.Windows.Forms.Label lblAzurirajGramazuJela;
        private System.Windows.Forms.RadioButton rbtnAzuriranjeObavezniPrilog;
        private System.Windows.Forms.Label lblAzurirajOmoguceneDodatke;
        private System.Windows.Forms.Label lblAzurirajOmogucenePriloge;
        private System.Windows.Forms.ComboBox cmbAzuriranjeDostupnihDodataka;
        private System.Windows.Forms.ComboBox cmbAzurirajDostupnePriloge;
        private System.Windows.Forms.Label lblAzurirajPriloge;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAzurirajCenuJela;
        private System.Windows.Forms.Label lblAzurirajCenuJela;
        private System.Windows.Forms.Label lblAzurirajOpisJela;
        private System.Windows.Forms.TextBox txtAzurirajOpisJela;
        private System.Windows.Forms.TextBox txtAzurirajGramazuJela;
        private System.Windows.Forms.TextBox txtAzurirajNazivJela;
        private System.Windows.Forms.Label lblAzurirajNazivJela;
        private System.Windows.Forms.ComboBox cmbRestoranZaAzuriranjeJela;
        private System.Windows.Forms.Label lblRestoranUKomJeJeloZaAzuriranje;
    }
}