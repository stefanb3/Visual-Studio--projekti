﻿
namespace Projekat1Konacno
{
    partial class PriloziForma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnObrisiPrilog;
            System.Windows.Forms.Button btnAzurirajPrilog;
            System.Windows.Forms.Button btnDodajPrilog;
            this.label3 = new System.Windows.Forms.Label();
            this.cmbOdabirPriloga = new System.Windows.Forms.ComboBox();
            this.lblAzurirajCenu = new System.Windows.Forms.Label();
            this.lblAzurirajNaziv = new System.Windows.Forms.Label();
            this.txtAzurirajCenuPriloga = new System.Windows.Forms.TextBox();
            this.txtAzurirajNazivPriloga = new System.Windows.Forms.TextBox();
            this.lblCenaPriloga = new System.Windows.Forms.Label();
            this.lblNazivPriloga = new System.Windows.Forms.Label();
            this.txtCenaPriloga = new System.Windows.Forms.TextBox();
            this.txtNazivPriloga = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            btnObrisiPrilog = new System.Windows.Forms.Button();
            btnAzurirajPrilog = new System.Windows.Forms.Button();
            btnDodajPrilog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnObrisiPrilog
            // 
            btnObrisiPrilog.Location = new System.Drawing.Point(266, 215);
            btnObrisiPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnObrisiPrilog.Name = "btnObrisiPrilog";
            btnObrisiPrilog.Size = new System.Drawing.Size(196, 29);
            btnObrisiPrilog.TabIndex = 34;
            btnObrisiPrilog.Text = "Obrisi prilog";
            btnObrisiPrilog.UseVisualStyleBackColor = true;
            btnObrisiPrilog.Click += new System.EventHandler(this.btnObrisiPrilog_Click);
            // 
            // btnAzurirajPrilog
            // 
            btnAzurirajPrilog.Location = new System.Drawing.Point(266, 182);
            btnAzurirajPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnAzurirajPrilog.Name = "btnAzurirajPrilog";
            btnAzurirajPrilog.Size = new System.Drawing.Size(196, 29);
            btnAzurirajPrilog.TabIndex = 32;
            btnAzurirajPrilog.Text = "Sacuvaj izmene";
            btnAzurirajPrilog.UseVisualStyleBackColor = true;
            btnAzurirajPrilog.Click += new System.EventHandler(this.btnAzurirajPrilog_Click);
            // 
            // btnDodajPrilog
            // 
            btnDodajPrilog.Location = new System.Drawing.Point(11, 133);
            btnDodajPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnDodajPrilog.Name = "btnDodajPrilog";
            btnDodajPrilog.Size = new System.Drawing.Size(196, 29);
            btnDodajPrilog.TabIndex = 32;
            btnDodajPrilog.Text = "Dodaj prilog";
            btnDodajPrilog.UseVisualStyleBackColor = true;
            btnDodajPrilog.Click += new System.EventHandler(this.btnDodajPrilog_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(264, 37);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 17);
            this.label3.TabIndex = 33;
            this.label3.Text = "Odabir priloga:";
            // 
            // cmbOdabirPriloga
            // 
            this.cmbOdabirPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOdabirPriloga.FormattingEnabled = true;
            this.cmbOdabirPriloga.Location = new System.Drawing.Point(267, 56);
            this.cmbOdabirPriloga.Margin = new System.Windows.Forms.Padding(2);
            this.cmbOdabirPriloga.Name = "cmbOdabirPriloga";
            this.cmbOdabirPriloga.Size = new System.Drawing.Size(197, 25);
            this.cmbOdabirPriloga.TabIndex = 32;
            this.cmbOdabirPriloga.SelectedIndexChanged += new System.EventHandler(this.cmbOdabirPriloga_SelectedIndexChanged);
            // 
            // lblAzurirajCenu
            // 
            this.lblAzurirajCenu.AutoSize = true;
            this.lblAzurirajCenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajCenu.Location = new System.Drawing.Point(266, 133);
            this.lblAzurirajCenu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajCenu.Name = "lblAzurirajCenu";
            this.lblAzurirajCenu.Size = new System.Drawing.Size(92, 17);
            this.lblAzurirajCenu.TabIndex = 31;
            this.lblAzurirajCenu.Text = "Cena priloga:";
            // 
            // lblAzurirajNaziv
            // 
            this.lblAzurirajNaziv.AutoSize = true;
            this.lblAzurirajNaziv.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajNaziv.Location = new System.Drawing.Point(264, 84);
            this.lblAzurirajNaziv.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajNaziv.Name = "lblAzurirajNaziv";
            this.lblAzurirajNaziv.Size = new System.Drawing.Size(94, 17);
            this.lblAzurirajNaziv.TabIndex = 30;
            this.lblAzurirajNaziv.Text = "Naziv priloga:";
            // 
            // txtAzurirajCenuPriloga
            // 
            this.txtAzurirajCenuPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajCenuPriloga.Location = new System.Drawing.Point(266, 152);
            this.txtAzurirajCenuPriloga.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajCenuPriloga.Name = "txtAzurirajCenuPriloga";
            this.txtAzurirajCenuPriloga.Size = new System.Drawing.Size(198, 26);
            this.txtAzurirajCenuPriloga.TabIndex = 1;
            // 
            // txtAzurirajNazivPriloga
            // 
            this.txtAzurirajNazivPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajNazivPriloga.Location = new System.Drawing.Point(266, 103);
            this.txtAzurirajNazivPriloga.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajNazivPriloga.Name = "txtAzurirajNazivPriloga";
            this.txtAzurirajNazivPriloga.Size = new System.Drawing.Size(198, 26);
            this.txtAzurirajNazivPriloga.TabIndex = 0;
            // 
            // lblCenaPriloga
            // 
            this.lblCenaPriloga.AutoSize = true;
            this.lblCenaPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCenaPriloga.Location = new System.Drawing.Point(8, 84);
            this.lblCenaPriloga.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCenaPriloga.Name = "lblCenaPriloga";
            this.lblCenaPriloga.Size = new System.Drawing.Size(92, 17);
            this.lblCenaPriloga.TabIndex = 31;
            this.lblCenaPriloga.Text = "Cena priloga:";
            // 
            // lblNazivPriloga
            // 
            this.lblNazivPriloga.AutoSize = true;
            this.lblNazivPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNazivPriloga.Location = new System.Drawing.Point(11, 37);
            this.lblNazivPriloga.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNazivPriloga.Name = "lblNazivPriloga";
            this.lblNazivPriloga.Size = new System.Drawing.Size(94, 17);
            this.lblNazivPriloga.TabIndex = 30;
            this.lblNazivPriloga.Text = "Naziv priloga:";
            // 
            // txtCenaPriloga
            // 
            this.txtCenaPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCenaPriloga.Location = new System.Drawing.Point(11, 103);
            this.txtCenaPriloga.Margin = new System.Windows.Forms.Padding(2);
            this.txtCenaPriloga.Name = "txtCenaPriloga";
            this.txtCenaPriloga.Size = new System.Drawing.Size(198, 26);
            this.txtCenaPriloga.TabIndex = 1;
            // 
            // txtNazivPriloga
            // 
            this.txtNazivPriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazivPriloga.Location = new System.Drawing.Point(11, 56);
            this.txtNazivPriloga.Margin = new System.Windows.Forms.Padding(2);
            this.txtNazivPriloga.Name = "txtNazivPriloga";
            this.txtNazivPriloga.Size = new System.Drawing.Size(198, 26);
            this.txtNazivPriloga.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 36;
            this.label1.Text = "Dodaj prilog:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(308, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 17);
            this.label2.TabIndex = 37;
            this.label2.Text = "Izmjeni prilog:";
            // 
            // PriloziForma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 260);
            this.Controls.Add(btnObrisiPrilog);
            this.Controls.Add(this.label2);
            this.Controls.Add(btnAzurirajPrilog);
            this.Controls.Add(this.cmbOdabirPriloga);
            this.Controls.Add(this.txtAzurirajCenuPriloga);
            this.Controls.Add(this.lblAzurirajCenu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblAzurirajNaziv);
            this.Controls.Add(this.txtAzurirajNazivPriloga);
            this.Controls.Add(btnDodajPrilog);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCenaPriloga);
            this.Controls.Add(this.lblCenaPriloga);
            this.Controls.Add(this.lblNazivPriloga);
            this.Controls.Add(this.txtNazivPriloga);
            this.Name = "PriloziForma";
            this.Text = "PriloziForma";
            this.Load += new System.EventHandler(this.PriloziForma_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbOdabirPriloga;
        private System.Windows.Forms.Label lblAzurirajCenu;
        private System.Windows.Forms.Label lblAzurirajNaziv;
        private System.Windows.Forms.TextBox txtAzurirajCenuPriloga;
        private System.Windows.Forms.TextBox txtAzurirajNazivPriloga;
        private System.Windows.Forms.Label lblCenaPriloga;
        private System.Windows.Forms.Label lblNazivPriloga;
        private System.Windows.Forms.TextBox txtCenaPriloga;
        private System.Windows.Forms.TextBox txtNazivPriloga;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}