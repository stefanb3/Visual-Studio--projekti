﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1Konacno
{
    [Serializable]
    class Jelo
    {
        private int idJela;
        private string nazivJela;
        private int gramazaJela;
        private string opisJela;
        private double cenaJela;
        private List<int> dostupniPrilozi; //Lista koja cuva id-eve priloga koji su dostupni za jelo
        private List<int> dostupniDodaci; //Lista koja cuva id-eve dodataka koji su dostupni za jelo
        private List<int> odabraniPrilozi;//koristicemo listu da kasnije pri dodavanju jela na porudzbinu mozemo da sacuvamo podatak sta je odabrano
        private List<int> odabraniDodaci;
        private bool obavezanPrilog;
        private int id_restoran;

        public Jelo(int idJela, string nazivJela, int gramazaJela, string opisJela, double cenaJela, List<int> dostupniPrilozi, List<int> dostupniDodaci, bool obavezanPrilog, int id_restoran)
        {
            List<int> pom = new List<int>(); //moramo ovako jer ako izjednacimo liste pokazivanje na istu adresu i posle praznjenja liste koji koristimo u programu i saljemo konstruktoru objekat ce pokazivati na praznu listu
            List<int> pom2 = new List<int>();

            this.idJela = idJela;
            this.nazivJela = nazivJela;
            this.gramazaJela = gramazaJela;
            this.opisJela = opisJela;
            this.cenaJela = cenaJela;
            pom.AddRange(dostupniPrilozi);
            this.dostupniPrilozi = pom;
            pom2.AddRange(dostupniDodaci);
            this.dostupniDodaci = pom2;

            this.odabraniPrilozi = new List<int>();
            this.odabraniDodaci = new List<int>();
            this.obavezanPrilog = obavezanPrilog;
            this.id_restoran = id_restoran;
        }

        public Jelo()
        {
            this.idJela = 0;
            this.nazivJela = "default";
            this.gramazaJela = 0;
            this.opisJela = "default";
            this.cenaJela = 0;
            this.dostupniPrilozi = new List<int>();
            this.dostupniDodaci = new List<int>();
            this.odabraniPrilozi = new List<int>();
            this.odabraniDodaci = new List<int>();
            this.obavezanPrilog = false;
            this.id_restoran = 0;
        }

        public int IdJela { get => idJela; set => idJela = value; }
        public string NazivJela { get => nazivJela; set => nazivJela = value; }
        public int GramazaJela { get => gramazaJela; set => gramazaJela = value; }
        public string OpisJela { get => opisJela; set => opisJela = value; }
        public double CenaJela { get => cenaJela; set => cenaJela = value; }
        public List<int> DostupniPrilozi { get => dostupniPrilozi; set => dostupniPrilozi = value; }
        public List<int> DostupniDodaci { get => dostupniDodaci; set => dostupniDodaci = value; }
        public int Id_restoran { get => id_restoran; set => id_restoran = value; }
        public List<int> OdabraniPrilozi { get => odabraniPrilozi; set => odabraniPrilozi = value; }
        public List<int> OdabraniDodaci { get => odabraniDodaci; set => odabraniDodaci = value; }
        public bool ObavezniPrilog { get => obavezanPrilog; set => obavezanPrilog = value; }
    }
}
