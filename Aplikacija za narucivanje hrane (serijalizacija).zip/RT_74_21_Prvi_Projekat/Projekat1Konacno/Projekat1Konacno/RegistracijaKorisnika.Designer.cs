﻿
namespace Projekat1Konacno
{
    partial class RegistracijaKorisnika
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbKorisnici = new System.Windows.Forms.GroupBox();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.tbPrezime = new System.Windows.Forms.TextBox();
            this.tbKorisnickoIme = new System.Windows.Forms.TextBox();
            this.lblIme = new System.Windows.Forms.Label();
            this.tbSifra = new System.Windows.Forms.TextBox();
            this.tbIme = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.grbKorisnici.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbKorisnici
            // 
            this.grbKorisnici.Controls.Add(this.lblPrezime);
            this.grbKorisnici.Controls.Add(this.btnDodaj);
            this.grbKorisnici.Controls.Add(this.tbPrezime);
            this.grbKorisnici.Controls.Add(this.tbKorisnickoIme);
            this.grbKorisnici.Controls.Add(this.lblIme);
            this.grbKorisnici.Controls.Add(this.tbSifra);
            this.grbKorisnici.Controls.Add(this.tbIme);
            this.grbKorisnici.Controls.Add(this.label1);
            this.grbKorisnici.Controls.Add(this.label2);
            this.grbKorisnici.Location = new System.Drawing.Point(11, 11);
            this.grbKorisnici.Margin = new System.Windows.Forms.Padding(2);
            this.grbKorisnici.Name = "grbKorisnici";
            this.grbKorisnici.Padding = new System.Windows.Forms.Padding(2);
            this.grbKorisnici.Size = new System.Drawing.Size(206, 267);
            this.grbKorisnici.TabIndex = 5;
            this.grbKorisnici.TabStop = false;
            this.grbKorisnici.Text = "Dodavanje korisnika";
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrezime.Location = new System.Drawing.Point(1, 70);
            this.lblPrezime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(63, 17);
            this.lblPrezime.TabIndex = 23;
            this.lblPrezime.Text = "Prezime:";
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(0, 234);
            this.btnDodaj.Margin = new System.Windows.Forms.Padding(2);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(196, 29);
            this.btnDodaj.TabIndex = 18;
            this.btnDodaj.Text = "Registruj se";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // tbPrezime
            // 
            this.tbPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPrezime.Location = new System.Drawing.Point(3, 89);
            this.tbPrezime.Margin = new System.Windows.Forms.Padding(2);
            this.tbPrezime.Name = "tbPrezime";
            this.tbPrezime.Size = new System.Drawing.Size(197, 26);
            this.tbPrezime.TabIndex = 22;
            // 
            // tbKorisnickoIme
            // 
            this.tbKorisnickoIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKorisnickoIme.Location = new System.Drawing.Point(3, 136);
            this.tbKorisnickoIme.Margin = new System.Windows.Forms.Padding(2);
            this.tbKorisnickoIme.Name = "tbKorisnickoIme";
            this.tbKorisnickoIme.Size = new System.Drawing.Size(197, 26);
            this.tbKorisnickoIme.TabIndex = 12;
            this.tbKorisnickoIme.TextChanged += new System.EventHandler(this.tbKorisnickoIme_TextChanged);
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIme.Location = new System.Drawing.Point(6, 18);
            this.lblIme.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(34, 17);
            this.lblIme.TabIndex = 21;
            this.lblIme.Text = "Ime:";
            // 
            // tbSifra
            // 
            this.tbSifra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSifra.Location = new System.Drawing.Point(4, 183);
            this.tbSifra.Margin = new System.Windows.Forms.Padding(2);
            this.tbSifra.Name = "tbSifra";
            this.tbSifra.Size = new System.Drawing.Size(197, 26);
            this.tbSifra.TabIndex = 13;
            this.tbSifra.UseSystemPasswordChar = true;
            // 
            // tbIme
            // 
            this.tbIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIme.Location = new System.Drawing.Point(6, 39);
            this.tbIme.Margin = new System.Windows.Forms.Padding(2);
            this.tbIme.Name = "tbIme";
            this.tbIme.Size = new System.Drawing.Size(197, 26);
            this.tbIme.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 117);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Korisnicko ime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 164);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "Lozinka";
            // 
            // RegistracijaKorisnika
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(254, 317);
            this.Controls.Add(this.grbKorisnici);
            this.Name = "RegistracijaKorisnika";
            this.Text = "RegistracijaKorisnika";
            this.grbKorisnici.ResumeLayout(false);
            this.grbKorisnici.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbKorisnici;
        private System.Windows.Forms.Label lblPrezime;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.TextBox tbPrezime;
        private System.Windows.Forms.TextBox tbKorisnickoIme;
        private System.Windows.Forms.Label lblIme;
        private System.Windows.Forms.TextBox tbSifra;
        private System.Windows.Forms.TextBox tbIme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}