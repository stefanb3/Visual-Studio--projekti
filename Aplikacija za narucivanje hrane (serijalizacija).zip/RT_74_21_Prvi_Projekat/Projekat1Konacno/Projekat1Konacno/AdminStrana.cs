﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class AdminStrana : Form
    {
        public AdminStrana()
        {
            InitializeComponent();
        }

        private void btnAzuriranjeAdmina_Click(object sender, EventArgs e)
        {
            AzurirajAdmine forma = new AzurirajAdmine();
            forma.Show();
        }

        private void btnAzurirajKorisnike_Click(object sender, EventArgs e)
        {
            AzurirajKorisnike forma = new AzurirajKorisnike();
            forma.Show();
        }

        private void AdminStrana_Load(object sender, EventArgs e)
        {

        }

        private void btnRestorani_Click(object sender, EventArgs e)
        {
            Restorani forma = new Restorani();
            forma.Show();
        }

        private void btnDodaci_Click(object sender, EventArgs e)
        {
            Dodaci forma = new Dodaci();
            forma.Show();
        }

        private void btnPrilog_Click(object sender, EventArgs e)
        {
            PriloziForma form = new PriloziForma();
            form.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            JeloForma jelof = new JeloForma();
            jelof.Show();
        }
    }
}
