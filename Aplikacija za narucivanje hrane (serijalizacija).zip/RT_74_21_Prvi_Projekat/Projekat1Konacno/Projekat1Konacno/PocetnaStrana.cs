﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class PocetnaStrana : Form
    {
        public PocetnaStrana()
        {
            InitializeComponent();
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            AdminLogIn forma = new AdminLogIn();
            forma.Show();
        }

        private void btnKorisnik_Click(object sender, EventArgs e)
        {
            KorisnikLogIn forma1 = new KorisnikLogIn();
            forma1.Show();
        }
    }
}
