﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class RegistracijaKorisnika : Form
    {
        List<Korisnik> korisnici = new List<Korisnik>();
        bool dupliran = false;
        bool datoteka = true;
        string nazivDatoteke = "korisnici.bin";
        public RegistracijaKorisnika()
        {
            InitializeComponent();
            ucitajKorisnike();
           
        }
        void ucitajKorisnike()
        {
            if (File.Exists(nazivDatoteke))
            {
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter(); //Deserijalizujemo datoteku kako bi smo kasnije proverili da li uenseni korisnik vec postoji
                korisnici = binaryFormatter.Deserialize(fs) as List<Korisnik>;
                fs.Close();
                datoteka = true;
            }
            else
            {
                datoteka = false;
            }
        }
        void upisiKorisnikeUDatoteku()
        {
            FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, korisnici);

            fs.Close();
        }

        private void btnDodaj_Click(object sender, EventArgs e)
        {
            if (datoteka) //Ako datoteka postoji proveravamo da li je uneti korisnik dupliran
            {
                for (int i = 0; i < korisnici.Count; i++)
                {
                    if (tbIme.Text == korisnici[i].KorIme)
                    {
                        dupliran = true; //Proveravamo da li unete informacije vec pripadaju nekom korisniku da se ne bi duplirale
                    }
                }
            }
            if (tbIme.Text == "" || tbKorisnickoIme.Text == "" || tbKorisnickoIme.Text == "" || tbSifra.Text == "")
            {
                MessageBox.Show("Sva polja su obavezna");
            }
            else if (dupliran)
            {
                MessageBox.Show("Uneti podaci vec postoje, morate promeniti korisnicko ime");
                dupliran = false;
            }

            else //Ako podaci prodju sve provere registrujemo korisnika
            {
                Korisnik korisnik1;

                korisnik1 = new Korisnik((korisnici[korisnici.Count - 1].Id + 1), tbIme.Text, tbPrezime.Text, tbKorisnickoIme.Text, tbSifra.Text);
                korisnici.Add(korisnik1);


                upisiKorisnikeUDatoteku();

                MessageBox.Show("Uspesno dodavanje korisnika");

                ucitajKorisnike(); //Ako smo uspesno dodali korisnika azuriramo listu postojecih korisnika

               

                tbIme.Text = "";
                tbPrezime.Text = "";
                tbKorisnickoIme.Text = "";
                tbSifra.Text = "";

                
            }

        }

        private void tbKorisnickoIme_TextChanged(object sender, EventArgs e)
        {
            if (File.Exists(nazivDatoteke))
            {

                for (int i = 0; i < korisnici.Count; i++)
                {
                    if (tbKorisnickoIme.Text == korisnici[i].KorIme)
                    {

                        btnDodaj.Enabled = false;
                        tbKorisnickoIme.BackColor = Color.Red;
                    }
                    else
                    {
                        btnDodaj.Enabled = true;
                        tbKorisnickoIme.BackColor = Color.White;

                    }
                }
            }
        }
    }
}
