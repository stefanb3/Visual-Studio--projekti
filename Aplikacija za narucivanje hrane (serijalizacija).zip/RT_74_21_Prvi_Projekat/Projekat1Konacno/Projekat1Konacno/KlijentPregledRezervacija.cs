﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class KlijentPregledRezervacija : Form
    {
        int prijavljeniKorisnik;
        List<Rezervacija> rezervacije = new List<Rezervacija>();
        List<Restoran> restorani = new List<Restoran>();
        Restoran pomocnaRestoran = new Restoran(0, "default", "default", "default");
        List<int> ucitaneRezervacije = new List<int>();
        string nazivDatoteke1 = "rezervacije.bin";
        string nazivDatoteke2 = "restorani.bin";
        string nazivDatoteke3 = "";

        public KlijentPregledRezervacija(int idKorisnika)
        {
            InitializeComponent();
            prijavljeniKorisnik = idKorisnika;
            ucitajRestorane();
            ucitajRezervacije();
            prikazRezervacija();
        }




        void ucitajRezervacije()
        {
            if (File.Exists(nazivDatoteke1))
            {
                FileStream fs = new FileStream(nazivDatoteke1, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                rezervacije = binaryFormatter.Deserialize(fs) as List<Rezervacija>;
                fs.Dispose();
            }
            else
            {
                List<Rezervacija> pomocnaRezervacija = new List<Rezervacija>();
                List<Jelo> pomocna = new List<Jelo>();
                List<int> pomocnaLista = new List<int>();
                pomocnaLista.Add(0);
                pomocna.Add(new Jelo(0, "default", 0, "default", 0.0, pomocnaLista, pomocnaLista, false, 0));
                pomocnaRezervacija.Add(new Rezervacija(DateTime.Now, pomocna, 0.0, 0, 0));

                FileStream fs = new FileStream(nazivDatoteke1, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, pomocnaRezervacija);

                fs.Dispose();

                ucitajRezervacije();
            }
        }
        void ucitajRestorane()
        {
            if (File.Exists(nazivDatoteke2))
            {
                FileStream fs = new FileStream(nazivDatoteke2, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                restorani = binaryFormatter.Deserialize(fs) as List<Restoran>;
                fs.Dispose();
            }
            else
            {
                List<Restoran> restoran = new List<Restoran>();
                restoran.Add(new Restoran(0, "default", "default", "default"));
                FileStream fs = new FileStream(nazivDatoteke2, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, restoran);

                fs.Dispose();

                ucitajRestorane();
            }
        }
        void prikazRezervacija()
        {
            for (int i = 0; i < rezervacije.Count; i++)
            {
                if (rezervacije[i].IdKorisnika == prijavljeniKorisnik)
                {
                    for (int j = 0; j < restorani.Count; j++)
                    {
                        if (restorani[j].IdRestorana == rezervacije[i].IdRestorana)
                        {
                            pomocnaRestoran.NazivRestorana = restorani[j].NazivRestorana;
                        }
                    }
                    lstbRezervacije.Items.Add(rezervacije[i].DatumRezervacije.Day + "/" + rezervacije[i].DatumRezervacije.Month + "/" + rezervacije[i].DatumRezervacije.Year + " " + pomocnaRestoran.NazivRestorana + ", " + rezervacije[i].UkupnaCena + "RSD");
                    ucitaneRezervacije.Add(i);
                }
            }
        }
        private void KlijentPregledRezervacija_Load(object sender, EventArgs e)
        {

        }

        private void lstbRezervacije_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtNazivRestorana.Text = "";
            txtAdresaRestorana.Text = "";
            txtKontaktRestorana.Text = "";
            txtDatumRezervacije.Text = "";
            lstbOdabranaJela.Items.Clear();

            for (int i = 0; i < restorani.Count; i++)
            {
                if (rezervacije[ucitaneRezervacije[lstbRezervacije.SelectedIndex]].IdRestorana == restorani[i].IdRestorana)
                {
                    pomocnaRestoran = restorani[i];
                }
            }
            txtNazivRestorana.Text = pomocnaRestoran.NazivRestorana;
            txtAdresaRestorana.Text = pomocnaRestoran.AdresaRestorana;
            txtKontaktRestorana.Text = pomocnaRestoran.KontaktRestorana;

            txtDatumRezervacije.Text = rezervacije[ucitaneRezervacije[lstbRezervacije.SelectedIndex]].DatumRezervacije.ToString();

            txtUkupnaCena.Text = rezervacije[ucitaneRezervacije[lstbRezervacije.SelectedIndex]].UkupnaCena.ToString();

            for (int i = 1; i < rezervacije[ucitaneRezervacije[lstbRezervacije.SelectedIndex]].OdabranaJela.Count; i++)
            {
                lstbOdabranaJela.Items.Add(rezervacije[ucitaneRezervacije[lstbRezervacije.SelectedIndex]].OdabranaJela[i].NazivJela);
            }
        }

        private void btnZatvaranje_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
