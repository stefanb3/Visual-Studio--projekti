﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1Konacno
{
    [Serializable]
    class Prilog
    {
        private int idPrilog;
        private string nazivPriloga;
        private double cenaPriloga;
        public Prilog(int idPrilog, string nazivPriloga, double cenaPriloga)
        {
            this.idPrilog = idPrilog;
            this.nazivPriloga = nazivPriloga;
            this.cenaPriloga = cenaPriloga;
        }

        public int IdPrilog { get => idPrilog; set => idPrilog = value; }
        public string NazivPriloga { get => nazivPriloga; set => nazivPriloga = value; }
        public double CenaPriloga { get => cenaPriloga; set => cenaPriloga = value; }
    }
}
