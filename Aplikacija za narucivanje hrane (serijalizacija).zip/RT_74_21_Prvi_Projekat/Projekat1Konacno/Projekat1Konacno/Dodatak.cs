﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1Konacno
{
    [Serializable]
    class Dodatak
    {
        private int idDodatka;
        private string nazivDodatka;
        private double cenaDodatka;
        private int gramazaDodatka;//Lista u kojoj cemo cuvati id jela za koje je odredjeni prilog dostupan

        public Dodatak(int idDodatka, string nazivDodatka, double cenaDodatka, int gramazaDodatka)
        {
            this.idDodatka = idDodatka;
            this.nazivDodatka = nazivDodatka;
            this.cenaDodatka = cenaDodatka;
            this.gramazaDodatka = gramazaDodatka;
        }

        public int IdDodatka { get => idDodatka; set => idDodatka = value; }
        public string NazivDodatka { get => nazivDodatka; set => nazivDodatka = value; }
        public double CenaDodatka { get => cenaDodatka; set => cenaDodatka = value; }
        public int GramazaDodatka { get => gramazaDodatka; set => gramazaDodatka = value; }
    }
}
