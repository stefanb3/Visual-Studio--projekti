﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class KorisnickaStrana : Form
    {
        int prijavljeniKorisnik;
        public KorisnickaStrana(int idKorisnika)
        {
            InitializeComponent();
            prijavljeniKorisnik = idKorisnika;
        }

        private void btnDodajPrilog_Click(object sender, EventArgs e)
        {
            KlijentNovaRezervacija forma = new KlijentNovaRezervacija(prijavljeniKorisnik);
            forma.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            KlijentPregledRezervacija forma = new KlijentPregledRezervacija(prijavljeniKorisnik);
            forma.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            KlijentIzmjenaREzervacija forma = new KlijentIzmjenaREzervacija(prijavljeniKorisnik);
            forma.Show();
        }
    }
}
