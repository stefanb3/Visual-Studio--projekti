﻿
namespace Projekat1Konacno
{
    partial class AdminStrana
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAzuriranjeAdmina = new System.Windows.Forms.Button();
            this.btnAzurirajKorisnike = new System.Windows.Forms.Button();
            this.btnRestorani = new System.Windows.Forms.Button();
            this.btnDodaci = new System.Windows.Forms.Button();
            this.btnPrilog = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAzuriranjeAdmina
            // 
            this.btnAzuriranjeAdmina.Location = new System.Drawing.Point(12, 26);
            this.btnAzuriranjeAdmina.Name = "btnAzuriranjeAdmina";
            this.btnAzuriranjeAdmina.Size = new System.Drawing.Size(104, 23);
            this.btnAzuriranjeAdmina.TabIndex = 0;
            this.btnAzuriranjeAdmina.Text = "Azuriraj Admine";
            this.btnAzuriranjeAdmina.UseVisualStyleBackColor = true;
            this.btnAzuriranjeAdmina.Click += new System.EventHandler(this.btnAzuriranjeAdmina_Click);
            // 
            // btnAzurirajKorisnike
            // 
            this.btnAzurirajKorisnike.Location = new System.Drawing.Point(12, 55);
            this.btnAzurirajKorisnike.Name = "btnAzurirajKorisnike";
            this.btnAzurirajKorisnike.Size = new System.Drawing.Size(104, 23);
            this.btnAzurirajKorisnike.TabIndex = 1;
            this.btnAzurirajKorisnike.Text = "AzurirajKorisnike";
            this.btnAzurirajKorisnike.UseVisualStyleBackColor = true;
            this.btnAzurirajKorisnike.Click += new System.EventHandler(this.btnAzurirajKorisnike_Click);
            // 
            // btnRestorani
            // 
            this.btnRestorani.Location = new System.Drawing.Point(12, 104);
            this.btnRestorani.Name = "btnRestorani";
            this.btnRestorani.Size = new System.Drawing.Size(104, 23);
            this.btnRestorani.TabIndex = 2;
            this.btnRestorani.Text = "Restorani";
            this.btnRestorani.UseVisualStyleBackColor = true;
            this.btnRestorani.Click += new System.EventHandler(this.btnRestorani_Click);
            // 
            // btnDodaci
            // 
            this.btnDodaci.Location = new System.Drawing.Point(12, 133);
            this.btnDodaci.Name = "btnDodaci";
            this.btnDodaci.Size = new System.Drawing.Size(104, 23);
            this.btnDodaci.TabIndex = 3;
            this.btnDodaci.Text = "Dodaci";
            this.btnDodaci.UseVisualStyleBackColor = true;
            this.btnDodaci.Click += new System.EventHandler(this.btnDodaci_Click);
            // 
            // btnPrilog
            // 
            this.btnPrilog.Location = new System.Drawing.Point(12, 162);
            this.btnPrilog.Name = "btnPrilog";
            this.btnPrilog.Size = new System.Drawing.Size(104, 23);
            this.btnPrilog.TabIndex = 4;
            this.btnPrilog.Text = "Prilog";
            this.btnPrilog.UseVisualStyleBackColor = true;
            this.btnPrilog.Click += new System.EventHandler(this.btnPrilog_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "Rad sa nalozima:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-1, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Rad sa podacima:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 191);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Jelo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // AdminStrana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(789, 412);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPrilog);
            this.Controls.Add(this.btnDodaci);
            this.Controls.Add(this.btnRestorani);
            this.Controls.Add(this.btnAzurirajKorisnike);
            this.Controls.Add(this.btnAzuriranjeAdmina);
            this.Name = "AdminStrana";
            this.Text = "AdminStrana";
            this.Load += new System.EventHandler(this.AdminStrana_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAzuriranjeAdmina;
        private System.Windows.Forms.Button btnAzurirajKorisnike;
        private System.Windows.Forms.Button btnRestorani;
        private System.Windows.Forms.Button btnDodaci;
        private System.Windows.Forms.Button btnPrilog;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}