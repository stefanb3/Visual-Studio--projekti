﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class JeloForma : Form
    {
        List<Restoran> listaRestorana = new List<Restoran>();
        string nazivDatoteke = "restorani.bin";
        List<Prilog> prilozi = new List<Prilog>();
        string nazivDatoteke1 = "prilozi.bin";
        List<Dodatak> dodaci = new List<Dodatak>();
        string nazivDatoteke2 = "dodaci.bin";
        List<int> pomocnaListaZaDostupnePriloge = new List<int>();
        List<int> pomocnaListaZaDostupneDodatke = new List<int>();
        List<Jelo> jela = new List<Jelo>();
        string nazivDatoteke3 = "jela.bin";
        List<int> pomocnaListaZaIDJelaDosutpnihUJednomRestoranu = new List<int>();
        List<int> pomocnaZaAzuriranjePriloga = new List<int>();
        List<int> pomocnaZaAzuriranjeDodataka = new List<int>();
        public JeloForma()
        {
            InitializeComponent();
            ucitajRestorane();
            UcitajRestoraneUKomboBox();
            ucitajPriloge();
            ucitajPrilogeZaAzuriranje();
            ucitajDodatke();
            ucitajDodatkeZaAzuriranje();
            ucitajJela();

        }

        void ucitajRestorane()
        {
            if (File.Exists(nazivDatoteke))
            {
                // Ako datoteka postoji, čitamo podatke iz nje
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                listaRestorana = binaryFormatter.Deserialize(fs) as List<Restoran>;
                fs.Close();
            }
            else
            {
                // Ako datoteka ne postoji, kreiramo listu sa jednim podrazumevanim restoranom
                List<Restoran> restoran = new List<Restoran>();
                restoran.Add(new Restoran(1, "default", "default", "default"));

                // Kreiramo novu datoteku i upisujemo listu u nju
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, restoran);

                fs.Dispose();
            }
        }
        void UcitajRestoraneUKomboBox()
        {

            cmbJeloZaRestoran.Items.Clear();
            cmbRestoranZaAzuriranjeJela.Items.Clear();
            for (int i = 1; i < listaRestorana.Count(); i++)
            {
                cmbJeloZaRestoran.Items.Add("Naziv: " + listaRestorana[i].NazivRestorana);
                cmbRestoranZaAzuriranjeJela.Items.Add("Naziv: " + listaRestorana[i].NazivRestorana );
            }


        }





        void ucitajPriloge()
        {
            if (File.Exists(nazivDatoteke1))
            {
                FileStream fs = new FileStream(nazivDatoteke1, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter(); //Deserijalizujemo datoteku kako bi smo kasnije omogucili prijavu
                prilozi = binaryFormatter.Deserialize(fs) as List<Prilog>;
                fs.Dispose();
            }
            else
            {
                List<Prilog> prilozi = new List<Prilog>();
                prilozi.Add(new Prilog(0, "default", 0.0));
                FileStream fs = new FileStream(nazivDatoteke1, FileMode.Create); //dodajemo default prilog koji ce nam omguciti da korisnik odabere da ne zeli prilog
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, prilozi);

                fs.Dispose();

                ucitajPriloge();

                ucitajPrilogeZaAzuriranje();
            }
        }

        void ucitajPrilogeZaAzuriranje()
        {
            cmbDostupniPrilozi.Items.Clear();
            cmbAzurirajDostupnePriloge.Items.Clear();
            for (int i = 1; i < prilozi.Count(); i++)
            {
                cmbDostupniPrilozi.Items.Add("ID:" + prilozi[i].IdPrilog + " " + prilozi[i].NazivPriloga + " " + prilozi[i].CenaPriloga + "RSD");
                cmbAzurirajDostupnePriloge.Items.Add("ID:" + prilozi[i].IdPrilog + " " + prilozi[i].NazivPriloga + " " + prilozi[i].CenaPriloga + "RSD");
            }
        }


        void ucitajDodatke()
        {
            if (File.Exists(nazivDatoteke2))
            {
                FileStream fs = new FileStream(nazivDatoteke2, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                dodaci = binaryFormatter.Deserialize(fs) as List<Dodatak>;
                fs.Dispose();
            }
            else
            {
                List<Dodatak> dodatak = new List<Dodatak>();
                dodatak.Add(new Dodatak(0, "default", 0, 0));
                FileStream fs = new FileStream(nazivDatoteke2, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, dodatak);

                fs.Dispose();

            }
        }

        void ucitajDodatkeZaAzuriranje()
        {
            cmbDostupniDodaci.Items.Clear();
            cmbAzuriranjeDostupnihDodataka.Items.Clear();
            for (int i = 1; i < dodaci.Count; i++)
            {
                cmbDostupniDodaci.Items.Add("ID " + dodaci[i].IdDodatka + " " + dodaci[i].NazivDodatka + " " + dodaci[i].GramazaDodatka + "g " + dodaci[i].CenaDodatka + "RSD");
                cmbAzuriranjeDostupnihDodataka.Items.Add("ID " + dodaci[i].IdDodatka + " " + dodaci[i].NazivDodatka + " " + dodaci[i].GramazaDodatka + "g " + dodaci[i].CenaDodatka + "RSD");
            }
        }

        void sacuvajJelaUDatoteku()
        {
            FileStream fs = new FileStream(nazivDatoteke3, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, jela);

            fs.Dispose();
        }


        void ucitajJela()
        {
            if (File.Exists(nazivDatoteke3))
            {
                FileStream fs = new FileStream(nazivDatoteke3, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                jela = binaryFormatter.Deserialize(fs) as List<Jelo>;
                fs.Dispose();
            }
            else
            {
                List<Jelo> jelaPom = new List<Jelo>();
                List<int> pom = new List<int>();
                pom.Add(0);
                jelaPom.Add(new Jelo(0, "default", 0, "default", 0.0, pom, pom, false, 0));
                FileStream fs = new FileStream(nazivDatoteke3, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, jelaPom);

                fs.Dispose();

                ucitajJela();

                
            }
        }
        private void cmbJeloZaRestoran_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnOmoguciPrilog_Click(object sender, EventArgs e)
        {
            bool vecjeodabran = false;
            for (int i = 0; i < pomocnaListaZaDostupnePriloge.Count; i++)
            {
                if (prilozi[(cmbDostupniPrilozi.SelectedIndex) + 1].IdPrilog == pomocnaListaZaDostupnePriloge[i]) //proveravamo da li id priloga koji zelimo da omogucimo vec postoji u listi omogucenih priloga i ako postoji sprecavamo dodavanje ponovo da ne bi doslo do dupliranja
                {
                    vecjeodabran = true;
                }
            }
            if (cmbDostupniPrilozi.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali prilog koji zelite da dodate");
            }
            else if (vecjeodabran)
            {
                MessageBox.Show("Prilog koji pokusavate da omogucite vec postoji u listi omogucenih priloga");
            }
            else
            {
                lstbOmoguceniPrilozi.Items.Add(prilozi[cmbDostupniPrilozi.SelectedIndex + 1].NazivPriloga + ", " + prilozi[cmbDostupniPrilozi.SelectedIndex + 1].CenaPriloga + "RSD");
                pomocnaListaZaDostupnePriloge.Add(cmbDostupniPrilozi.SelectedIndex + 1);
            }
        }

        private void btnUkiniPrilog_Click(object sender, EventArgs e)
        {

            if (cmbDostupniPrilozi.Items.Count != 0 && lstbOmoguceniPrilozi.SelectedIndex != -1)
            {
                pomocnaListaZaDostupnePriloge.RemoveAt(lstbOmoguceniPrilozi.SelectedIndex);
                lstbOmoguceniPrilozi.Items.RemoveAt(lstbOmoguceniPrilozi.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Neuspesno ukidanje priloga");
            }
        }

        private void btnOmoguciDodatak_Click(object sender, EventArgs e)
        {
            bool vecjeodabran = false;
            for (int i = 0; i < pomocnaListaZaDostupneDodatke.Count; i++)
            {
                if (dodaci[cmbDostupniDodaci.SelectedIndex + 1].IdDodatka == pomocnaListaZaDostupneDodatke[i])
                {
                    vecjeodabran = true;
                }
            }
            if (cmbDostupniDodaci.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali dodatak koji zelite da dodate");
            }
            else if (vecjeodabran)
            {
                MessageBox.Show("Dodatak koji pokusavate da omogucite vec postoji u listi omogucenih dodataka");
            }
            else
            {
                lstbOmoguceniDodaci.Items.Add(dodaci[cmbDostupniDodaci.SelectedIndex + 1].NazivDodatka + ", " + dodaci[cmbDostupniDodaci.SelectedIndex + 1].CenaDodatka + "RSD");
                pomocnaListaZaDostupneDodatke.Add(dodaci[cmbDostupniDodaci.SelectedIndex + 1].IdDodatka);
            }
        }

        private void btnUkiniDodatak_Click(object sender, EventArgs e)
        {

            if (cmbDostupniDodaci.Items.Count != 0 && lstbOmoguceniDodaci.SelectedIndex != -1)
            {
                pomocnaListaZaDostupneDodatke.RemoveAt(lstbOmoguceniDodaci.SelectedIndex);
                lstbOmoguceniDodaci.Items.RemoveAt(lstbOmoguceniDodaci.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Neuspesno ukidanje dodatka");
            }
        }

        private void btnDodajJelo_Click(object sender, EventArgs e)
        {
            double pom;
            int pom2;
            if (cmbJeloZaRestoran.SelectedIndex == -1 || txtNazivJela.Text == "" || txtGramazaJela.Text == "" || txtOpisJela.Text == "" || txtCenaJela.Text == "")
            {
                MessageBox.Show("Sva polja su obavezna");
            }
            else if (!rbtnObavezanPrilog.Checked && !rbtnPrilogNijeObavezan.Checked)
            {
                MessageBox.Show("Sva polja su obavezna");
            }
            else if (!rbtnObavezanPrilog.Checked && lstbOmoguceniPrilozi.Items.Count == 0)
            {
                MessageBox.Show("Posto je prilog obavezan za ovo jelo, morate dodati moguce priloge");
            }
            else if (!double.TryParse(txtCenaJela.Text, out pom))
            {
                MessageBox.Show("Cena jela mora biti broj");
            }
            else if (!int.TryParse(txtGramazaJela.Text, out pom2))
            {
                MessageBox.Show("Gramaza jela mora biti ceo broj");
            }
            else
            {
                if (rbtnObavezanPrilog.Checked)
                {
                    if (pomocnaListaZaDostupneDodatke.Count == 0)
                    {
                        pomocnaListaZaDostupneDodatke.Add(0);
                    }
                    if (pomocnaListaZaDostupnePriloge.Count == 0)
                    {
                        pomocnaListaZaDostupnePriloge.Add(0);//dodavanjem default vrednosti u praznu listu sprecavamo pucanje programa u slucaju da prosledimo praznu listu konstruktoru
                    }
                    jela.Add(new Jelo((jela[jela.Count - 1].IdJela) + 1, txtNazivJela.Text, int.Parse(txtGramazaJela.Text), txtOpisJela.Text, double.Parse(txtCenaJela.Text), pomocnaListaZaDostupnePriloge, pomocnaListaZaDostupneDodatke, true, listaRestorana[cmbJeloZaRestoran.SelectedIndex + 1].IdRestorana));

                    pomocnaListaZaDostupnePriloge.Clear(); //praznimo liste da budu spremne za sledece dodavanje jela
                    pomocnaListaZaDostupneDodatke.Clear();

                    sacuvajJelaUDatoteku();
                    ucitajJela();
                    //ucitajJelaZaAzuriranje();

                    MessageBox.Show("Uspesno dodavanje jela");
                }
                if (rbtnPrilogNijeObavezan.Checked)
                {
                    if (pomocnaListaZaDostupneDodatke.Count == 0)
                    {
                        pomocnaListaZaDostupneDodatke.Add(0);
                    }
                    if (pomocnaListaZaDostupnePriloge.Count == 0)
                    {
                        pomocnaListaZaDostupnePriloge.Add(0);//dodavanjem default vrednosti u praznu listu sprecavamo pucanje programa u slucaju da prosledimo praznu listu konstruktoru
                    }
                    List<int> pom1 = new List<int>();
                    jela.Add(new Jelo(jela[jela.Count - 1].IdJela + 1, txtNazivJela.Text, int.Parse(txtGramazaJela.Text), txtOpisJela.Text, double.Parse(txtCenaJela.Text), pomocnaListaZaDostupnePriloge, pomocnaListaZaDostupneDodatke, false, listaRestorana[cmbJeloZaRestoran.SelectedIndex + 1].IdRestorana));
                    pomocnaListaZaDostupnePriloge.Clear();
                    pomocnaListaZaDostupneDodatke.Clear();

                    sacuvajJelaUDatoteku();
                    ucitajJela();
                    //ucitajJelaZaAzuriranje();

                    MessageBox.Show("Uspesno dodavanje jela");
                }
                txtNazivJela.Text = "";
                txtGramazaJela.Text = "";
                txtOpisJela.Text = "";
                txtCenaJela.Text = "";
                lstbOmoguceniPrilozi.Items.Clear();
                rbtnObavezanPrilog.Checked = false;
                rbtnPrilogNijeObavezan.Checked = false;
                lstbOmoguceniDodaci.Items.Clear();
            }
        }

        private void cmbRestoranZaAzuriranjeJela_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbOdabirJelaZaAzuriranje.Items.Clear();
            pomocnaListaZaIDJelaDosutpnihUJednomRestoranu.Clear();


            for (int i = 0; i < jela.Count; i++)
            {
                if (jela[i].Id_restoran == listaRestorana[cmbRestoranZaAzuriranjeJela.SelectedIndex + 1].IdRestorana)
                {
                    cmbOdabirJelaZaAzuriranje.Items.Add(jela[i].NazivJela + ", " + jela[i].CenaJela + "RSD");
                    pomocnaListaZaIDJelaDosutpnihUJednomRestoranu.Add(i);
                }
            }
        }





        private void cmbOdabirJelaZaAzuriranje_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstbAzuriraniOmoguceniPrilozi.Items.Clear();
            lstbAzurirajOmoguceneDodatke.Items.Clear();
            pomocnaZaAzuriranjeDodataka.Clear();
            pomocnaZaAzuriranjePriloga.Clear();

            txtAzurirajNazivJela.Text = jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].NazivJela;
            txtAzurirajGramazuJela.Text = jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].GramazaJela.ToString();
            txtAzurirajOpisJela.Text = jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].OpisJela;
            txtAzurirajCenuJela.Text = jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].CenaJela.ToString();
            pomocnaZaAzuriranjePriloga.AddRange(jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].DostupniPrilozi);
            pomocnaZaAzuriranjeDodataka.AddRange(jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].DostupniDodaci);
            if (jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]].ObavezniPrilog)
            {
                rbtnAzuriranjeObavezniPrilog.Checked = true;
            }
            else
            {
                rbtAzuriranjePrilogNijeObavezan.Checked = true;
            }

            for (int i = 0; i < pomocnaZaAzuriranjePriloga.Count; i++)
            {
                for (int j = 0; j < prilozi.Count; j++)
                {
                    if (prilozi[j].IdPrilog == pomocnaZaAzuriranjePriloga[i])
                    {
                        lstbAzuriraniOmoguceniPrilozi.Items.Add(prilozi[j].NazivPriloga + ", " + prilozi[j].CenaPriloga + "RSD");
                    }
                }
            }

            for (int i = 0; i < pomocnaZaAzuriranjeDodataka.Count; i++)
            {
                for (int j = 0; j < dodaci.Count; j++)
                {
                    if (dodaci[j].IdDodatka == dodaci[pomocnaZaAzuriranjeDodataka[i]].IdDodatka)
                    {
                        lstbAzurirajOmoguceneDodatke.Items.Add(dodaci[pomocnaZaAzuriranjeDodataka[i]].NazivDodatka + ", " + dodaci[pomocnaZaAzuriranjeDodataka[i]].CenaDodatka + "RSD");
                    }
                }
            }

        }

        private void btnAzurirajOmoguciPrilog_Click(object sender, EventArgs e)
        {
            bool vecjeodabran = false;
            for (int i = 0; i < pomocnaZaAzuriranjePriloga.Count; i++)
            {
                if (prilozi[(cmbAzurirajDostupnePriloge.SelectedIndex) + 1].IdPrilog == pomocnaZaAzuriranjePriloga[i])
                {
                    vecjeodabran = true;
                }
            }
            if (vecjeodabran)
            {
                MessageBox.Show("Prilog koji pokusavate da omogucite vec postoji u listi omogucenih priloga");
            }
            else if (cmbAzurirajDostupnePriloge.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali prilog koji zelite da dodate");
            }
            else if (cmbOdabirJelaZaAzuriranje.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali jelo za koje zelite da napravite izmene");
            }
            else
            {
                lstbAzuriraniOmoguceniPrilozi.Items.Add(prilozi[cmbAzurirajDostupnePriloge.SelectedIndex + 1].NazivPriloga + ", " + prilozi[cmbAzurirajDostupnePriloge.SelectedIndex + 1].CenaPriloga + "RSD");
                pomocnaZaAzuriranjePriloga.Add(prilozi[cmbAzurirajDostupnePriloge.SelectedIndex + 1].IdPrilog);
            }

        }

        private void btnAzurirajOmoguciDodatak_Click(object sender, EventArgs e)
        {

            bool vecjeodabran = false;
            for (int i = 0; i < pomocnaZaAzuriranjeDodataka.Count; i++)
            {
                if (dodaci[cmbAzuriranjeDostupnihDodataka.SelectedIndex + 1].IdDodatka == pomocnaZaAzuriranjeDodataka[i])
                {
                    vecjeodabran = true;
                }
            }
            if (vecjeodabran)
            {
                MessageBox.Show("Dodatak koji pokusavate da omogucite vec postoji u listi omogucenih dodataka");
            }
            else if (cmbAzuriranjeDostupnihDodataka.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali dodatak koji zelite da dodate");
            }
            else if (cmbOdabirJelaZaAzuriranje.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali jelo za koje zelite da napravite izmene");
            }
            else
            {
                lstbAzurirajOmoguceneDodatke.Items.Add(dodaci[cmbAzuriranjeDostupnihDodataka.SelectedIndex + 1].NazivDodatka + ", " + dodaci[cmbAzuriranjeDostupnihDodataka.SelectedIndex + 1].CenaDodatka + "RSD");
                pomocnaZaAzuriranjeDodataka.Add(dodaci[cmbAzuriranjeDostupnihDodataka.SelectedIndex + 1].IdDodatka);
            }
        }


        void ucitajJelaZaAzuriranje()
        {
            cmbOdabirJelaZaAzuriranje.Items.Clear();
            for (int i = 1; i < jela.Count; i++)
            {
                cmbOdabirJelaZaAzuriranje.Items.Add("ID:" + jela[i].IdJela + " " + jela[i].NazivJela + " " + jela[i].CenaJela + " RSD");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbAzurirajDostupnePriloge.Items.Count != 0 && lstbAzuriraniOmoguceniPrilozi.SelectedIndex != -1)
            {
                pomocnaZaAzuriranjePriloga.RemoveAt(lstbAzuriraniOmoguceniPrilozi.SelectedIndex);
                lstbAzuriraniOmoguceniPrilozi.Items.RemoveAt(lstbAzuriraniOmoguceniPrilozi.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Neuspesno uklanjanje priloga");
            }
        }

        private void btnAzurirajUkiniDodatak_Click(object sender, EventArgs e)
        {

            if (cmbAzuriranjeDostupnihDodataka.Items.Count != 0 && lstbAzurirajOmoguceneDodatke.SelectedIndex != -1)
            {
                pomocnaZaAzuriranjeDodataka.RemoveAt(lstbAzurirajOmoguceneDodatke.SelectedIndex);
                lstbAzurirajOmoguceneDodatke.Items.RemoveAt(lstbAzurirajOmoguceneDodatke.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Neuspesno ukidanje dodatka");
            }
        }

        private void btnSacuvajAzuriranePodatke_Click(object sender, EventArgs e)
        {
            double pom;
            int pom2;

            if (cmbRestoranZaAzuriranjeJela.SelectedIndex == -1 || cmbOdabirJelaZaAzuriranje.SelectedIndex == -1 || txtAzurirajNazivJela.Text == "" || txtAzurirajGramazuJela.Text == "" || txtAzurirajOpisJela.Text == "" || txtAzurirajCenuJela.Text == "")
            {
                if (!rbtAzuriranjePrilogNijeObavezan.Checked && !rbtnAzuriranjeObavezniPrilog.Checked)
                {
                    MessageBox.Show("Sva polja su obavezna");
                }
            }
            else if (!rbtnAzuriranjeObavezniPrilog.Checked && lstbAzuriraniOmoguceniPrilozi.Items.Count == 0)
            {
                MessageBox.Show("Posto je prilog obavezan za ovo jelo, morate dodati moguce priloge");
            }
            else if (!double.TryParse(txtAzurirajCenuJela.Text, out pom))
            {
                MessageBox.Show("Cena jela mora biti broj");
            }
            else if (!int.TryParse(txtAzurirajGramazuJela.Text, out pom2))
            {
                MessageBox.Show("Gramaza jela mora biti ceo broj");
            }
            else
            {
                Jelo jeloPom;
                if (rbtnAzuriranjeObavezniPrilog.Checked)
                {
                    if (pomocnaZaAzuriranjePriloga.Count == 0)
                    {
                        pomocnaZaAzuriranjePriloga.Add(0);
                    }
                    if (pomocnaZaAzuriranjeDodataka.Count == 0)
                    {
                        pomocnaZaAzuriranjeDodataka.Add(0);
                    }
                    jeloPom = new Jelo(((jela[jela.Count - 1].IdJela) + 1), txtAzurirajNazivJela.Text, int.Parse(txtAzurirajGramazuJela.Text), txtAzurirajOpisJela.Text, double.Parse(txtAzurirajCenuJela.Text), pomocnaZaAzuriranjePriloga, pomocnaZaAzuriranjeDodataka, true, listaRestorana[cmbRestoranZaAzuriranjeJela.SelectedIndex + 1].IdRestorana);
                    jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]] = jeloPom;
                }
                if (rbtAzuriranjePrilogNijeObavezan.Checked)
                {
                    if (pomocnaZaAzuriranjePriloga.Count == 0)
                    {
                        pomocnaZaAzuriranjePriloga.Add(0);
                    }
                    if (pomocnaZaAzuriranjeDodataka.Count == 0)
                    {
                        pomocnaZaAzuriranjeDodataka.Add(0);
                    }
                    jeloPom = new Jelo(((jela[jela.Count - 1].IdJela) + 1), txtAzurirajNazivJela.Text, int.Parse(txtAzurirajGramazuJela.Text), txtAzurirajOpisJela.Text, double.Parse(txtAzurirajCenuJela.Text), pomocnaZaAzuriranjePriloga, pomocnaZaAzuriranjeDodataka, false, listaRestorana[cmbRestoranZaAzuriranjeJela.SelectedIndex + 1].IdRestorana);
                    jela[pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]] = jeloPom;
                }
                txtAzurirajNazivJela.Text = "";
                txtAzurirajGramazuJela.Text = "";
                txtAzurirajOpisJela.Text = "";
                txtAzurirajCenuJela.Text = "";
                lstbAzuriraniOmoguceniPrilozi.Items.Clear();
                lstbAzurirajOmoguceneDodatke.Items.Clear();

                MessageBox.Show("Uspesno ste sacuvali izmene za jelo");
            }

            sacuvajJelaUDatoteku();
            ucitajJela();

        }

        private void btnObrisiJelo_Click(object sender, EventArgs e)
        {
            jela.RemoveAt(pomocnaListaZaIDJelaDosutpnihUJednomRestoranu[cmbOdabirJelaZaAzuriranje.SelectedIndex]);

            txtAzurirajNazivJela.Text = "";
            txtAzurirajGramazuJela.Text = "";
            txtAzurirajOpisJela.Text = "";
            txtAzurirajCenuJela.Text = "";
            lstbAzuriraniOmoguceniPrilozi.Items.Clear();
            lstbAzurirajOmoguceneDodatke.Items.Clear();

            MessageBox.Show("Uspesno ste obrisali jelo");

            sacuvajJelaUDatoteku();
            ucitajJela();
        }

        private void cmbAzurirajDostupnePriloge_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbAzuriranjeDostupnihDodataka_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void rbtnAzuriranjeObavezniPrilog_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void rbtAzuriranjePrilogNijeObavezan_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void lstbAzuriraniOmoguceniPrilozi_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void JeloForma_Load(object sender, EventArgs e)
        {

        }

        private void cmbDostupniPrilozi_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void cmbDostupniDodaci_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

 