﻿
namespace Projekat1Konacno
{
    partial class AzurirajAdmine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnObrisi;
            this.cmbAdmini = new System.Windows.Forms.ComboBox();
            this.lblOdabir = new System.Windows.Forms.Label();
            this.btnSacuvaj = new System.Windows.Forms.Button();
            this.lblAzurirajPrezime = new System.Windows.Forms.Label();
            this.tbImeNovo = new System.Windows.Forms.TextBox();
            this.lblAzurirajKorIme = new System.Windows.Forms.Label();
            this.tbPrezimeNovo = new System.Windows.Forms.TextBox();
            this.tbSifraNova = new System.Windows.Forms.TextBox();
            this.lblAzurirajLozinku = new System.Windows.Forms.Label();
            this.tbKorisnickoImeNovo = new System.Windows.Forms.TextBox();
            this.lblAzurirajIme = new System.Windows.Forms.Label();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.tbPrezime = new System.Windows.Forms.TextBox();
            this.tbKorisnickoIme = new System.Windows.Forms.TextBox();
            this.lblIme = new System.Windows.Forms.Label();
            this.tbSifra = new System.Windows.Forms.TextBox();
            this.tbIme = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            btnObrisi = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnObrisi
            // 
            btnObrisi.Location = new System.Drawing.Point(305, 284);
            btnObrisi.Margin = new System.Windows.Forms.Padding(2);
            btnObrisi.Name = "btnObrisi";
            btnObrisi.Size = new System.Drawing.Size(196, 29);
            btnObrisi.TabIndex = 1;
            btnObrisi.Text = "Obrisi admina";
            btnObrisi.UseVisualStyleBackColor = true;
            btnObrisi.Click += new System.EventHandler(this.btnObrisi_Click);
            // 
            // cmbAdmini
            // 
            this.cmbAdmini.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAdmini.FormattingEnabled = true;
            this.cmbAdmini.Location = new System.Drawing.Point(304, 48);
            this.cmbAdmini.Margin = new System.Windows.Forms.Padding(2);
            this.cmbAdmini.Name = "cmbAdmini";
            this.cmbAdmini.Size = new System.Drawing.Size(197, 28);
            this.cmbAdmini.TabIndex = 2;
            this.cmbAdmini.SelectedIndexChanged += new System.EventHandler(this.cmbAdmini_SelectedIndexChanged);
            // 
            // lblOdabir
            // 
            this.lblOdabir.AutoSize = true;
            this.lblOdabir.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabir.Location = new System.Drawing.Point(301, 29);
            this.lblOdabir.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabir.Name = "lblOdabir";
            this.lblOdabir.Size = new System.Drawing.Size(115, 17);
            this.lblOdabir.TabIndex = 24;
            this.lblOdabir.Text = "Odabir korisnika:";
            // 
            // btnSacuvaj
            // 
            this.btnSacuvaj.Location = new System.Drawing.Point(305, 321);
            this.btnSacuvaj.Margin = new System.Windows.Forms.Padding(2);
            this.btnSacuvaj.Name = "btnSacuvaj";
            this.btnSacuvaj.Size = new System.Drawing.Size(196, 29);
            this.btnSacuvaj.TabIndex = 0;
            this.btnSacuvaj.Text = "Sacuvaj azurirane podatake";
            this.btnSacuvaj.UseVisualStyleBackColor = true;
            this.btnSacuvaj.Click += new System.EventHandler(this.btnSacuvaj_Click);
            // 
            // lblAzurirajPrezime
            // 
            this.lblAzurirajPrezime.AutoSize = true;
            this.lblAzurirajPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajPrezime.Location = new System.Drawing.Point(301, 125);
            this.lblAzurirajPrezime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajPrezime.Name = "lblAzurirajPrezime";
            this.lblAzurirajPrezime.Size = new System.Drawing.Size(63, 17);
            this.lblAzurirajPrezime.TabIndex = 31;
            this.lblAzurirajPrezime.Text = "Prezime:";
            // 
            // tbImeNovo
            // 
            this.tbImeNovo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbImeNovo.Location = new System.Drawing.Point(304, 97);
            this.tbImeNovo.Margin = new System.Windows.Forms.Padding(2);
            this.tbImeNovo.Name = "tbImeNovo";
            this.tbImeNovo.Size = new System.Drawing.Size(197, 26);
            this.tbImeNovo.TabIndex = 28;
            // 
            // lblAzurirajKorIme
            // 
            this.lblAzurirajKorIme.AutoSize = true;
            this.lblAzurirajKorIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajKorIme.Location = new System.Drawing.Point(301, 172);
            this.lblAzurirajKorIme.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajKorIme.Name = "lblAzurirajKorIme";
            this.lblAzurirajKorIme.Size = new System.Drawing.Size(103, 17);
            this.lblAzurirajKorIme.TabIndex = 26;
            this.lblAzurirajKorIme.Text = "Korisnicko ime:";
            // 
            // tbPrezimeNovo
            // 
            this.tbPrezimeNovo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPrezimeNovo.Location = new System.Drawing.Point(304, 144);
            this.tbPrezimeNovo.Margin = new System.Windows.Forms.Padding(2);
            this.tbPrezimeNovo.Name = "tbPrezimeNovo";
            this.tbPrezimeNovo.Size = new System.Drawing.Size(197, 26);
            this.tbPrezimeNovo.TabIndex = 30;
            // 
            // tbSifraNova
            // 
            this.tbSifraNova.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSifraNova.Location = new System.Drawing.Point(304, 245);
            this.tbSifraNova.Margin = new System.Windows.Forms.Padding(2);
            this.tbSifraNova.Name = "tbSifraNova";
            this.tbSifraNova.Size = new System.Drawing.Size(197, 26);
            this.tbSifraNova.TabIndex = 25;
            // 
            // lblAzurirajLozinku
            // 
            this.lblAzurirajLozinku.AutoSize = true;
            this.lblAzurirajLozinku.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajLozinku.Location = new System.Drawing.Point(301, 226);
            this.lblAzurirajLozinku.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajLozinku.Name = "lblAzurirajLozinku";
            this.lblAzurirajLozinku.Size = new System.Drawing.Size(57, 17);
            this.lblAzurirajLozinku.TabIndex = 27;
            this.lblAzurirajLozinku.Text = "Lozinka";
            // 
            // tbKorisnickoImeNovo
            // 
            this.tbKorisnickoImeNovo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKorisnickoImeNovo.Location = new System.Drawing.Point(304, 191);
            this.tbKorisnickoImeNovo.Margin = new System.Windows.Forms.Padding(2);
            this.tbKorisnickoImeNovo.Name = "tbKorisnickoImeNovo";
            this.tbKorisnickoImeNovo.Size = new System.Drawing.Size(197, 26);
            this.tbKorisnickoImeNovo.TabIndex = 24;
            // 
            // lblAzurirajIme
            // 
            this.lblAzurirajIme.AutoSize = true;
            this.lblAzurirajIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajIme.Location = new System.Drawing.Point(301, 78);
            this.lblAzurirajIme.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajIme.Name = "lblAzurirajIme";
            this.lblAzurirajIme.Size = new System.Drawing.Size(34, 17);
            this.lblAzurirajIme.TabIndex = 29;
            this.lblAzurirajIme.Text = "Ime:";
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrezime.Location = new System.Drawing.Point(11, 77);
            this.lblPrezime.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(63, 17);
            this.lblPrezime.TabIndex = 23;
            this.lblPrezime.Text = "Prezime:";
            // 
            // btnDodaj
            // 
            this.btnDodaj.Location = new System.Drawing.Point(11, 226);
            this.btnDodaj.Margin = new System.Windows.Forms.Padding(2);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(196, 29);
            this.btnDodaj.TabIndex = 18;
            this.btnDodaj.Text = "Dodaj admina";
            this.btnDodaj.UseVisualStyleBackColor = true;
            this.btnDodaj.Click += new System.EventHandler(this.btnDodaj_Click);
            // 
            // tbPrezime
            // 
            this.tbPrezime.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPrezime.Location = new System.Drawing.Point(11, 96);
            this.tbPrezime.Margin = new System.Windows.Forms.Padding(2);
            this.tbPrezime.Name = "tbPrezime";
            this.tbPrezime.Size = new System.Drawing.Size(197, 26);
            this.tbPrezime.TabIndex = 22;
            // 
            // tbKorisnickoIme
            // 
            this.tbKorisnickoIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKorisnickoIme.Location = new System.Drawing.Point(11, 143);
            this.tbKorisnickoIme.Margin = new System.Windows.Forms.Padding(2);
            this.tbKorisnickoIme.Name = "tbKorisnickoIme";
            this.tbKorisnickoIme.Size = new System.Drawing.Size(197, 26);
            this.tbKorisnickoIme.TabIndex = 12;
            this.tbKorisnickoIme.TextChanged += new System.EventHandler(this.tbKorisnickoIme_TextChanged);
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIme.Location = new System.Drawing.Point(11, 29);
            this.lblIme.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(34, 17);
            this.lblIme.TabIndex = 21;
            this.lblIme.Text = "Ime:";
            this.lblIme.Click += new System.EventHandler(this.lblIme_Click);
            // 
            // tbSifra
            // 
            this.tbSifra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSifra.Location = new System.Drawing.Point(11, 190);
            this.tbSifra.Margin = new System.Windows.Forms.Padding(2);
            this.tbSifra.Name = "tbSifra";
            this.tbSifra.Size = new System.Drawing.Size(197, 26);
            this.tbSifra.TabIndex = 13;
            this.tbSifra.TextChanged += new System.EventHandler(this.txtLozinka_TextChanged);
            // 
            // tbIme
            // 
            this.tbIme.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbIme.Location = new System.Drawing.Point(11, 50);
            this.tbIme.Margin = new System.Windows.Forms.Padding(2);
            this.tbIme.Name = "tbIme";
            this.tbIme.Size = new System.Drawing.Size(197, 26);
            this.tbIme.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(11, 124);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "Korisnicko ime:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 171);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "Lozinka";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 9);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 17);
            this.label3.TabIndex = 25;
            this.label3.Text = "Dodaj Admina";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(340, 9);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 17);
            this.label4.TabIndex = 26;
            this.label4.Text = "Azuriraj Admina";
            // 
            // AzurirajAdmine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 372);
            this.Controls.Add(this.btnSacuvaj);
            this.Controls.Add(this.cmbAdmini);
            this.Controls.Add(btnObrisi);
            this.Controls.Add(this.tbSifraNova);
            this.Controls.Add(this.lblAzurirajKorIme);
            this.Controls.Add(this.lblAzurirajPrezime);
            this.Controls.Add(this.lblAzurirajLozinku);
            this.Controls.Add(this.tbPrezimeNovo);
            this.Controls.Add(this.tbKorisnickoImeNovo);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbImeNovo);
            this.Controls.Add(this.lblOdabir);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.lblPrezime);
            this.Controls.Add(this.tbSifra);
            this.Controls.Add(this.tbKorisnickoIme);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblAzurirajIme);
            this.Controls.Add(this.tbPrezime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblIme);
            this.Controls.Add(this.tbIme);
            this.Name = "AzurirajAdmine";
            this.Text = "AzurirajAdmine";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmbAdmini;
        private System.Windows.Forms.Label lblOdabir;
        private System.Windows.Forms.Button btnSacuvaj;
        private System.Windows.Forms.Label lblAzurirajPrezime;
        private System.Windows.Forms.TextBox tbImeNovo;
        private System.Windows.Forms.Label lblAzurirajKorIme;
        private System.Windows.Forms.TextBox tbPrezimeNovo;
        private System.Windows.Forms.TextBox tbSifraNova;
        private System.Windows.Forms.Label lblAzurirajLozinku;
        private System.Windows.Forms.TextBox tbKorisnickoImeNovo;
        private System.Windows.Forms.Label lblAzurirajIme;
        private System.Windows.Forms.Label lblPrezime;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.TextBox tbPrezime;
        private System.Windows.Forms.TextBox tbKorisnickoIme;
        private System.Windows.Forms.Label lblIme;
        private System.Windows.Forms.TextBox tbSifra;
        private System.Windows.Forms.TextBox tbIme;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}