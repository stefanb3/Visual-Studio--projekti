﻿
namespace Projekat1Konacno
{
    partial class KlijentIzmjenaREzervacija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnBrisanjeRezervacije;
            System.Windows.Forms.Button btnUkloniOznacenoJelo;
            System.Windows.Forms.Button btnSacuvajRezervaciju;
            System.Windows.Forms.Button btnDodajJeloNaRezervaciju;
            System.Windows.Forms.Button btnUkidanjePriloga;
            System.Windows.Forms.Button btnDodavanjePrilogaJelu;
            System.Windows.Forms.Button btnUkiniDodatak;
            System.Windows.Forms.Button btnDodajDodatak;
            this.lblUkupnaCenaJela = new System.Windows.Forms.Label();
            this.txtUkupnaCenaJela = new System.Windows.Forms.TextBox();
            this.txtKontaktRestorana = new System.Windows.Forms.TextBox();
            this.lblKontaktRestorana = new System.Windows.Forms.Label();
            this.txtAdresaRestorana = new System.Windows.Forms.TextBox();
            this.txtNazivRestorana = new System.Windows.Forms.TextBox();
            this.lblAdresaRestorana = new System.Windows.Forms.Label();
            this.lblNazivRestorana = new System.Windows.Forms.Label();
            this.txtUkupnaCena = new System.Windows.Forms.TextBox();
            this.lblUkupnaCena = new System.Windows.Forms.Label();
            this.lstbOdabranaJela = new System.Windows.Forms.ListBox();
            this.lblOdabranaJela = new System.Windows.Forms.Label();
            this.lblDodavanjeDodataka = new System.Windows.Forms.Label();
            this.lblOdabirJela = new System.Windows.Forms.Label();
            this.cmbOdabirJela = new System.Windows.Forms.ComboBox();
            this.lstbOmoguceniPrilozi = new System.Windows.Forms.ListBox();
            this.lstbOmoguceniDodaci = new System.Windows.Forms.ListBox();
            this.lblGramazaJela = new System.Windows.Forms.Label();
            this.rbtnObavezanPrilog = new System.Windows.Forms.RadioButton();
            this.lblOdabraniDodaci = new System.Windows.Forms.Label();
            this.lblOmoguceniPrilozi = new System.Windows.Forms.Label();
            this.cmbDodavanjeDodataka = new System.Windows.Forms.ComboBox();
            this.cmbDodavanjePriloga = new System.Windows.Forms.ComboBox();
            this.lblPrilog = new System.Windows.Forms.Label();
            this.txtCenaJela = new System.Windows.Forms.TextBox();
            this.lblCenaJela = new System.Windows.Forms.Label();
            this.lblOpisJela = new System.Windows.Forms.Label();
            this.txtOpisJela = new System.Windows.Forms.TextBox();
            this.txtGramazaJela = new System.Windows.Forms.TextBox();
            this.txtNazivJela = new System.Windows.Forms.TextBox();
            this.lblNazivJela = new System.Windows.Forms.Label();
            this.cmbOdabirRezervacije = new System.Windows.Forms.ComboBox();
            this.lblOdabirRezervacije = new System.Windows.Forms.Label();
            this.lblDatum = new System.Windows.Forms.Label();
            this.DatumRezervacije = new System.Windows.Forms.DateTimePicker();
            btnBrisanjeRezervacije = new System.Windows.Forms.Button();
            btnUkloniOznacenoJelo = new System.Windows.Forms.Button();
            btnSacuvajRezervaciju = new System.Windows.Forms.Button();
            btnDodajJeloNaRezervaciju = new System.Windows.Forms.Button();
            btnUkidanjePriloga = new System.Windows.Forms.Button();
            btnDodavanjePrilogaJelu = new System.Windows.Forms.Button();
            btnUkiniDodatak = new System.Windows.Forms.Button();
            btnDodajDodatak = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnBrisanjeRezervacije
            // 
            btnBrisanjeRezervacije.Location = new System.Drawing.Point(1009, 330);
            btnBrisanjeRezervacije.Margin = new System.Windows.Forms.Padding(2);
            btnBrisanjeRezervacije.Name = "btnBrisanjeRezervacije";
            btnBrisanjeRezervacije.Size = new System.Drawing.Size(243, 29);
            btnBrisanjeRezervacije.TabIndex = 187;
            btnBrisanjeRezervacije.Text = "Brisanje rezervacije";
            btnBrisanjeRezervacije.UseVisualStyleBackColor = true;
            btnBrisanjeRezervacije.Click += new System.EventHandler(this.btnBrisanjeRezervacije_Click);
            // 
            // lblUkupnaCenaJela
            // 
            this.lblUkupnaCenaJela.AutoSize = true;
            this.lblUkupnaCenaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUkupnaCenaJela.Location = new System.Drawing.Point(405, 442);
            this.lblUkupnaCenaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUkupnaCenaJela.Name = "lblUkupnaCenaJela";
            this.lblUkupnaCenaJela.Size = new System.Drawing.Size(122, 17);
            this.lblUkupnaCenaJela.TabIndex = 186;
            this.lblUkupnaCenaJela.Text = "Ukupna cena jela:";
            // 
            // btnUkloniOznacenoJelo
            // 
            btnUkloniOznacenoJelo.Location = new System.Drawing.Point(1008, 231);
            btnUkloniOznacenoJelo.Margin = new System.Windows.Forms.Padding(2);
            btnUkloniOznacenoJelo.Name = "btnUkloniOznacenoJelo";
            btnUkloniOznacenoJelo.Size = new System.Drawing.Size(243, 29);
            btnUkloniOznacenoJelo.TabIndex = 185;
            btnUkloniOznacenoJelo.Text = "Ukloni oznaceno jelo";
            btnUkloniOznacenoJelo.UseVisualStyleBackColor = true;
            btnUkloniOznacenoJelo.Click += new System.EventHandler(this.btnUkloniOznacenoJelo_Click);
            // 
            // txtUkupnaCenaJela
            // 
            this.txtUkupnaCenaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUkupnaCenaJela.Location = new System.Drawing.Point(576, 442);
            this.txtUkupnaCenaJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtUkupnaCenaJela.Name = "txtUkupnaCenaJela";
            this.txtUkupnaCenaJela.ReadOnly = true;
            this.txtUkupnaCenaJela.Size = new System.Drawing.Size(244, 26);
            this.txtUkupnaCenaJela.TabIndex = 184;
            // 
            // txtKontaktRestorana
            // 
            this.txtKontaktRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKontaktRestorana.Location = new System.Drawing.Point(141, 406);
            this.txtKontaktRestorana.Margin = new System.Windows.Forms.Padding(2);
            this.txtKontaktRestorana.Name = "txtKontaktRestorana";
            this.txtKontaktRestorana.ReadOnly = true;
            this.txtKontaktRestorana.Size = new System.Drawing.Size(244, 26);
            this.txtKontaktRestorana.TabIndex = 183;
            // 
            // lblKontaktRestorana
            // 
            this.lblKontaktRestorana.AutoSize = true;
            this.lblKontaktRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKontaktRestorana.Location = new System.Drawing.Point(11, 415);
            this.lblKontaktRestorana.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKontaktRestorana.Name = "lblKontaktRestorana";
            this.lblKontaktRestorana.Size = new System.Drawing.Size(125, 17);
            this.lblKontaktRestorana.TabIndex = 182;
            this.lblKontaktRestorana.Text = "Kontakt restorana:";
            // 
            // txtAdresaRestorana
            // 
            this.txtAdresaRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdresaRestorana.Location = new System.Drawing.Point(141, 373);
            this.txtAdresaRestorana.Margin = new System.Windows.Forms.Padding(2);
            this.txtAdresaRestorana.Name = "txtAdresaRestorana";
            this.txtAdresaRestorana.ReadOnly = true;
            this.txtAdresaRestorana.Size = new System.Drawing.Size(244, 26);
            this.txtAdresaRestorana.TabIndex = 181;
            // 
            // txtNazivRestorana
            // 
            this.txtNazivRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazivRestorana.Location = new System.Drawing.Point(141, 341);
            this.txtNazivRestorana.Margin = new System.Windows.Forms.Padding(2);
            this.txtNazivRestorana.Name = "txtNazivRestorana";
            this.txtNazivRestorana.ReadOnly = true;
            this.txtNazivRestorana.Size = new System.Drawing.Size(244, 26);
            this.txtNazivRestorana.TabIndex = 180;
            // 
            // lblAdresaRestorana
            // 
            this.lblAdresaRestorana.AutoSize = true;
            this.lblAdresaRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdresaRestorana.Location = new System.Drawing.Point(9, 382);
            this.lblAdresaRestorana.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAdresaRestorana.Name = "lblAdresaRestorana";
            this.lblAdresaRestorana.Size = new System.Drawing.Size(122, 17);
            this.lblAdresaRestorana.TabIndex = 179;
            this.lblAdresaRestorana.Text = "Adresa restorana:";
            // 
            // lblNazivRestorana
            // 
            this.lblNazivRestorana.AutoSize = true;
            this.lblNazivRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNazivRestorana.Location = new System.Drawing.Point(9, 341);
            this.lblNazivRestorana.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNazivRestorana.Name = "lblNazivRestorana";
            this.lblNazivRestorana.Size = new System.Drawing.Size(112, 17);
            this.lblNazivRestorana.TabIndex = 178;
            this.lblNazivRestorana.Text = "Naziv restorana:";
            // 
            // btnSacuvajRezervaciju
            // 
            btnSacuvajRezervaciju.Location = new System.Drawing.Point(1008, 297);
            btnSacuvajRezervaciju.Margin = new System.Windows.Forms.Padding(2);
            btnSacuvajRezervaciju.Name = "btnSacuvajRezervaciju";
            btnSacuvajRezervaciju.Size = new System.Drawing.Size(243, 29);
            btnSacuvajRezervaciju.TabIndex = 177;
            btnSacuvajRezervaciju.Text = "Potvrdjivanje rezervacije";
            btnSacuvajRezervaciju.UseVisualStyleBackColor = true;
            btnSacuvajRezervaciju.Click += new System.EventHandler(this.btnSacuvajRezervaciju_Click);
            // 
            // txtUkupnaCena
            // 
            this.txtUkupnaCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUkupnaCena.Location = new System.Drawing.Point(1008, 267);
            this.txtUkupnaCena.Margin = new System.Windows.Forms.Padding(2);
            this.txtUkupnaCena.Name = "txtUkupnaCena";
            this.txtUkupnaCena.ReadOnly = true;
            this.txtUkupnaCena.Size = new System.Drawing.Size(244, 26);
            this.txtUkupnaCena.TabIndex = 176;
            // 
            // lblUkupnaCena
            // 
            this.lblUkupnaCena.AutoSize = true;
            this.lblUkupnaCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUkupnaCena.Location = new System.Drawing.Point(848, 276);
            this.lblUkupnaCena.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUkupnaCena.Name = "lblUkupnaCena";
            this.lblUkupnaCena.Size = new System.Drawing.Size(96, 17);
            this.lblUkupnaCena.TabIndex = 175;
            this.lblUkupnaCena.Text = "Ukupna cena:";
            // 
            // lstbOdabranaJela
            // 
            this.lstbOdabranaJela.FormattingEnabled = true;
            this.lstbOdabranaJela.Location = new System.Drawing.Point(1008, 15);
            this.lstbOdabranaJela.Margin = new System.Windows.Forms.Padding(2);
            this.lstbOdabranaJela.Name = "lstbOdabranaJela";
            this.lstbOdabranaJela.Size = new System.Drawing.Size(244, 212);
            this.lstbOdabranaJela.TabIndex = 174;
            // 
            // lblOdabranaJela
            // 
            this.lblOdabranaJela.AutoSize = true;
            this.lblOdabranaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabranaJela.Location = new System.Drawing.Point(848, 15);
            this.lblOdabranaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabranaJela.Name = "lblOdabranaJela";
            this.lblOdabranaJela.Size = new System.Drawing.Size(156, 17);
            this.lblOdabranaJela.TabIndex = 173;
            this.lblOdabranaJela.Text = "Do sada odabrana jela:";
            // 
            // btnDodajJeloNaRezervaciju
            // 
            btnDodajJeloNaRezervaciju.Location = new System.Drawing.Point(576, 472);
            btnDodajJeloNaRezervaciju.Margin = new System.Windows.Forms.Padding(2);
            btnDodajJeloNaRezervaciju.Name = "btnDodajJeloNaRezervaciju";
            btnDodajJeloNaRezervaciju.Size = new System.Drawing.Size(243, 29);
            btnDodajJeloNaRezervaciju.TabIndex = 172;
            btnDodajJeloNaRezervaciju.Text = "Dodaj na rezervaciju";
            btnDodajJeloNaRezervaciju.UseVisualStyleBackColor = true;
            btnDodajJeloNaRezervaciju.Click += new System.EventHandler(this.btnDodajJeloNaRezervaciju_Click);
            // 
            // lblDodavanjeDodataka
            // 
            this.lblDodavanjeDodataka.AutoSize = true;
            this.lblDodavanjeDodataka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDodavanjeDodataka.Location = new System.Drawing.Point(386, 231);
            this.lblDodavanjeDodataka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDodavanjeDodataka.Name = "lblDodavanjeDodataka";
            this.lblDodavanjeDodataka.Size = new System.Drawing.Size(188, 17);
            this.lblDodavanjeDodataka.TabIndex = 171;
            this.lblDodavanjeDodataka.Text = "Dodavanje dodataka za jelo:";
            // 
            // lblOdabirJela
            // 
            this.lblOdabirJela.AutoSize = true;
            this.lblOdabirJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabirJela.Location = new System.Drawing.Point(11, 80);
            this.lblOdabirJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabirJela.Name = "lblOdabirJela";
            this.lblOdabirJela.Size = new System.Drawing.Size(81, 17);
            this.lblOdabirJela.TabIndex = 148;
            this.lblOdabirJela.Text = "Odabir jela:";
            // 
            // cmbOdabirJela
            // 
            this.cmbOdabirJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOdabirJela.FormattingEnabled = true;
            this.cmbOdabirJela.Location = new System.Drawing.Point(141, 72);
            this.cmbOdabirJela.Margin = new System.Windows.Forms.Padding(2);
            this.cmbOdabirJela.Name = "cmbOdabirJela";
            this.cmbOdabirJela.Size = new System.Drawing.Size(244, 25);
            this.cmbOdabirJela.TabIndex = 149;
            this.cmbOdabirJela.SelectedIndexChanged += new System.EventHandler(this.cmbOdabirJela_SelectedIndexChanged);
            // 
            // btnUkidanjePriloga
            // 
            btnUkidanjePriloga.Location = new System.Drawing.Point(578, 187);
            btnUkidanjePriloga.Margin = new System.Windows.Forms.Padding(2);
            btnUkidanjePriloga.Name = "btnUkidanjePriloga";
            btnUkidanjePriloga.Size = new System.Drawing.Size(245, 29);
            btnUkidanjePriloga.TabIndex = 170;
            btnUkidanjePriloga.Text = "Ukini oznaceni prilog\r\n";
            btnUkidanjePriloga.UseVisualStyleBackColor = true;
            btnUkidanjePriloga.Click += new System.EventHandler(this.btnUkidanjePriloga_Click);
            // 
            // btnDodavanjePrilogaJelu
            // 
            btnDodavanjePrilogaJelu.Location = new System.Drawing.Point(578, 37);
            btnDodavanjePrilogaJelu.Margin = new System.Windows.Forms.Padding(2);
            btnDodavanjePrilogaJelu.Name = "btnDodavanjePrilogaJelu";
            btnDodavanjePrilogaJelu.Size = new System.Drawing.Size(244, 29);
            btnDodavanjePrilogaJelu.TabIndex = 169;
            btnDodavanjePrilogaJelu.Text = "Dodaj oznaceni prilog";
            btnDodavanjePrilogaJelu.UseVisualStyleBackColor = true;
            btnDodavanjePrilogaJelu.Click += new System.EventHandler(this.btnDodavanjePrilogaJelu_Click);
            // 
            // btnUkiniDodatak
            // 
            btnUkiniDodatak.Location = new System.Drawing.Point(577, 403);
            btnUkiniDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnUkiniDodatak.Name = "btnUkiniDodatak";
            btnUkiniDodatak.Size = new System.Drawing.Size(243, 29);
            btnUkiniDodatak.TabIndex = 168;
            btnUkiniDodatak.Text = "Ukini oznaceni dodatak";
            btnUkiniDodatak.UseVisualStyleBackColor = true;
            btnUkiniDodatak.Click += new System.EventHandler(this.btnUkiniDodatak_Click);
            // 
            // lstbOmoguceniPrilozi
            // 
            this.lstbOmoguceniPrilozi.FormattingEnabled = true;
            this.lstbOmoguceniPrilozi.Location = new System.Drawing.Point(579, 75);
            this.lstbOmoguceniPrilozi.Margin = new System.Windows.Forms.Padding(2);
            this.lstbOmoguceniPrilozi.Name = "lstbOmoguceniPrilozi";
            this.lstbOmoguceniPrilozi.Size = new System.Drawing.Size(244, 95);
            this.lstbOmoguceniPrilozi.TabIndex = 167;
            // 
            // lstbOmoguceniDodaci
            // 
            this.lstbOmoguceniDodaci.FormattingEnabled = true;
            this.lstbOmoguceniDodaci.Location = new System.Drawing.Point(577, 297);
            this.lstbOmoguceniDodaci.Margin = new System.Windows.Forms.Padding(2);
            this.lstbOmoguceniDodaci.Name = "lstbOmoguceniDodaci";
            this.lstbOmoguceniDodaci.Size = new System.Drawing.Size(244, 95);
            this.lstbOmoguceniDodaci.TabIndex = 156;
            // 
            // btnDodajDodatak
            // 
            btnDodajDodatak.Location = new System.Drawing.Point(578, 252);
            btnDodajDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnDodajDodatak.Name = "btnDodajDodatak";
            btnDodajDodatak.Size = new System.Drawing.Size(243, 29);
            btnDodajDodatak.TabIndex = 166;
            btnDodajDodatak.Text = "Dodaj oznaceni dodatak";
            btnDodajDodatak.UseVisualStyleBackColor = true;
            btnDodajDodatak.Click += new System.EventHandler(this.btnDodajDodatak_Click);
            // 
            // lblGramazaJela
            // 
            this.lblGramazaJela.AutoSize = true;
            this.lblGramazaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGramazaJela.Location = new System.Drawing.Point(11, 143);
            this.lblGramazaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGramazaJela.Name = "lblGramazaJela";
            this.lblGramazaJela.Size = new System.Drawing.Size(96, 17);
            this.lblGramazaJela.TabIndex = 154;
            this.lblGramazaJela.Text = "Gramaza jela:";
            // 
            // rbtnObavezanPrilog
            // 
            this.rbtnObavezanPrilog.AutoSize = true;
            this.rbtnObavezanPrilog.Enabled = false;
            this.rbtnObavezanPrilog.Location = new System.Drawing.Point(405, 194);
            this.rbtnObavezanPrilog.Margin = new System.Windows.Forms.Padding(2);
            this.rbtnObavezanPrilog.Name = "rbtnObavezanPrilog";
            this.rbtnObavezanPrilog.Size = new System.Drawing.Size(112, 17);
            this.rbtnObavezanPrilog.TabIndex = 165;
            this.rbtnObavezanPrilog.TabStop = true;
            this.rbtnObavezanPrilog.Text = "Prilog je obavezan";
            this.rbtnObavezanPrilog.UseVisualStyleBackColor = true;
            // 
            // lblOdabraniDodaci
            // 
            this.lblOdabraniDodaci.AutoSize = true;
            this.lblOdabraniDodaci.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabraniDodaci.Location = new System.Drawing.Point(389, 297);
            this.lblOdabraniDodaci.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabraniDodaci.Name = "lblOdabraniDodaci";
            this.lblOdabraniDodaci.Size = new System.Drawing.Size(130, 17);
            this.lblOdabraniDodaci.TabIndex = 164;
            this.lblOdabraniDodaci.Text = "Omoguceni dodaci:";
            // 
            // lblOmoguceniPrilozi
            // 
            this.lblOmoguceniPrilozi.AutoSize = true;
            this.lblOmoguceniPrilozi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOmoguceniPrilozi.Location = new System.Drawing.Point(402, 75);
            this.lblOmoguceniPrilozi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOmoguceniPrilozi.Name = "lblOmoguceniPrilozi";
            this.lblOmoguceniPrilozi.Size = new System.Drawing.Size(125, 17);
            this.lblOmoguceniPrilozi.TabIndex = 161;
            this.lblOmoguceniPrilozi.Text = "Omoguceni prilozi:";
            // 
            // cmbDodavanjeDodataka
            // 
            this.cmbDodavanjeDodataka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDodavanjeDodataka.FormattingEnabled = true;
            this.cmbDodavanjeDodataka.Location = new System.Drawing.Point(578, 223);
            this.cmbDodavanjeDodataka.Margin = new System.Windows.Forms.Padding(2);
            this.cmbDodavanjeDodataka.Name = "cmbDodavanjeDodataka";
            this.cmbDodavanjeDodataka.Size = new System.Drawing.Size(244, 25);
            this.cmbDodavanjeDodataka.TabIndex = 163;
            // 
            // cmbDodavanjePriloga
            // 
            this.cmbDodavanjePriloga.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbDodavanjePriloga.FormattingEnabled = true;
            this.cmbDodavanjePriloga.Location = new System.Drawing.Point(578, 7);
            this.cmbDodavanjePriloga.Margin = new System.Windows.Forms.Padding(2);
            this.cmbDodavanjePriloga.Name = "cmbDodavanjePriloga";
            this.cmbDodavanjePriloga.Size = new System.Drawing.Size(244, 25);
            this.cmbDodavanjePriloga.TabIndex = 160;
            this.cmbDodavanjePriloga.SelectedIndexChanged += new System.EventHandler(this.cmbDodavanjePriloga_SelectedIndexChanged);
            // 
            // lblPrilog
            // 
            this.lblPrilog.AutoSize = true;
            this.lblPrilog.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrilog.Location = new System.Drawing.Point(402, 10);
            this.lblPrilog.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPrilog.Name = "lblPrilog";
            this.lblPrilog.Size = new System.Drawing.Size(172, 17);
            this.lblPrilog.TabIndex = 159;
            this.lblPrilog.Text = "Dodavanje priloga za jelo:";
            // 
            // txtCenaJela
            // 
            this.txtCenaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCenaJela.Location = new System.Drawing.Point(141, 297);
            this.txtCenaJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtCenaJela.Name = "txtCenaJela";
            this.txtCenaJela.ReadOnly = true;
            this.txtCenaJela.Size = new System.Drawing.Size(244, 26);
            this.txtCenaJela.TabIndex = 158;
            // 
            // lblCenaJela
            // 
            this.lblCenaJela.AutoSize = true;
            this.lblCenaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCenaJela.Location = new System.Drawing.Point(11, 297);
            this.lblCenaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCenaJela.Name = "lblCenaJela";
            this.lblCenaJela.Size = new System.Drawing.Size(71, 17);
            this.lblCenaJela.TabIndex = 157;
            this.lblCenaJela.Text = "Cena jela:";
            // 
            // lblOpisJela
            // 
            this.lblOpisJela.AutoSize = true;
            this.lblOpisJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOpisJela.Location = new System.Drawing.Point(11, 187);
            this.lblOpisJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOpisJela.Name = "lblOpisJela";
            this.lblOpisJela.Size = new System.Drawing.Size(67, 17);
            this.lblOpisJela.TabIndex = 155;
            this.lblOpisJela.Text = "Opis jela:";
            // 
            // txtOpisJela
            // 
            this.txtOpisJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOpisJela.Location = new System.Drawing.Point(141, 187);
            this.txtOpisJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtOpisJela.Multiline = true;
            this.txtOpisJela.Name = "txtOpisJela";
            this.txtOpisJela.ReadOnly = true;
            this.txtOpisJela.Size = new System.Drawing.Size(244, 93);
            this.txtOpisJela.TabIndex = 151;
            // 
            // txtGramazaJela
            // 
            this.txtGramazaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramazaJela.Location = new System.Drawing.Point(141, 143);
            this.txtGramazaJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtGramazaJela.Name = "txtGramazaJela";
            this.txtGramazaJela.ReadOnly = true;
            this.txtGramazaJela.Size = new System.Drawing.Size(244, 26);
            this.txtGramazaJela.TabIndex = 150;
            // 
            // txtNazivJela
            // 
            this.txtNazivJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazivJela.Location = new System.Drawing.Point(141, 107);
            this.txtNazivJela.Margin = new System.Windows.Forms.Padding(2);
            this.txtNazivJela.Name = "txtNazivJela";
            this.txtNazivJela.ReadOnly = true;
            this.txtNazivJela.Size = new System.Drawing.Size(244, 26);
            this.txtNazivJela.TabIndex = 152;
            // 
            // lblNazivJela
            // 
            this.lblNazivJela.AutoSize = true;
            this.lblNazivJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNazivJela.Location = new System.Drawing.Point(11, 116);
            this.lblNazivJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNazivJela.Name = "lblNazivJela";
            this.lblNazivJela.Size = new System.Drawing.Size(73, 17);
            this.lblNazivJela.TabIndex = 153;
            this.lblNazivJela.Text = "Naziv jela:";
            // 
            // cmbOdabirRezervacije
            // 
            this.cmbOdabirRezervacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOdabirRezervacije.FormattingEnabled = true;
            this.cmbOdabirRezervacije.Location = new System.Drawing.Point(141, 37);
            this.cmbOdabirRezervacije.Margin = new System.Windows.Forms.Padding(2);
            this.cmbOdabirRezervacije.Name = "cmbOdabirRezervacije";
            this.cmbOdabirRezervacije.Size = new System.Drawing.Size(244, 25);
            this.cmbOdabirRezervacije.TabIndex = 147;
            this.cmbOdabirRezervacije.SelectedIndexChanged += new System.EventHandler(this.cmbOdabirRezervacije_SelectedIndexChanged);
            // 
            // lblOdabirRezervacije
            // 
            this.lblOdabirRezervacije.AutoSize = true;
            this.lblOdabirRezervacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabirRezervacije.Location = new System.Drawing.Point(9, 45);
            this.lblOdabirRezervacije.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabirRezervacije.Name = "lblOdabirRezervacije";
            this.lblOdabirRezervacije.Size = new System.Drawing.Size(128, 17);
            this.lblOdabirRezervacije.TabIndex = 146;
            this.lblOdabirRezervacije.Text = "Odabir rezervacije:";
            // 
            // lblDatum
            // 
            this.lblDatum.AutoSize = true;
            this.lblDatum.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatum.Location = new System.Drawing.Point(9, 10);
            this.lblDatum.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDatum.Name = "lblDatum";
            this.lblDatum.Size = new System.Drawing.Size(126, 17);
            this.lblDatum.TabIndex = 145;
            this.lblDatum.Text = "Datum rezervacije:\r\n";
            // 
            // DatumRezervacije
            // 
            this.DatumRezervacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DatumRezervacije.Location = new System.Drawing.Point(141, 4);
            this.DatumRezervacije.Margin = new System.Windows.Forms.Padding(2);
            this.DatumRezervacije.Name = "DatumRezervacije";
            this.DatumRezervacije.Size = new System.Drawing.Size(244, 23);
            this.DatumRezervacije.TabIndex = 144;
            // 
            // KlijentIzmjenaREzervacija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1372, 523);
            this.Controls.Add(btnBrisanjeRezervacije);
            this.Controls.Add(this.lblUkupnaCenaJela);
            this.Controls.Add(btnUkloniOznacenoJelo);
            this.Controls.Add(this.txtUkupnaCenaJela);
            this.Controls.Add(this.txtKontaktRestorana);
            this.Controls.Add(this.lblKontaktRestorana);
            this.Controls.Add(this.txtAdresaRestorana);
            this.Controls.Add(this.txtNazivRestorana);
            this.Controls.Add(this.lblAdresaRestorana);
            this.Controls.Add(this.lblNazivRestorana);
            this.Controls.Add(btnSacuvajRezervaciju);
            this.Controls.Add(this.txtUkupnaCena);
            this.Controls.Add(this.lblUkupnaCena);
            this.Controls.Add(this.lstbOdabranaJela);
            this.Controls.Add(this.lblOdabranaJela);
            this.Controls.Add(btnDodajJeloNaRezervaciju);
            this.Controls.Add(this.lblDodavanjeDodataka);
            this.Controls.Add(this.lblOdabirJela);
            this.Controls.Add(this.cmbOdabirJela);
            this.Controls.Add(btnUkidanjePriloga);
            this.Controls.Add(btnDodavanjePrilogaJelu);
            this.Controls.Add(btnUkiniDodatak);
            this.Controls.Add(this.lstbOmoguceniPrilozi);
            this.Controls.Add(this.lstbOmoguceniDodaci);
            this.Controls.Add(btnDodajDodatak);
            this.Controls.Add(this.lblGramazaJela);
            this.Controls.Add(this.rbtnObavezanPrilog);
            this.Controls.Add(this.lblOdabraniDodaci);
            this.Controls.Add(this.lblOmoguceniPrilozi);
            this.Controls.Add(this.cmbDodavanjeDodataka);
            this.Controls.Add(this.cmbDodavanjePriloga);
            this.Controls.Add(this.lblPrilog);
            this.Controls.Add(this.txtCenaJela);
            this.Controls.Add(this.lblCenaJela);
            this.Controls.Add(this.lblOpisJela);
            this.Controls.Add(this.txtOpisJela);
            this.Controls.Add(this.txtGramazaJela);
            this.Controls.Add(this.txtNazivJela);
            this.Controls.Add(this.lblNazivJela);
            this.Controls.Add(this.cmbOdabirRezervacije);
            this.Controls.Add(this.lblOdabirRezervacije);
            this.Controls.Add(this.lblDatum);
            this.Controls.Add(this.DatumRezervacije);
            this.Name = "KlijentIzmjenaREzervacija";
            this.Text = "KlijentIzmjenaREzervacija";
            this.Load += new System.EventHandler(this.KlijentIzmjenaREzervacija_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblUkupnaCenaJela;
        private System.Windows.Forms.TextBox txtUkupnaCenaJela;
        private System.Windows.Forms.TextBox txtKontaktRestorana;
        private System.Windows.Forms.Label lblKontaktRestorana;
        private System.Windows.Forms.TextBox txtAdresaRestorana;
        private System.Windows.Forms.TextBox txtNazivRestorana;
        private System.Windows.Forms.Label lblAdresaRestorana;
        private System.Windows.Forms.Label lblNazivRestorana;
        private System.Windows.Forms.TextBox txtUkupnaCena;
        private System.Windows.Forms.Label lblUkupnaCena;
        private System.Windows.Forms.ListBox lstbOdabranaJela;
        private System.Windows.Forms.Label lblOdabranaJela;
        private System.Windows.Forms.Label lblDodavanjeDodataka;
        private System.Windows.Forms.Label lblOdabirJela;
        private System.Windows.Forms.ComboBox cmbOdabirJela;
        private System.Windows.Forms.ListBox lstbOmoguceniPrilozi;
        private System.Windows.Forms.ListBox lstbOmoguceniDodaci;
        private System.Windows.Forms.Label lblGramazaJela;
        private System.Windows.Forms.RadioButton rbtnObavezanPrilog;
        private System.Windows.Forms.Label lblOdabraniDodaci;
        private System.Windows.Forms.Label lblOmoguceniPrilozi;
        private System.Windows.Forms.ComboBox cmbDodavanjeDodataka;
        private System.Windows.Forms.ComboBox cmbDodavanjePriloga;
        private System.Windows.Forms.Label lblPrilog;
        private System.Windows.Forms.TextBox txtCenaJela;
        private System.Windows.Forms.Label lblCenaJela;
        private System.Windows.Forms.Label lblOpisJela;
        private System.Windows.Forms.TextBox txtOpisJela;
        private System.Windows.Forms.TextBox txtGramazaJela;
        private System.Windows.Forms.TextBox txtNazivJela;
        private System.Windows.Forms.Label lblNazivJela;
        private System.Windows.Forms.ComboBox cmbOdabirRezervacije;
        private System.Windows.Forms.Label lblOdabirRezervacije;
        private System.Windows.Forms.Label lblDatum;
        private System.Windows.Forms.DateTimePicker DatumRezervacije;
    }
}