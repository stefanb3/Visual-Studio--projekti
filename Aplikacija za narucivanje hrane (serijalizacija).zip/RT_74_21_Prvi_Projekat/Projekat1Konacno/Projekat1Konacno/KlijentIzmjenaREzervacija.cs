﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class KlijentIzmjenaREzervacija : Form
    {
        int prijavljeniKorisnik;
        List<Rezervacija> rezervacije = new List<Rezervacija>();
        List<Restoran> restorani = new List<Restoran>();
        Restoran pomocnaRestoran = new Restoran(0, "", "", "");
        List<int> ucitaneRezervacije = new List<int>();
        List<Prilog> sviPrilozi = new List<Prilog>();
        List<Dodatak> sviDodaci = new List<Dodatak>();
        List<Jelo> ucitanaJela = new List<Jelo>();
        List<int> dostupniPriloziZaJelo = new List<int>();
        List<int> jelaDostupnaURestoranu = new List<int>();
        List<int> dostupniDodaciZaJelo = new List<int>();
        double ukupnaCenaJela = 0;
        List<int> odabraniPriloziZaJelo = new List<int>();
        List<int> odabraniDodaciZaJelo = new List<int>();
        Jelo jeloPomocna = new Jelo();
        Rezervacija pomocnaRezervacija = new Rezervacija();
        string nazivDatoteke1 = "rezervacije.bin";
        string nazivDatoteke2 = "restorani.bin";
        string nazivDatoteke3 = "prilozi.bin";
        string nazivDatoteke4 = "dodaci.bin";
        string nazivDatoteke5 = "jela.bin";
        string nazivDatoteke6 = "rezervacije.bin";

        public KlijentIzmjenaREzervacija(int idKorisnika)
        {
            InitializeComponent();
            prijavljeniKorisnik = idKorisnika;
            ucitajRestorane();
            ucitajRezervacije();
            prikazRezervacija();
            ucitajPriloge();
            ucitajDodatke();
            ucitajJela();
            DatumRezervacije.Enabled = false;
        }

        private void KlijentIzmjenaREzervacija_Load(object sender, EventArgs e)
        {

        }




        void ucitajRezervacije()
        {
            if (File.Exists(nazivDatoteke1))
            {
                FileStream fs = new FileStream(nazivDatoteke1, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                rezervacije = binaryFormatter.Deserialize(fs) as List<Rezervacija>;
                fs.Dispose();
            }
            else
            {
                List<Rezervacija> pomocnaRezervacija = new List<Rezervacija>();
                List<Jelo> pomocna = new List<Jelo>();
                List<int> pomocnaLista = new List<int>();
                pomocnaLista.Add(0);
                pomocna.Add(new Jelo(0, "default", 0, "default", 0.0, pomocnaLista, pomocnaLista, false, 0));
                pomocnaRezervacija.Add(new Rezervacija(DateTime.Now, pomocna, 0.0, 0, 0));

                FileStream fs = new FileStream(nazivDatoteke1, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, pomocnaRezervacija);

                fs.Dispose();

                ucitajRezervacije();
            }
        }
        void prikazRezervacija()
        {
            for (int i = 0; i < rezervacije.Count; i++)
            {
                if (rezervacije[i].IdKorisnika == prijavljeniKorisnik)
                {
                    for (int j = 0; j < restorani.Count; j++)
                    {
                        if (restorani[j].IdRestorana == rezervacije[i].IdRestorana)
                        {
                            pomocnaRestoran.NazivRestorana = restorani[j].NazivRestorana;
                        }
                    }
                    cmbOdabirRezervacije.Items.Add(rezervacije[i].DatumRezervacije.Day + "/" + rezervacije[i].DatumRezervacije.Month + "/" + rezervacije[i].DatumRezervacije.Year + " " + pomocnaRestoran.NazivRestorana + ", " + rezervacije[i].UkupnaCena + "RSD");
                    ucitaneRezervacije.Add(i);
                }
            }
        }
        void ucitajRestorane()
        {
            if (File.Exists(nazivDatoteke2))
            {
                FileStream fs = new FileStream(nazivDatoteke2, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                restorani = binaryFormatter.Deserialize(fs) as List<Restoran>;
                fs.Dispose();
            }
            else
            {
                List<Restoran> restoran = new List<Restoran>();
                restoran.Add(new Restoran(0, "default", "default", "default"));
                FileStream fs = new FileStream(nazivDatoteke2, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, restoran);

                fs.Dispose();

                ucitajRestorane();
            }
        }
        void ucitajPriloge()
        {
            if (File.Exists(nazivDatoteke3))
            {
                FileStream fs = new FileStream(nazivDatoteke3, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter(); //Deserijalizujemo datoteku kako bi smo kasnije omogucili prijavu
                sviPrilozi = binaryFormatter.Deserialize(fs) as List<Prilog>;
                fs.Dispose();
            }
            else
            {
                List<Prilog> prilozi = new List<Prilog>();
                prilozi.Add(new Prilog(0, "default", 0.0));
                FileStream fs = new FileStream(nazivDatoteke3, FileMode.Create); //dodajemo default prilog koji ce nam omguciti da korisnik odabere da ne zeli prilog
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, prilozi);

                fs.Dispose();

                ucitajPriloge();
            }
        }
        void ucitajDodatke()
        {
            if (File.Exists(nazivDatoteke4))
            {
                FileStream fs = new FileStream(nazivDatoteke4, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                sviDodaci = binaryFormatter.Deserialize(fs) as List<Dodatak>;
                fs.Dispose();
            }
            else
            {
                List<Dodatak> dodatak = new List<Dodatak>();
                dodatak.Add(new Dodatak(0, "default", 0, 0));
                FileStream fs = new FileStream(nazivDatoteke4, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, dodatak);

                fs.Dispose();

                ucitajDodatke();
            }
        }
        void ucitajJela()
        {
            if (File.Exists(nazivDatoteke5))
            {
                FileStream fs = new FileStream(nazivDatoteke5, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                ucitanaJela = binaryFormatter.Deserialize(fs) as List<Jelo>;
                fs.Dispose();
            }
            else
            {
                List<Jelo> jelaPom = new List<Jelo>();
                List<int> pom = new List<int>();
                pom.Add(0);
                jelaPom.Add(new Jelo(0, "default", 0, "default", 0.0, pom, pom, false, 0));
                FileStream fs = new FileStream(nazivDatoteke5, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, jelaPom);

                fs.Dispose();

                ucitajJela();
            }
        }
        void ucitajPrilogeZaJelo(int idJela)
        {
            dostupniPriloziZaJelo.Clear();
            for (int i = 0; i < ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].DostupniPrilozi.Count; i++)
            {
                for (int j = 0; j < sviPrilozi.Count; j++)
                {
                    if (ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].DostupniPrilozi[i] == sviPrilozi[j].IdPrilog)
                    {
                        cmbDodavanjePriloga.Items.Add(sviPrilozi[j].NazivPriloga + ", " + sviPrilozi[j].CenaPriloga + "RSD");
                        dostupniPriloziZaJelo.Add(j);
                    }
                }
            }
        }
        void ucitajDodatkeZaJelo(int idJela)
        {
            dostupniDodaciZaJelo.Clear();
            for (int i = 0; i < ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].DostupniDodaci.Count; i++)
            {
                for (int j = 0; j < sviDodaci.Count; j++)
                {
                    if (ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].DostupniDodaci[i] == sviDodaci[j].IdDodatka)
                    {
                        cmbDodavanjeDodataka.Items.Add(sviDodaci[j].NazivDodatka + ", " + sviDodaci[j].GramazaDodatka + "g, " + sviDodaci[j].CenaDodatka + "RSD");
                        dostupniDodaciZaJelo.Add(j);
                    }
                }
            }
        }
        void upisiRezervacije()
        {
            FileStream fs = new FileStream(nazivDatoteke6, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, rezervacije);

            fs.Dispose();
        }

        private void cmbOdabirRezervacije_SelectedIndexChanged(object sender, EventArgs e)
        {

            DatumRezervacije.Value = rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]].DatumRezervacije;

            lstbOdabranaJela.Items.Clear();
            lstbOmoguceniDodaci.Items.Clear();
            lstbOmoguceniPrilozi.Items.Clear();

            pomocnaRezervacija = rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]];

            if (rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]].DatumRezervacije < DateTime.Now)
            {
                MessageBox.Show("Posto je datum ove rezervacije prosao nije moguca izmena iste");
            }
            else
            {
                pomocnaRestoran = null;
                for (int i = 0; i < restorani.Count; i++)
                {
                    if (restorani[i].IdRestorana == rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]].IdRestorana)
                    {
                        pomocnaRestoran = restorani[i];
                    }
                }
                txtNazivRestorana.Text = pomocnaRestoran.NazivRestorana;
                txtAdresaRestorana.Text = pomocnaRestoran.AdresaRestorana;
                txtKontaktRestorana.Text = pomocnaRestoran.KontaktRestorana;

                for (int i = 1; i < rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]].OdabranaJela.Count; i++)
                {
                    lstbOdabranaJela.Items.Add(rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]].OdabranaJela[i].NazivJela);
                }

                for (int i = 0; i < ucitanaJela.Count; i++)
                {
                    if (ucitanaJela[i].Id_restoran == pomocnaRestoran.IdRestorana)
                    {
                        cmbOdabirJela.Items.Add(ucitanaJela[i].NazivJela + ", " + ucitanaJela[i].CenaJela + "RSD, " + ucitanaJela[i].GramazaJela + "g");
                        jelaDostupnaURestoranu.Add(i);
                    }
                }
            }
        }

        private void cmbOdabirJela_SelectedIndexChanged(object sender, EventArgs e)
        {
            ukupnaCenaJela = 0;
            odabraniPriloziZaJelo.Clear();
            odabraniDodaciZaJelo.Clear();
            lstbOmoguceniPrilozi.Items.Clear();
            lstbOmoguceniDodaci.Items.Clear();
            cmbDodavanjeDodataka.Items.Clear();
            cmbDodavanjePriloga.Items.Clear();
            dostupniDodaciZaJelo.Clear();
            dostupniPriloziZaJelo.Clear();

            txtNazivJela.Text = ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].NazivJela;
            txtGramazaJela.Text = ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].GramazaJela.ToString() + "g";
            txtOpisJela.Text = ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].OpisJela;
            txtCenaJela.Text = ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].CenaJela.ToString() + "RSD";
            if (ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].ObavezniPrilog)
            {
                rbtnObavezanPrilog.Checked = true;
                rbtnObavezanPrilog.Enabled = true;
            }

            jeloPomocna = ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]];

            ukupnaCenaJela += ucitanaJela[jelaDostupnaURestoranu[cmbOdabirJela.SelectedIndex]].CenaJela;
            txtUkupnaCenaJela.Text = ukupnaCenaJela.ToString() + "RSD";

            ucitajPrilogeZaJelo(pomocnaRestoran.IdRestorana);
            ucitajDodatkeZaJelo(pomocnaRestoran.IdRestorana);
        }

        private void cmbDodavanjePriloga_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void btnUkidanjePriloga_Click(object sender, EventArgs e)
        {
            if (lstbOmoguceniPrilozi.SelectedIndex != -1 && lstbOmoguceniPrilozi.Items.Count != 0)
            {
                ukupnaCenaJela -= sviPrilozi[odabraniPriloziZaJelo[lstbOmoguceniPrilozi.SelectedIndex]].CenaPriloga;
                txtUkupnaCenaJela.Text = ukupnaCenaJela.ToString() + "RSD";
                odabraniPriloziZaJelo.RemoveAt(lstbOmoguceniPrilozi.SelectedIndex);
                lstbOmoguceniPrilozi.Items.RemoveAt(lstbOmoguceniPrilozi.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Neuspelo ukidanje priloga");
            }
        }

        private void btnDodajDodatak_Click(object sender, EventArgs e)
        {
            bool vecjeodabran = false;
            for (int i = 0; i < odabraniDodaciZaJelo.Count; i++)
            {
                if (sviDodaci[cmbDodavanjeDodataka.SelectedIndex + 1].IdDodatka == odabraniDodaciZaJelo[i])
                {
                    vecjeodabran = true;
                }
            }
            if (vecjeodabran)
            {
                MessageBox.Show("Dodatak koji pokusavate da odaberete vec postoji u listi odabranih dodataka");
            }
            else if (cmbDodavanjeDodataka.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali dodatak koji zelite da dodate");
            }
            else if (cmbOdabirJela.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali jelo za koje zelite da dodate");
            }
            else
            {
                ukupnaCenaJela += sviDodaci[cmbDodavanjeDodataka.SelectedIndex + 1].CenaDodatka;
                txtUkupnaCenaJela.Text = ukupnaCenaJela.ToString() + "RSD";
                lstbOmoguceniDodaci.Items.Add(sviDodaci[cmbDodavanjeDodataka.SelectedIndex + 1].NazivDodatka + ", " + sviDodaci[cmbDodavanjeDodataka.SelectedIndex + 1].GramazaDodatka + "g, " + sviDodaci[cmbDodavanjeDodataka.SelectedIndex + 1].CenaDodatka + "RSD");
                odabraniDodaciZaJelo.Add(sviDodaci[cmbDodavanjeDodataka.SelectedIndex + 1].IdDodatka);
            }
        }

        private void btnUkiniDodatak_Click(object sender, EventArgs e)
        {
            if (cmbDodavanjeDodataka.Items.Count != 0 && lstbOmoguceniDodaci.SelectedIndex != -1)
            {
                ukupnaCenaJela -= sviDodaci[odabraniDodaciZaJelo[lstbOmoguceniDodaci.SelectedIndex]].CenaDodatka;
                txtUkupnaCenaJela.Text = ukupnaCenaJela.ToString() + "RSD";
                odabraniDodaciZaJelo.RemoveAt(lstbOmoguceniDodaci.SelectedIndex);
                lstbOmoguceniDodaci.Items.RemoveAt(lstbOmoguceniDodaci.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Neuspesno ukidanje dodatka");
            }
        }

        private void btnDodajJeloNaRezervaciju_Click(object sender, EventArgs e)
        {
            if (rbtnObavezanPrilog.Checked && lstbOmoguceniPrilozi.Items.Count == 0)
            {
                MessageBox.Show("Za ovo jelo je obavezno odabrati prilog");
            }
            else if (DatumRezervacije.Value.Date < DateTime.Now)
            {
                MessageBox.Show("Izabrani datum ne moze biti u proslosti");
            }
            else
            {
                jeloPomocna.OdabraniPrilozi.AddRange(odabraniPriloziZaJelo);
                jeloPomocna.OdabraniDodaci.AddRange(odabraniDodaciZaJelo);

                pomocnaRezervacija.IdKorisnika = prijavljeniKorisnik;
                pomocnaRezervacija.DatumRezervacije = DatumRezervacije.Value.Date;
                DatumRezervacije.Enabled = false;
                pomocnaRezervacija.UkupnaCena += ukupnaCenaJela;
                pomocnaRezervacija.OdabranaJela.Add(jeloPomocna);
                pomocnaRezervacija.IdRestorana = pomocnaRestoran.IdRestorana;

                ukupnaCenaJela = 0;
                txtNazivJela.Text = "";
                txtOpisJela.Text = "";
                txtGramazaJela.Text = "";
                txtCenaJela.Text = "";
                lstbOmoguceniDodaci.Items.Clear();
                lstbOmoguceniPrilozi.Items.Clear();

                txtUkupnaCena.Text = pomocnaRezervacija.UkupnaCena.ToString() + "RSD";

                lstbOdabranaJela.Items.Clear();
                for (int i = 1; i < pomocnaRezervacija.OdabranaJela.Count; i++)
                {
                    lstbOdabranaJela.Items.Add(pomocnaRezervacija.OdabranaJela[i].NazivJela + ", " + pomocnaRezervacija.OdabranaJela[i].GramazaJela + "g");
                }
            }
        }

        private void btnUkloniOznacenoJelo_Click(object sender, EventArgs e)
        {
            if (lstbOdabranaJela.SelectedIndex != -1)
            {
                pomocnaRezervacija.OdabranaJela.RemoveAt(lstbOdabranaJela.SelectedIndex);
                lstbOdabranaJela.Items.RemoveAt(lstbOdabranaJela.SelectedIndex);
            }
        }

        private void btnSacuvajRezervaciju_Click(object sender, EventArgs e)
        {
            rezervacije[ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]] = pomocnaRezervacija;

            pomocnaRezervacija = null;

            upisiRezervacije();

            MessageBox.Show("Uspesno ste sacuvali rezervaciju");

            this.Close();
        }

        private void btnBrisanjeRezervacije_Click(object sender, EventArgs e)
        {
            rezervacije.RemoveAt(ucitaneRezervacije[cmbOdabirRezervacije.SelectedIndex]);
            upisiRezervacije();
            MessageBox.Show("Rezervacija je uspjesno izbrisana");
            this.Close();
        }

        private void btnDodavanjePrilogaJelu_Click(object sender, EventArgs e)
        {
            bool vecjeodabran = false;
            for (int i = 0; i < odabraniPriloziZaJelo.Count; i++)
            {
                if (sviPrilozi[cmbDodavanjePriloga.SelectedIndex + 1].IdPrilog == odabraniPriloziZaJelo[i])
                {
                    vecjeodabran = true;
                }
            }
            if (vecjeodabran)
            {
                MessageBox.Show("Prilog koji pokusavate da dodate vec postoji u listi dodatih priloga");
            }
            else if (cmbDodavanjePriloga.SelectedIndex == -1)
            {
                MessageBox.Show("Niste odabrali prilog koji zelite da dodate");
            }
            else if (cmbOdabirJela.SelectedIndex == -1)
            {
                MessageBox.Show("Nije odabrano ni jedno jelo");
            }
            else
            {
                ukupnaCenaJela += sviPrilozi[cmbDodavanjePriloga.SelectedIndex + 1].CenaPriloga;
                txtUkupnaCenaJela.Text = ukupnaCenaJela.ToString() + "RSD";
                lstbOmoguceniPrilozi.Items.Add(sviPrilozi[cmbDodavanjePriloga.SelectedIndex + 1].NazivPriloga + ", " + sviPrilozi[cmbDodavanjePriloga.SelectedIndex + 1].CenaPriloga + "RSD");
                odabraniPriloziZaJelo.Add(cmbDodavanjePriloga.SelectedIndex + 1);
            }
        }
    }
}
