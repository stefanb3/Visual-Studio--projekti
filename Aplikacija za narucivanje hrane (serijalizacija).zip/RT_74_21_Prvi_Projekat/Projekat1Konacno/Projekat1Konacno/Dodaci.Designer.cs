﻿
namespace Projekat1Konacno
{
    partial class Dodaci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnObrisiDodatak;
            System.Windows.Forms.Button btnAzurirajDodatak;
            System.Windows.Forms.Button btnDodajDodatak;
            this.lblOdabirDodatka = new System.Windows.Forms.Label();
            this.cmbOdaberiDodatak = new System.Windows.Forms.ComboBox();
            this.lblAzurirajCenuDodatka = new System.Windows.Forms.Label();
            this.txtAzurirajCenuDodatka = new System.Windows.Forms.TextBox();
            this.lblAzurirajGramazuDodatka = new System.Windows.Forms.Label();
            this.lblAzurirajNazivDodatka = new System.Windows.Forms.Label();
            this.txtAzurirajGramazuDodatka = new System.Windows.Forms.TextBox();
            this.txtAzurirajNazivDodatka = new System.Windows.Forms.TextBox();
            this.lblCenaDodatka = new System.Windows.Forms.Label();
            this.txtCenaDodatka = new System.Windows.Forms.TextBox();
            this.lblGramazaDodatka = new System.Windows.Forms.Label();
            this.lblNazivDodatka = new System.Windows.Forms.Label();
            this.txtGramazaDodatka = new System.Windows.Forms.TextBox();
            this.txtNazivDodatka = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            btnObrisiDodatak = new System.Windows.Forms.Button();
            btnAzurirajDodatak = new System.Windows.Forms.Button();
            btnDodajDodatak = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnObrisiDodatak
            // 
            btnObrisiDodatak.Location = new System.Drawing.Point(303, 274);
            btnObrisiDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnObrisiDodatak.Name = "btnObrisiDodatak";
            btnObrisiDodatak.Size = new System.Drawing.Size(196, 29);
            btnObrisiDodatak.TabIndex = 35;
            btnObrisiDodatak.Text = "Obrisi dodatak";
            btnObrisiDodatak.UseVisualStyleBackColor = true;
            btnObrisiDodatak.Click += new System.EventHandler(this.btnObrisiDodatak_Click);
            // 
            // btnAzurirajDodatak
            // 
            btnAzurirajDodatak.Location = new System.Drawing.Point(303, 241);
            btnAzurirajDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnAzurirajDodatak.Name = "btnAzurirajDodatak";
            btnAzurirajDodatak.Size = new System.Drawing.Size(196, 29);
            btnAzurirajDodatak.TabIndex = 32;
            btnAzurirajDodatak.Text = "Sacuvaj izmene";
            btnAzurirajDodatak.UseVisualStyleBackColor = true;
            btnAzurirajDodatak.Click += new System.EventHandler(this.btnAzurirajDodatak_Click);
            // 
            // btnDodajDodatak
            // 
            btnDodajDodatak.Location = new System.Drawing.Point(28, 203);
            btnDodajDodatak.Margin = new System.Windows.Forms.Padding(2);
            btnDodajDodatak.Name = "btnDodajDodatak";
            btnDodajDodatak.Size = new System.Drawing.Size(196, 29);
            btnDodajDodatak.TabIndex = 32;
            btnDodajDodatak.Text = "Dodaj dodatak";
            btnDodajDodatak.UseVisualStyleBackColor = true;
            btnDodajDodatak.Click += new System.EventHandler(this.btnDodajDodatak_Click);
            // 
            // lblOdabirDodatka
            // 
            this.lblOdabirDodatka.AutoSize = true;
            this.lblOdabirDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabirDodatka.Location = new System.Drawing.Point(301, 43);
            this.lblOdabirDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabirDodatka.Name = "lblOdabirDodatka";
            this.lblOdabirDodatka.Size = new System.Drawing.Size(106, 17);
            this.lblOdabirDodatka.TabIndex = 35;
            this.lblOdabirDodatka.Text = "Odabir dodatka";
            // 
            // cmbOdaberiDodatak
            // 
            this.cmbOdaberiDodatak.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOdaberiDodatak.FormattingEnabled = true;
            this.cmbOdaberiDodatak.Location = new System.Drawing.Point(304, 64);
            this.cmbOdaberiDodatak.Margin = new System.Windows.Forms.Padding(2);
            this.cmbOdaberiDodatak.Name = "cmbOdaberiDodatak";
            this.cmbOdaberiDodatak.Size = new System.Drawing.Size(197, 25);
            this.cmbOdaberiDodatak.TabIndex = 32;
            this.cmbOdaberiDodatak.SelectedIndexChanged += new System.EventHandler(this.cmbOdaberiDodatak_SelectedIndexChanged);
            // 
            // lblAzurirajCenuDodatka
            // 
            this.lblAzurirajCenuDodatka.AutoSize = true;
            this.lblAzurirajCenuDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajCenuDodatka.Location = new System.Drawing.Point(301, 192);
            this.lblAzurirajCenuDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajCenuDodatka.Name = "lblAzurirajCenuDodatka";
            this.lblAzurirajCenuDodatka.Size = new System.Drawing.Size(100, 17);
            this.lblAzurirajCenuDodatka.TabIndex = 34;
            this.lblAzurirajCenuDodatka.Text = "Cena dodatka:";
            // 
            // txtAzurirajCenuDodatka
            // 
            this.txtAzurirajCenuDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajCenuDodatka.Location = new System.Drawing.Point(303, 211);
            this.txtAzurirajCenuDodatka.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajCenuDodatka.Name = "txtAzurirajCenuDodatka";
            this.txtAzurirajCenuDodatka.Size = new System.Drawing.Size(198, 26);
            this.txtAzurirajCenuDodatka.TabIndex = 33;
            // 
            // lblAzurirajGramazuDodatka
            // 
            this.lblAzurirajGramazuDodatka.AutoSize = true;
            this.lblAzurirajGramazuDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajGramazuDodatka.Location = new System.Drawing.Point(300, 145);
            this.lblAzurirajGramazuDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajGramazuDodatka.Name = "lblAzurirajGramazuDodatka";
            this.lblAzurirajGramazuDodatka.Size = new System.Drawing.Size(121, 17);
            this.lblAzurirajGramazuDodatka.TabIndex = 31;
            this.lblAzurirajGramazuDodatka.Text = "Gramaza dodatka";
            // 
            // lblAzurirajNazivDodatka
            // 
            this.lblAzurirajNazivDodatka.AutoSize = true;
            this.lblAzurirajNazivDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAzurirajNazivDodatka.Location = new System.Drawing.Point(301, 95);
            this.lblAzurirajNazivDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAzurirajNazivDodatka.Name = "lblAzurirajNazivDodatka";
            this.lblAzurirajNazivDodatka.Size = new System.Drawing.Size(102, 17);
            this.lblAzurirajNazivDodatka.TabIndex = 30;
            this.lblAzurirajNazivDodatka.Text = "Naziv dodatka:";
            // 
            // txtAzurirajGramazuDodatka
            // 
            this.txtAzurirajGramazuDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajGramazuDodatka.Location = new System.Drawing.Point(303, 164);
            this.txtAzurirajGramazuDodatka.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajGramazuDodatka.Name = "txtAzurirajGramazuDodatka";
            this.txtAzurirajGramazuDodatka.Size = new System.Drawing.Size(198, 26);
            this.txtAzurirajGramazuDodatka.TabIndex = 1;
            // 
            // txtAzurirajNazivDodatka
            // 
            this.txtAzurirajNazivDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAzurirajNazivDodatka.Location = new System.Drawing.Point(303, 114);
            this.txtAzurirajNazivDodatka.Margin = new System.Windows.Forms.Padding(2);
            this.txtAzurirajNazivDodatka.Name = "txtAzurirajNazivDodatka";
            this.txtAzurirajNazivDodatka.Size = new System.Drawing.Size(198, 26);
            this.txtAzurirajNazivDodatka.TabIndex = 0;
            // 
            // lblCenaDodatka
            // 
            this.lblCenaDodatka.AutoSize = true;
            this.lblCenaDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCenaDodatka.Location = new System.Drawing.Point(27, 145);
            this.lblCenaDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCenaDodatka.Name = "lblCenaDodatka";
            this.lblCenaDodatka.Size = new System.Drawing.Size(100, 17);
            this.lblCenaDodatka.TabIndex = 34;
            this.lblCenaDodatka.Text = "Cena dodatka:";
            // 
            // txtCenaDodatka
            // 
            this.txtCenaDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCenaDodatka.Location = new System.Drawing.Point(28, 165);
            this.txtCenaDodatka.Margin = new System.Windows.Forms.Padding(2);
            this.txtCenaDodatka.Name = "txtCenaDodatka";
            this.txtCenaDodatka.Size = new System.Drawing.Size(198, 26);
            this.txtCenaDodatka.TabIndex = 33;
            // 
            // lblGramazaDodatka
            // 
            this.lblGramazaDodatka.AutoSize = true;
            this.lblGramazaDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGramazaDodatka.Location = new System.Drawing.Point(25, 95);
            this.lblGramazaDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGramazaDodatka.Name = "lblGramazaDodatka";
            this.lblGramazaDodatka.Size = new System.Drawing.Size(121, 17);
            this.lblGramazaDodatka.TabIndex = 31;
            this.lblGramazaDodatka.Text = "Gramaza dodatka";
            // 
            // lblNazivDodatka
            // 
            this.lblNazivDodatka.AutoSize = true;
            this.lblNazivDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNazivDodatka.Location = new System.Drawing.Point(25, 43);
            this.lblNazivDodatka.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNazivDodatka.Name = "lblNazivDodatka";
            this.lblNazivDodatka.Size = new System.Drawing.Size(102, 17);
            this.lblNazivDodatka.TabIndex = 30;
            this.lblNazivDodatka.Text = "Naziv dodatka:";
            // 
            // txtGramazaDodatka
            // 
            this.txtGramazaDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGramazaDodatka.Location = new System.Drawing.Point(28, 117);
            this.txtGramazaDodatka.Margin = new System.Windows.Forms.Padding(2);
            this.txtGramazaDodatka.Name = "txtGramazaDodatka";
            this.txtGramazaDodatka.Size = new System.Drawing.Size(198, 26);
            this.txtGramazaDodatka.TabIndex = 1;
            // 
            // txtNazivDodatka
            // 
            this.txtNazivDodatka.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazivDodatka.Location = new System.Drawing.Point(28, 62);
            this.txtNazivDodatka.Margin = new System.Windows.Forms.Padding(2);
            this.txtNazivDodatka.Name = "txtNazivDodatka";
            this.txtNazivDodatka.Size = new System.Drawing.Size(198, 26);
            this.txtNazivDodatka.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(60, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(104, 17);
            this.label1.TabIndex = 38;
            this.label1.Text = "Dodaj dodatak:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(332, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 17);
            this.label2.TabIndex = 39;
            this.label2.Text = "Azuriraj dodatak:";
            // 
            // Dodaci
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(597, 337);
            this.Controls.Add(btnObrisiDodatak);
            this.Controls.Add(this.label2);
            this.Controls.Add(btnAzurirajDodatak);
            this.Controls.Add(this.txtAzurirajCenuDodatka);
            this.Controls.Add(this.lblAzurirajCenuDodatka);
            this.Controls.Add(this.cmbOdaberiDodatak);
            this.Controls.Add(this.lblOdabirDodatka);
            this.Controls.Add(btnDodajDodatak);
            this.Controls.Add(this.txtAzurirajGramazuDodatka);
            this.Controls.Add(this.lblAzurirajGramazuDodatka);
            this.Controls.Add(this.txtCenaDodatka);
            this.Controls.Add(this.lblAzurirajNazivDodatka);
            this.Controls.Add(this.txtAzurirajNazivDodatka);
            this.Controls.Add(this.lblCenaDodatka);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtGramazaDodatka);
            this.Controls.Add(this.lblGramazaDodatka);
            this.Controls.Add(this.lblNazivDodatka);
            this.Controls.Add(this.txtNazivDodatka);
            this.Name = "Dodaci";
            this.Text = "Dodaci";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblOdabirDodatka;
        private System.Windows.Forms.ComboBox cmbOdaberiDodatak;
        private System.Windows.Forms.Label lblAzurirajCenuDodatka;
        private System.Windows.Forms.TextBox txtAzurirajCenuDodatka;
        private System.Windows.Forms.Label lblAzurirajGramazuDodatka;
        private System.Windows.Forms.Label lblAzurirajNazivDodatka;
        private System.Windows.Forms.TextBox txtAzurirajGramazuDodatka;
        private System.Windows.Forms.TextBox txtAzurirajNazivDodatka;
        private System.Windows.Forms.Label lblCenaDodatka;
        private System.Windows.Forms.TextBox txtCenaDodatka;
        private System.Windows.Forms.Label lblGramazaDodatka;
        private System.Windows.Forms.Label lblNazivDodatka;
        private System.Windows.Forms.TextBox txtGramazaDodatka;
        private System.Windows.Forms.TextBox txtNazivDodatka;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}