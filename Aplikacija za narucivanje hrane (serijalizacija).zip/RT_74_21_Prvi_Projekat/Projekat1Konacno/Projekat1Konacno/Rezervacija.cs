﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1Konacno
{
    [Serializable]
    class Rezervacija
    {
        private DateTime datumRezervacije;
        private List<Jelo> odabranaJela = new List<Jelo>();
        private double ukupnaCena;
        private int idKorisnika;
        private int idRestorana;

        public Rezervacija(DateTime datumRezervacije, List<Jelo> odabranaJela, double ukupnaCena, int idKorisnika, int idRestorana)
        {
            List<Jelo> pom = new List<Jelo>();
            pom = odabranaJela;

            this.datumRezervacije = datumRezervacije;
            this.odabranaJela.AddRange(pom);
            this.ukupnaCena = ukupnaCena;
            this.idKorisnika = idKorisnika;
            this.idRestorana = idRestorana;
        }
        public Rezervacija()
        {
            List<Jelo> pomocna = new List<Jelo>();
            List<int> pomocnaLista = new List<int>();
            pomocnaLista.Add(0);
            pomocna.Add(new Jelo(0, "default", 0, "default", 0.0, pomocnaLista, pomocnaLista, false, 0));

            this.datumRezervacije = DateTime.Now;
            this.odabranaJela = pomocna;
            this.ukupnaCena = 0;
            this.idKorisnika = 0;
            this.idRestorana = 0;

        }

        public DateTime DatumRezervacije { get => datumRezervacije; set => datumRezervacije = value; }
        public double UkupnaCena { get => ukupnaCena; set => ukupnaCena = value; }
        public int IdKorisnika { get => idKorisnika; set => idKorisnika = value; }
        public int IdRestorana { get => idRestorana; set => idRestorana = value; }
        internal List<Jelo> OdabranaJela { get => odabranaJela; set => odabranaJela = value; }
    }
}
