﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class Restorani : Form
    {
        List<Restoran> restorani = new List<Restoran>();
        string nazivDatoteke = "restorani.bin";
        public Restorani()
        {
            InitializeComponent();
            ucitajRestorane();
            upisiRestoraneUDatoteku();
            ucitajRestoraneZaAzuriranje();
        }

        void ucitajRestorane()
        {
            if (File.Exists(nazivDatoteke))
            {
                // Ako datoteka postoji, čitamo podatke iz nje
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                restorani = binaryFormatter.Deserialize(fs) as List<Restoran>;
                fs.Close();
            }
            else
            {
                // Ako datoteka ne postoji, kreiramo listu sa jednim podrazumevanim restoranom
                List<Restoran> restoran = new List<Restoran>();
                restoran.Add(new Restoran(1, "default", "default", "default"));

                // Kreiramo novu datoteku i upisujemo listu u nju
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, restoran);

                fs.Dispose();
            }
        }


        void upisiRestoraneUDatoteku()
        {
            FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, restorani);

            fs.Dispose();
        }



        void ucitajRestoraneZaAzuriranje()
        {
            cmbOdabirRestorana.Items.Clear();
            for (int i = 1; i < restorani.Count; i++)
            {
                cmbOdabirRestorana.Items.Add("Naziv: " + restorani[i].NazivRestorana + " adresa: " + restorani[i].AdresaRestorana + " kontakt: " + restorani[i].KontaktRestorana);
            }
        }



        private void btnDodajRestoran_Click(object sender, EventArgs e)
        {
            if (txtNazivRestorana.Text == "" || txtAdresaRestorana.Text == "" || txtKontaktRestorana.Text == "")
            {
                MessageBox.Show("Sva polja su obavezna");
            }
            else
            {
                Restoran restorani1;
                if (restorani.Count > 0)
                {
                    restorani1 = new Restoran(restorani[restorani.Count - 1].IdRestorana + 1, txtNazivRestorana.Text, txtAdresaRestorana.Text, txtKontaktRestorana.Text);
                }
                else
                {
                    // Ako lista nema elemenata odna postavljamo prvi 
                    restorani1 = new Restoran(1, txtNazivRestorana.Text, txtAdresaRestorana.Text, txtKontaktRestorana.Text);
                }
                restorani.Add(restorani1);
                upisiRestoraneUDatoteku();
                MessageBox.Show("Uspesno dodavanje restorana");

                txtNazivRestorana.Text = "";
                txtAdresaRestorana.Text = "";
                txtKontaktRestorana.Text = "";

               
                ucitajRestorane();
                ucitajRestoraneZaAzuriranje();
            }
        }







      

        private void cmbOdabirRestorana_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            txtAzurirajNazivRestorana.Text = restorani[cmbOdabirRestorana.SelectedIndex + 1].NazivRestorana;
            txtAzurirajAdresuRestorana.Text = restorani[cmbOdabirRestorana.SelectedIndex + 1].AdresaRestorana;//posto kod upisivanja itema u combo preskacemo prvi clan koji je default posle moramo da dodajemo + 1 na indeks
            txtAzurirajKontaktRestorana.Text = restorani[cmbOdabirRestorana.SelectedIndex + 1].KontaktRestorana;
        }

        private void btnAzurirajRestoran_Click(object sender, EventArgs e)
        {
            if (txtAzurirajNazivRestorana.Text == "" || txtAzurirajAdresuRestorana.Text == "" || txtAzurirajKontaktRestorana.Text == "")
            {
                MessageBox.Show("Da bi se sacuvale izmene sva polja moraju biti popunjena");
            }
            else
            {
                restorani[cmbOdabirRestorana.SelectedIndex + 1].NazivRestorana = txtAzurirajNazivRestorana.Text;
                restorani[cmbOdabirRestorana.SelectedIndex + 1].AdresaRestorana = txtAzurirajAdresuRestorana.Text;
                restorani[cmbOdabirRestorana.SelectedIndex + 1].KontaktRestorana = txtAzurirajKontaktRestorana.Text;

                MessageBox.Show("Uspesno ste sacuvali izmene");

                txtAzurirajNazivRestorana.Text = restorani[cmbOdabirRestorana.SelectedIndex + 1].NazivRestorana;
                txtAzurirajAdresuRestorana.Text = restorani[cmbOdabirRestorana.SelectedIndex + 1].AdresaRestorana;
                txtAzurirajKontaktRestorana.Text = restorani[cmbOdabirRestorana.SelectedIndex + 1].KontaktRestorana;

                upisiRestoraneUDatoteku();
                ucitajRestorane();
                ucitajRestoraneZaAzuriranje();
            }
        }

        private void btnObrisiRestoran_Click(object sender, EventArgs e)
        {
            restorani.RemoveAt(cmbOdabirRestorana.SelectedIndex + 1);
            MessageBox.Show("Upesno ste obrisali restoran");
            txtAzurirajAdresuRestorana.Text = "";
            txtAzurirajKontaktRestorana.Text = "";
            txtAzurirajNazivRestorana.Text = "";
            upisiRestoraneUDatoteku();
            ucitajRestorane();
            ucitajRestoraneZaAzuriranje();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Restorani_Load(object sender, EventArgs e)
        {

        }
    }
}
