﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class KorisnikLogIn : Form
    {
        List<Korisnik> korisnici = new List<Korisnik>();
        string nazivDatoteke = "korisnici.bin";
        public KorisnikLogIn()
        {
            InitializeComponent();
            PostojanjeDatoteke();
        }

        void PostojanjeDatoteke()
        {
            if (File.Exists(nazivDatoteke))
            {
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter(); //Deserijalizujemo datoteku kako bi smo kasnije omogucili prijavu
                korisnici = binaryFormatter.Deserialize(fs) as List<Korisnik>;
                fs.Dispose();
            }
            else
            {
                List<Korisnik> korisnik = new List<Korisnik>(); //pravimo listu
                korisnik.Add(new Korisnik(1, "korisnik", "korisnik", "korisnik", "korisnik")); //pravimo default korisnika
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Create); //pravimo datoteku
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, korisnik); //upisujemo u datoteku
                fs.Dispose(); //zatvaramo
            }






        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (tbKorisnickoIme.Text != "" && tbSifra.Text != "")
            {

                for (int i = 0; i < korisnici.Count; i++)
                {
                    if (tbKorisnickoIme.Text == "korisnik" && tbSifra.Text == "korisnik")
                    {
                        KorisnickaStrana form2 = new KorisnickaStrana(0);
                        form2.Show();
                        break;
                    }
                    if (tbKorisnickoIme.Text == korisnici[i].KorIme && tbSifra.Text == korisnici[i].Password) //Proveravamo da li uneseni kredencijali odgovaraju nekom korisnku
                    {

                        KorisnickaStrana forma1 = new KorisnickaStrana(korisnici[i].Id);
                        forma1.Show(); 
                        break;

                    }

                }
            }
            else
            {

                MessageBox.Show("Oba polja moraju biti popunjena");
            }

        }

        private void btnRegistrujSe_Click(object sender, EventArgs e)
        {
            RegistracijaKorisnika form1 = new RegistracijaKorisnika();
            form1.Show();
        }
    }
}
