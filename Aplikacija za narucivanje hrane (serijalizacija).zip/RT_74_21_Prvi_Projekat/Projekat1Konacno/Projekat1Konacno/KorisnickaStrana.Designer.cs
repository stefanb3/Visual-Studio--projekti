﻿
namespace Projekat1Konacno
{
    partial class KorisnickaStrana
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button button3;
            System.Windows.Forms.Button button2;
            System.Windows.Forms.Button button1;
            System.Windows.Forms.Button btnDodajPrilog;
            button3 = new System.Windows.Forms.Button();
            button2 = new System.Windows.Forms.Button();
            button1 = new System.Windows.Forms.Button();
            btnDodajPrilog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button3
            // 
            button3.Location = new System.Drawing.Point(88, 175);
            button3.Margin = new System.Windows.Forms.Padding(2);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(260, 29);
            button3.TabIndex = 40;
            button3.Text = "Izloguj se";
            button3.UseVisualStyleBackColor = true;
            button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            button2.Location = new System.Drawing.Point(88, 103);
            button2.Margin = new System.Windows.Forms.Padding(2);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(260, 68);
            button2.TabIndex = 39;
            button2.Text = "Izmena postojecih rezervacija";
            button2.UseVisualStyleBackColor = true;
            button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            button1.Location = new System.Drawing.Point(212, 18);
            button1.Margin = new System.Windows.Forms.Padding(2);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(136, 81);
            button1.TabIndex = 38;
            button1.Text = "Pregled napravljenih rezervacija";
            button1.UseVisualStyleBackColor = true;
            button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDodajPrilog
            // 
            btnDodajPrilog.Location = new System.Drawing.Point(88, 18);
            btnDodajPrilog.Margin = new System.Windows.Forms.Padding(2);
            btnDodajPrilog.Name = "btnDodajPrilog";
            btnDodajPrilog.Size = new System.Drawing.Size(120, 81);
            btnDodajPrilog.TabIndex = 37;
            btnDodajPrilog.Text = "Pravljenje nove rezervacije";
            btnDodajPrilog.UseVisualStyleBackColor = true;
            btnDodajPrilog.Click += new System.EventHandler(this.btnDodajPrilog_Click);
            // 
            // KorisnickaStrana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 227);
            this.Controls.Add(button3);
            this.Controls.Add(button2);
            this.Controls.Add(button1);
            this.Controls.Add(btnDodajPrilog);
            this.Name = "KorisnickaStrana";
            this.Text = "KorisnickaStrana";
            this.ResumeLayout(false);

        }

        #endregion
    }
}