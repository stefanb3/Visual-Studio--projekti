﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class PriloziForma : Form
    {


        List<Prilog> prilozi = new List<Prilog>();
        string nazivDatoteke = "prilozi.bin";
        public PriloziForma()
        {
            InitializeComponent();
            ucitajPriloge();
            sacuvajPrilogeUDatoteku();
            ucitajPrilogeZaAzuriranje();
        }



        void ucitajPriloge()
        {
            if (File.Exists(nazivDatoteke))
            {
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter(); //Deserijalizujemo datoteku kako bi smo kasnije omogucili prijavu
                prilozi = binaryFormatter.Deserialize(fs) as List<Prilog>;
                fs.Dispose();
            }
            else
            {
                List<Prilog> prilozi = new List<Prilog>();
                prilozi.Add(new Prilog(0, "default", 0.0));
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Create); //dodajemo default prilog koji ce nam omguciti da korisnik odabere da ne zeli prilog
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, prilozi);

                fs.Dispose();

                ucitajPriloge();

                ucitajPrilogeZaAzuriranje();
            }
        }
        void sacuvajPrilogeUDatoteku()
        {
            FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, prilozi);

            fs.Dispose();
        }
        void ucitajPrilogeZaAzuriranje()
        {
            cmbOdabirPriloga.Items.Clear();

            for (int i = 1; i < prilozi.Count(); i++)
            {
                cmbOdabirPriloga.Items.Add("ID:" + prilozi[i].IdPrilog + " " + prilozi[i].NazivPriloga + " " + prilozi[i].CenaPriloga + "RSD");
            }
        }


        private void btnDodajPrilog_Click(object sender, EventArgs e)
        {
            double pom;
            if (txtNazivPriloga.Text == "" || txtCenaPriloga.Text == "")
            {
                MessageBox.Show("Oba polja su obavezna");
            }
            else if (!double.TryParse(txtCenaPriloga.Text, out pom))
            {
                MessageBox.Show("Cena mora biti brojcana vrednost");
            }
            else
            {
                Prilog noviPrilog;
              

                if (prilozi.Count > 0) {

                    noviPrilog = new Prilog((prilozi[prilozi.Count - 1].IdPrilog) + 1, txtNazivPriloga.Text, double.Parse(txtCenaPriloga.Text));

                } else {
                   
                    
                    noviPrilog = new Prilog(1, txtNazivPriloga.Text, double.Parse(txtCenaPriloga.Text));

                }

                prilozi.Add(noviPrilog);

                sacuvajPrilogeUDatoteku();
                MessageBox.Show("Uspesno ste dodali prilog");
                ucitajPriloge();
                ucitajPrilogeZaAzuriranje();
                txtNazivPriloga.Text = "";
                txtCenaPriloga.Text = "";
            }
        }

        private void cmbOdabirPriloga_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtAzurirajNazivPriloga.Text = prilozi[cmbOdabirPriloga.SelectedIndex +1 ].NazivPriloga; 
            txtAzurirajCenuPriloga.Text = prilozi[cmbOdabirPriloga.SelectedIndex +1].CenaPriloga.ToString();
        }

        private void btnAzurirajPrilog_Click(object sender, EventArgs e)
        {
            double pom;
            if (txtAzurirajNazivPriloga.Text == "" || txtAzurirajCenuPriloga.Text == "")
            {
                MessageBox.Show("Oba polja su obavezna");
            }
            else if (!double.TryParse(txtAzurirajCenuPriloga.Text, out pom))
            {
                MessageBox.Show("Cena mora biti brojcana vrednost");
            }
            else
            {
                prilozi[cmbOdabirPriloga.SelectedIndex +1].NazivPriloga = txtAzurirajNazivPriloga.Text;
                prilozi[cmbOdabirPriloga.SelectedIndex +1].CenaPriloga = double.Parse(txtAzurirajCenuPriloga.Text);


                txtAzurirajCenuPriloga.Text = "";
                txtAzurirajNazivPriloga.Text = "";

                sacuvajPrilogeUDatoteku();
                ucitajPriloge();
                ucitajPrilogeZaAzuriranje();

                MessageBox.Show("Uspesno ste sacuvali izmene");

                
            }
        }

        private void btnObrisiPrilog_Click(object sender, EventArgs e)
        {
            prilozi.RemoveAt(cmbOdabirPriloga.SelectedIndex + 1);

            sacuvajPrilogeUDatoteku();
            ucitajPriloge();
            ucitajPrilogeZaAzuriranje();

            MessageBox.Show("Uspesno ste obrisali odabrani prilog");

            txtAzurirajCenuPriloga.Text = "";
            txtAzurirajNazivPriloga.Text = "";
        }

        private void PriloziForma_Load(object sender, EventArgs e)
        {

        }
    }
    }

