﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1Konacno
{
    [Serializable]
    class Restoran
    {
        private int idRestorana;
        private string nazivRestorana;
        private string adresaRestorana;
        private string kontaktRestorana;

        public Restoran(int idRestorana, string nazivRestorana, string adresaRestorana, string kontaktRestorana)
        {
            this.idRestorana = idRestorana;
            this.nazivRestorana = nazivRestorana;
            this.adresaRestorana = adresaRestorana;
            this.kontaktRestorana = kontaktRestorana;
        }

        public int IdRestorana { get => idRestorana; set => idRestorana = value; }
        public string NazivRestorana { get => nazivRestorana; set => nazivRestorana = value; }
        public string AdresaRestorana { get => adresaRestorana; set => adresaRestorana = value; }
        public string KontaktRestorana { get => kontaktRestorana; set => kontaktRestorana = value; }
    }
}
