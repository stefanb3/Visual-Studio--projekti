﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projekat1Konacno
{
    [Serializable]
    class Korisnik
    {
        private int id;
        private string ime;
        private string prezime;
        private string korIme;
        private string password;

        public Korisnik(int id, string ime, string prezime, string korIme, string password)
        {
            this.id = id;
            this.ime = ime;
            this.prezime = prezime;
            this.korIme = korIme;
            this.password = password;
            
        }

        

        public int Id { get => id; set => id = value; }
        public string Ime { get => ime; set => ime = value; }
        public string Prezime { get => prezime; set => prezime = value; }
        public string KorIme { get => korIme; set => korIme = value; }
        public string Password { get => password; set => password = value; }
        
    }
}
