﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekat1Konacno
{
    public partial class Dodaci : Form
    {
        List<Dodatak> dodaci = new List<Dodatak>();
        string nazivDatoteke = "dodaci.bin";
        public Dodaci()
        {
            InitializeComponent();
            ucitajDodatke();
            ucitajDodatkeZaAzuriranje();
        }

        void ucitajDodatke()
        {
            if (File.Exists(nazivDatoteke))
            {
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                dodaci = binaryFormatter.Deserialize(fs) as List<Dodatak>;
                fs.Dispose();
            }
            else
            {
                List<Dodatak> dodatak = new List<Dodatak>();
                dodatak.Add(new Dodatak(0, "default", 0, 0));
                FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, dodatak);

                fs.Dispose();

            }
        }
        void upisiDodatkaUDatoteku()
        {
            FileStream fs = new FileStream(nazivDatoteke, FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fs, dodaci);

            fs.Dispose();
        }
        void ucitajDodatkeZaAzuriranje()
        {
            cmbOdaberiDodatak.Items.Clear();
            for (int i = 1; i < dodaci.Count; i++)
            {
                cmbOdaberiDodatak.Items.Add("ID " + dodaci[i].IdDodatka + " " + dodaci[i].NazivDodatka + " " + dodaci[i].GramazaDodatka + "g " + dodaci[i].CenaDodatka + "RSD");
            }
        }

        private void btnDodajDodatak_Click(object sender, EventArgs e)
        {
            int pom;
            double pom1;
            if (txtNazivDodatka.Text == "" || txtGramazaDodatka.Text == "" || txtCenaDodatka.Text == "")
            {
                MessageBox.Show("Sva polja su obavezna");
            }
            else if (!int.TryParse(txtGramazaDodatka.Text, out pom) || !double.TryParse(txtCenaDodatka.Text, out pom1))
            {
                MessageBox.Show("Gramaza i cena moraju biti brojcane vrednosti");
            }
            else
            {

                Dodatak noviDodatak;
                if (dodaci.Count > 0)
                {
                    noviDodatak = new Dodatak(dodaci[dodaci.Count - 1].IdDodatka + 1, txtNazivDodatka.Text, double.Parse(txtCenaDodatka.Text), int.Parse(txtGramazaDodatka.Text));
                }
                else
                {
                    // Ako lista nema elemenata odna postavljamo prvi 
                    noviDodatak = new Dodatak(1, txtNazivDodatka.Text, double.Parse(txtCenaDodatka.Text), int.Parse(txtGramazaDodatka.Text));
                }
                dodaci.Add(noviDodatak);
                MessageBox.Show("Uspesno ste dodali dodatak");

                txtNazivDodatka.Text = "";
                txtCenaDodatka.Text = "";
                txtGramazaDodatka.Text = "";

                upisiDodatkaUDatoteku();
                ucitajDodatke();
                ucitajDodatkeZaAzuriranje();
            }
        }

        private void cmbOdaberiDodatak_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtAzurirajNazivDodatka.Text = dodaci[cmbOdaberiDodatak.SelectedIndex + 1].NazivDodatka;
            txtAzurirajCenuDodatka.Text = dodaci[cmbOdaberiDodatak.SelectedIndex + 1].CenaDodatka.ToString();
            txtAzurirajGramazuDodatka.Text = dodaci[cmbOdaberiDodatak.SelectedIndex + 1].GramazaDodatka.ToString();
        }

        private void btnAzurirajDodatak_Click(object sender, EventArgs e)
        {
            int pom;
            double pom1;
            if (txtAzurirajNazivDodatka.Text == "" || txtAzurirajGramazuDodatka.Text == "" || txtAzurirajCenuDodatka.Text == "")
            {
                MessageBox.Show("Sva polja su obavezna");
            }
            else if (!int.TryParse(txtAzurirajGramazuDodatka.Text, out pom) || !double.TryParse(txtAzurirajCenuDodatka.Text, out pom1))
            {
                MessageBox.Show("Gramaza i cena moraju biti brojcane vrednosti");
            }
            else
            {
                dodaci[cmbOdaberiDodatak.SelectedIndex].NazivDodatka = txtAzurirajNazivDodatka.Text;
                dodaci[cmbOdaberiDodatak.SelectedIndex].GramazaDodatka = int.Parse(txtAzurirajGramazuDodatka.Text);
                dodaci[cmbOdaberiDodatak.SelectedIndex].CenaDodatka = double.Parse(txtAzurirajCenuDodatka.Text);

                MessageBox.Show("Uspesno ste azurirali informacije o dodatku");

                txtAzurirajCenuDodatka.Text = "";
                txtAzurirajGramazuDodatka.Text = "";
                txtAzurirajNazivDodatka.Text = "";

                upisiDodatkaUDatoteku();
                ucitajDodatke();
                ucitajDodatkeZaAzuriranje();
            }
        }

        private void btnObrisiDodatak_Click(object sender, EventArgs e)
        {
            dodaci.RemoveAt(cmbOdaberiDodatak.SelectedIndex + 1);

            MessageBox.Show("Uspesno ste obrisali dodatak");

            txtAzurirajCenuDodatka.Text = "";
            txtAzurirajGramazuDodatka.Text = "";
            txtAzurirajNazivDodatka.Text = "";

            upisiDodatkaUDatoteku();
            ucitajDodatke();
            ucitajDodatkeZaAzuriranje();
        }
    }
}
