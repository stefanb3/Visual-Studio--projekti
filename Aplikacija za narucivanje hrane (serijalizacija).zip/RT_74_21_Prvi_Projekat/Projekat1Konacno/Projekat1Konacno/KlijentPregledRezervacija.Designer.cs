﻿
namespace Projekat1Konacno
{
    partial class KlijentPregledRezervacija
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button btnZatvaranje;
            this.txtDatumRezervacije = new System.Windows.Forms.TextBox();
            this.lblDatumRezervacije = new System.Windows.Forms.Label();
            this.lblOdabirRezervacije = new System.Windows.Forms.Label();
            this.lstbRezervacije = new System.Windows.Forms.ListBox();
            this.txtKontaktRestorana = new System.Windows.Forms.TextBox();
            this.lblKontaktRestorana = new System.Windows.Forms.Label();
            this.txtAdresaRestorana = new System.Windows.Forms.TextBox();
            this.txtNazivRestorana = new System.Windows.Forms.TextBox();
            this.lblAdresaRestorana = new System.Windows.Forms.Label();
            this.lblNazivRestorana = new System.Windows.Forms.Label();
            this.txtUkupnaCena = new System.Windows.Forms.TextBox();
            this.lblUkupnaCena = new System.Windows.Forms.Label();
            this.lstbOdabranaJela = new System.Windows.Forms.ListBox();
            this.lblOdabranaJela = new System.Windows.Forms.Label();
            btnZatvaranje = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtDatumRezervacije
            // 
            this.txtDatumRezervacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDatumRezervacije.Location = new System.Drawing.Point(272, 27);
            this.txtDatumRezervacije.Margin = new System.Windows.Forms.Padding(2);
            this.txtDatumRezervacije.Name = "txtDatumRezervacije";
            this.txtDatumRezervacije.ReadOnly = true;
            this.txtDatumRezervacije.Size = new System.Drawing.Size(244, 26);
            this.txtDatumRezervacije.TabIndex = 129;
            // 
            // lblDatumRezervacije
            // 
            this.lblDatumRezervacije.AutoSize = true;
            this.lblDatumRezervacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatumRezervacije.Location = new System.Drawing.Point(269, 9);
            this.lblDatumRezervacije.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDatumRezervacije.Name = "lblDatumRezervacije";
            this.lblDatumRezervacije.Size = new System.Drawing.Size(126, 17);
            this.lblDatumRezervacije.TabIndex = 128;
            this.lblDatumRezervacije.Text = "Datum rezervacije:";
            // 
            // lblOdabirRezervacije
            // 
            this.lblOdabirRezervacije.AutoSize = true;
            this.lblOdabirRezervacije.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabirRezervacije.Location = new System.Drawing.Point(11, 9);
            this.lblOdabirRezervacije.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabirRezervacije.Name = "lblOdabirRezervacije";
            this.lblOdabirRezervacije.Size = new System.Drawing.Size(128, 17);
            this.lblOdabirRezervacije.TabIndex = 127;
            this.lblOdabirRezervacije.Text = "Odabir rezervacije:";
            // 
            // lstbRezervacije
            // 
            this.lstbRezervacije.FormattingEnabled = true;
            this.lstbRezervacije.Location = new System.Drawing.Point(14, 27);
            this.lstbRezervacije.Margin = new System.Windows.Forms.Padding(2);
            this.lstbRezervacije.Name = "lstbRezervacije";
            this.lstbRezervacije.Size = new System.Drawing.Size(244, 238);
            this.lstbRezervacije.TabIndex = 126;
            this.lstbRezervacije.SelectedIndexChanged += new System.EventHandler(this.lstbRezervacije_SelectedIndexChanged);
            // 
            // txtKontaktRestorana
            // 
            this.txtKontaktRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKontaktRestorana.Location = new System.Drawing.Point(545, 75);
            this.txtKontaktRestorana.Margin = new System.Windows.Forms.Padding(2);
            this.txtKontaktRestorana.Name = "txtKontaktRestorana";
            this.txtKontaktRestorana.ReadOnly = true;
            this.txtKontaktRestorana.Size = new System.Drawing.Size(244, 26);
            this.txtKontaktRestorana.TabIndex = 125;
            // 
            // lblKontaktRestorana
            // 
            this.lblKontaktRestorana.AutoSize = true;
            this.lblKontaktRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKontaktRestorana.Location = new System.Drawing.Point(545, 56);
            this.lblKontaktRestorana.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblKontaktRestorana.Name = "lblKontaktRestorana";
            this.lblKontaktRestorana.Size = new System.Drawing.Size(125, 17);
            this.lblKontaktRestorana.TabIndex = 124;
            this.lblKontaktRestorana.Text = "Kontakt restorana:";
            // 
            // txtAdresaRestorana
            // 
            this.txtAdresaRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAdresaRestorana.Location = new System.Drawing.Point(272, 74);
            this.txtAdresaRestorana.Margin = new System.Windows.Forms.Padding(2);
            this.txtAdresaRestorana.Name = "txtAdresaRestorana";
            this.txtAdresaRestorana.ReadOnly = true;
            this.txtAdresaRestorana.Size = new System.Drawing.Size(244, 26);
            this.txtAdresaRestorana.TabIndex = 123;
            // 
            // txtNazivRestorana
            // 
            this.txtNazivRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNazivRestorana.Location = new System.Drawing.Point(548, 28);
            this.txtNazivRestorana.Margin = new System.Windows.Forms.Padding(2);
            this.txtNazivRestorana.Name = "txtNazivRestorana";
            this.txtNazivRestorana.ReadOnly = true;
            this.txtNazivRestorana.Size = new System.Drawing.Size(244, 26);
            this.txtNazivRestorana.TabIndex = 122;
            // 
            // lblAdresaRestorana
            // 
            this.lblAdresaRestorana.AutoSize = true;
            this.lblAdresaRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdresaRestorana.Location = new System.Drawing.Point(273, 55);
            this.lblAdresaRestorana.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblAdresaRestorana.Name = "lblAdresaRestorana";
            this.lblAdresaRestorana.Size = new System.Drawing.Size(122, 17);
            this.lblAdresaRestorana.TabIndex = 121;
            this.lblAdresaRestorana.Text = "Adresa restorana:";
            // 
            // lblNazivRestorana
            // 
            this.lblNazivRestorana.AutoSize = true;
            this.lblNazivRestorana.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNazivRestorana.Location = new System.Drawing.Point(545, 9);
            this.lblNazivRestorana.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNazivRestorana.Name = "lblNazivRestorana";
            this.lblNazivRestorana.Size = new System.Drawing.Size(112, 17);
            this.lblNazivRestorana.TabIndex = 120;
            this.lblNazivRestorana.Text = "Naziv restorana:";
            // 
            // btnZatvaranje
            // 
            btnZatvaranje.Location = new System.Drawing.Point(544, 161);
            btnZatvaranje.Margin = new System.Windows.Forms.Padding(2);
            btnZatvaranje.Name = "btnZatvaranje";
            btnZatvaranje.Size = new System.Drawing.Size(243, 64);
            btnZatvaranje.TabIndex = 119;
            btnZatvaranje.Text = "Zatvaranje pregleda";
            btnZatvaranje.UseVisualStyleBackColor = true;
            btnZatvaranje.Click += new System.EventHandler(this.btnZatvaranje_Click);
            // 
            // txtUkupnaCena
            // 
            this.txtUkupnaCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUkupnaCena.Location = new System.Drawing.Point(544, 131);
            this.txtUkupnaCena.Margin = new System.Windows.Forms.Padding(2);
            this.txtUkupnaCena.Name = "txtUkupnaCena";
            this.txtUkupnaCena.ReadOnly = true;
            this.txtUkupnaCena.Size = new System.Drawing.Size(244, 26);
            this.txtUkupnaCena.TabIndex = 118;
            // 
            // lblUkupnaCena
            // 
            this.lblUkupnaCena.AutoSize = true;
            this.lblUkupnaCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUkupnaCena.Location = new System.Drawing.Point(542, 112);
            this.lblUkupnaCena.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblUkupnaCena.Name = "lblUkupnaCena";
            this.lblUkupnaCena.Size = new System.Drawing.Size(96, 17);
            this.lblUkupnaCena.TabIndex = 117;
            this.lblUkupnaCena.Text = "Ukupna cena:";
            // 
            // lstbOdabranaJela
            // 
            this.lstbOdabranaJela.FormattingEnabled = true;
            this.lstbOdabranaJela.Location = new System.Drawing.Point(272, 131);
            this.lstbOdabranaJela.Margin = new System.Windows.Forms.Padding(2);
            this.lstbOdabranaJela.Name = "lstbOdabranaJela";
            this.lstbOdabranaJela.Size = new System.Drawing.Size(244, 134);
            this.lstbOdabranaJela.TabIndex = 116;
            // 
            // lblOdabranaJela
            // 
            this.lblOdabranaJela.AutoSize = true;
            this.lblOdabranaJela.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOdabranaJela.Location = new System.Drawing.Point(273, 112);
            this.lblOdabranaJela.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblOdabranaJela.Name = "lblOdabranaJela";
            this.lblOdabranaJela.Size = new System.Drawing.Size(156, 17);
            this.lblOdabranaJela.TabIndex = 115;
            this.lblOdabranaJela.Text = "Do sada odabrana jela:";
            // 
            // KlijentPregledRezervacija
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 272);
            this.Controls.Add(this.txtDatumRezervacije);
            this.Controls.Add(this.lblDatumRezervacije);
            this.Controls.Add(this.lblOdabirRezervacije);
            this.Controls.Add(this.lstbRezervacije);
            this.Controls.Add(this.txtKontaktRestorana);
            this.Controls.Add(this.lblKontaktRestorana);
            this.Controls.Add(this.txtAdresaRestorana);
            this.Controls.Add(this.txtNazivRestorana);
            this.Controls.Add(this.lblAdresaRestorana);
            this.Controls.Add(this.lblNazivRestorana);
            this.Controls.Add(btnZatvaranje);
            this.Controls.Add(this.txtUkupnaCena);
            this.Controls.Add(this.lblUkupnaCena);
            this.Controls.Add(this.lstbOdabranaJela);
            this.Controls.Add(this.lblOdabranaJela);
            this.Name = "KlijentPregledRezervacija";
            this.Text = "KlijentPregledRezervacija";
            this.Load += new System.EventHandler(this.KlijentPregledRezervacija_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDatumRezervacije;
        private System.Windows.Forms.Label lblDatumRezervacije;
        private System.Windows.Forms.Label lblOdabirRezervacije;
        private System.Windows.Forms.ListBox lstbRezervacije;
        private System.Windows.Forms.TextBox txtKontaktRestorana;
        private System.Windows.Forms.Label lblKontaktRestorana;
        private System.Windows.Forms.TextBox txtAdresaRestorana;
        private System.Windows.Forms.TextBox txtNazivRestorana;
        private System.Windows.Forms.Label lblAdresaRestorana;
        private System.Windows.Forms.Label lblNazivRestorana;
        private System.Windows.Forms.TextBox txtUkupnaCena;
        private System.Windows.Forms.Label lblUkupnaCena;
        private System.Windows.Forms.ListBox lstbOdabranaJela;
        private System.Windows.Forms.Label lblOdabranaJela;
    }
}